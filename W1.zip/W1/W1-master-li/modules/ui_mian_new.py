# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainBxxNnA.ui'
##
## Created by: Qt User Interface Compiler version 5.14.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QMetaObject,
    QObject, QPoint, QRect, QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont,
    QFontDatabase, QIcon, QKeySequence, QLinearGradient, QPalette, QPainter,
    QPixmap, QRadialGradient)
from PySide6.QtWidgets import *

import resources_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1362, 904)
        MainWindow.setMinimumSize(QSize(940, 560))
        self.styleSheet = QWidget(MainWindow)
        self.styleSheet.setObjectName(u"styleSheet")
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(QFont.Normal)
        self.styleSheet.setFont(font)
        self.styleSheet.setStyleSheet(u"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"\n"
"SET APP STYLESHEET - FULL STYLES HERE\n"
"DARK THEME - DRACULA COLOR BASED\n"
"\n"
"///////////////////////////////////////////////////////////////////////////////////////////////// */\n"
"\n"
"QWidget{\n"
"	color: rgb(221, 221, 221);\n"
"	font: 10pt \"Segoe UI\";\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Tooltip */\n"
"QToolTip {\n"
"	color: #ffffff;\n"
"	background-color: rgba(33, 37, 43, 180);\n"
"	border: 1px solid rgb(44, 49, 58);\n"
"	background-image: none;\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 2px solid rgb(255, 121, 198);\n"
"	text-align: left;\n"
"	padding-left: 8px;\n"
"	margin: 0px;\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Bg App */\n"
"#bgApp {	\n"
"	background"
                        "-color: rgb(40, 44, 52);\n"
"	border: 1px solid rgb(44, 49, 58);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Left Menu */\n"
"#leftMenuBg {	\n"
"	background-color: rgb(33, 37, 43);\n"
"}\n"
"#topLogo {\n"
"	background-color: rgb(33, 37, 43);\n"
"	background-image: url(:/images/images/images/LeftTopLogo.png);\n"
"	background-position: centered;\n"
"	background-repeat: no-repeat;\n"
"}\n"
"#titleLeftApp { font: 63 12pt \"Segoe UI Semibold\"; }\n"
"#titleLeftDescription { font: 8pt \"Segoe UI\"; color: rgb(189, 147, 249); }\n"
"\n"
"/* MENUS */\n"
"#topMenu .QPushButton {	\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 22px solid transparent;\n"
"	background-color: transparent;\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"}\n"
"#topMenu .QPushButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#topMenu .QPushButton:pressed {	\n"
"	background-color: rgb("
                        "189, 147, 249);\n"
"	color: rgb(255, 255, 255);\n"
"}\n"
"#bottomMenu .QPushButton {	\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 20px solid transparent;\n"
"	background-color:transparent;\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"}\n"
"#bottomMenu .QPushButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#bottomMenu .QPushButton:pressed {	\n"
"	background-color: rgb(189, 147, 249);\n"
"	color: rgb(255, 255, 255);\n"
"}\n"
"#leftMenuFrame{\n"
"	border-top: 3px solid rgb(44, 49, 58);\n"
"}\n"
"\n"
"/* Toggle Button */\n"
"#toggleButton {\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 20px solid transparent;\n"
"	background-color: rgb(37, 41, 48);\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"	color: rgb(113, 126, 149);\n"
"}\n"
"#toggleButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#toggleButton:pressed {\n"
"	background-color: rg"
                        "b(189, 147, 249);\n"
"}\n"
"\n"
"/* Title Menu */\n"
"#titleRightInfo { padding-left: 10px; }\n"
"\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Extra Tab */\n"
"#extraLeftBox {	\n"
"	background-color: rgb(44, 49, 58);\n"
"}\n"
"#extraTopBg{	\n"
"	background-color: rgb(189, 147, 249)\n"
"}\n"
"\n"
"/* Icon */\n"
"#extraIcon {\n"
"	background-position: center;\n"
"	background-repeat: no-repeat;\n"
"	background-image: url(:/icons/images/icons/icon_settings.png);\n"
"}\n"
"\n"
"/* Label */\n"
"#extraLabel { color: rgb(255, 255, 255); }\n"
"\n"
"/* Btn Close */\n"
"#extraCloseColumnBtn { background-color: rgba(255, 255, 255, 0); border: none;  border-radius: 5px; }\n"
"#extraCloseColumnBtn:hover { background-color: rgb(196, 161, 249); border-style: solid; border-radius: 4px; }\n"
"#extraCloseColumnBtn:pressed { background-color: rgb(180, 141, 238); border-style: solid; border-radius: 4px; }\n"
"\n"
"/* Extra Content */\n"
"#extraContent{\n"
"	bord"
                        "er-top: 3px solid rgb(40, 44, 52);\n"
"}\n"
"\n"
"/* Extra Top Menus */\n"
"#extraTopMenu .QPushButton {\n"
"background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 22px solid transparent;\n"
"	background-color:transparent;\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"}\n"
"#extraTopMenu .QPushButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#extraTopMenu .QPushButton:pressed {	\n"
"	background-color: rgb(189, 147, 249);\n"
"	color: rgb(255, 255, 255);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Content App */\n"
"#contentTopBg{	\n"
"	background-color: rgb(33, 37, 43);\n"
"}\n"
"#contentBottom{\n"
"	border-top: 3px solid rgb(44, 49, 58);\n"
"}\n"
"\n"
"/* Top Buttons */\n"
"#rightButtons .QPushButton { background-color: rgba(255, 255, 255, 0); border: none;  border-radius: 5px; }\n"
"#rightButtons .QPushButton:hover { background-color: rgb(44, 49, 57); border-s"
                        "tyle: solid; border-radius: 4px; }\n"
"#rightButtons .QPushButton:pressed { background-color: rgb(23, 26, 30); border-style: solid; border-radius: 4px; }\n"
"\n"
"/* Theme Settings */\n"
"#extraRightBox { background-color: rgb(44, 49, 58); }\n"
"#themeSettingsTopDetail { background-color: rgb(189, 147, 249); }\n"
"\n"
"/* Bottom Bar */\n"
"#bottomBar { background-color: rgb(44, 49, 58); }\n"
"#bottomBar QLabel { font-size: 11px; color: rgb(113, 126, 149); padding-left: 10px; padding-right: 10px; padding-bottom: 2px; }\n"
"\n"
"/* CONTENT SETTINGS */\n"
"/* MENUS */\n"
"#contentSettings .QPushButton {	\n"
"	background-position: left center;\n"
"    background-repeat: no-repeat;\n"
"	border: none;\n"
"	border-left: 22px solid transparent;\n"
"	background-color:transparent;\n"
"	text-align: left;\n"
"	padding-left: 44px;\n"
"}\n"
"#contentSettings .QPushButton:hover {\n"
"	background-color: rgb(40, 44, 52);\n"
"}\n"
"#contentSettings .QPushButton:pressed {	\n"
"	background-color: rgb(189, 147, 249);\n"
"	color: r"
                        "gb(255, 255, 255);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"QTableWidget */\n"
"QTableWidget {	\n"
"	background-color: transparent;\n"
"	padding: 10px;\n"
"	border-radius: 5px;\n"
"	gridline-color: rgb(44, 49, 58);\n"
"	border-bottom: 1px solid rgb(44, 49, 60);\n"
"}\n"
"QTableWidget::item{\n"
"	border-color: rgb(44, 49, 60);\n"
"	padding-left: 5px;\n"
"	padding-right: 5px;\n"
"	gridline-color: rgb(44, 49, 60);\n"
"}\n"
"QTableWidget::item:selected{\n"
"	background-color: rgb(189, 147, 249);\n"
"}\n"
"QHeaderView::section{\n"
"	background-color: rgb(33, 37, 43);\n"
"	max-width: 30px;\n"
"	border: 1px solid rgb(44, 49, 58);\n"
"	border-style: none;\n"
"    border-bottom: 1px solid rgb(44, 49, 60);\n"
"    border-right: 1px solid rgb(44, 49, 60);\n"
"}\n"
"QTableWidget::horizontalHeader {	\n"
"	background-color: rgb(33, 37, 43);\n"
"}\n"
"QHeaderView::section:horizontal\n"
"{\n"
"    border: 1px solid rgb(33, 37, 43);\n"
"	background-"
                        "color: rgb(33, 37, 43);\n"
"	padding: 3px;\n"
"	border-top-left-radius: 7px;\n"
"    border-top-right-radius: 7px;\n"
"}\n"
"QHeaderView::section:vertical\n"
"{\n"
"    border: 1px solid rgb(44, 49, 60);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"LineEdit */\n"
"QLineEdit {\n"
"	background-color: rgb(33, 37, 43);\n"
"	border-radius: 5px;\n"
"	border: 2px solid rgb(33, 37, 43);\n"
"	padding-left: 10px;\n"
"	selection-color: rgb(255, 255, 255);\n"
"	selection-background-color: rgb(255, 121, 198);\n"
"}\n"
"QLineEdit:hover {\n"
"	border: 2px solid rgb(64, 71, 88);\n"
"}\n"
"QLineEdit:focus {\n"
"	border: 2px solid rgb(91, 101, 124);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"PlainTextEdit */\n"
"QPlainTextEdit {\n"
"	background-color: rgb(27, 29, 35);\n"
"	border-radius: 5px;\n"
"	padding: 10px;\n"
"	selection-color: rgb(255, 255, 255);\n"
"	selection-background"
                        "-color: rgb(255, 121, 198);\n"
"}\n"
"QPlainTextEdit  QScrollBar:vertical {\n"
"    width: 8px;\n"
" }\n"
"QPlainTextEdit  QScrollBar:horizontal {\n"
"    height: 8px;\n"
" }\n"
"QPlainTextEdit:hover {\n"
"	border: 2px solid rgb(64, 71, 88);\n"
"}\n"
"QPlainTextEdit:focus {\n"
"	border: 2px solid rgb(91, 101, 124);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"ScrollBars */\n"
"QScrollBar:horizontal {\n"
"    border: none;\n"
"    background: rgb(52, 59, 72);\n"
"    height: 8px;\n"
"    margin: 0px 21px 0 21px;\n"
"	border-radius: 0px;\n"
"}\n"
"QScrollBar::handle:horizontal {\n"
"    background: rgb(189, 147, 249);\n"
"    min-width: 25px;\n"
"	border-radius: 4px\n"
"}\n"
"QScrollBar::add-line:horizontal {\n"
"    border: none;\n"
"    background: rgb(55, 63, 77);\n"
"    width: 20px;\n"
"	border-top-right-radius: 4px;\n"
"    border-bottom-right-radius: 4px;\n"
"    subcontrol-position: right;\n"
"    subcontrol-origin: margin;\n"
"}\n"
""
                        "QScrollBar::sub-line:horizontal {\n"
"    border: none;\n"
"    background: rgb(55, 63, 77);\n"
"    width: 20px;\n"
"	border-top-left-radius: 4px;\n"
"    border-bottom-left-radius: 4px;\n"
"    subcontrol-position: left;\n"
"    subcontrol-origin: margin;\n"
"}\n"
"QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal\n"
"{\n"
"     background: none;\n"
"}\n"
"QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal\n"
"{\n"
"     background: none;\n"
"}\n"
" QScrollBar:vertical {\n"
"	border: none;\n"
"    background: rgb(52, 59, 72);\n"
"    width: 8px;\n"
"    margin: 21px 0 21px 0;\n"
"	border-radius: 0px;\n"
" }\n"
" QScrollBar::handle:vertical {	\n"
"	background: rgb(189, 147, 249);\n"
"    min-height: 25px;\n"
"	border-radius: 4px\n"
" }\n"
" QScrollBar::add-line:vertical {\n"
"     border: none;\n"
"    background: rgb(55, 63, 77);\n"
"     height: 20px;\n"
"	border-bottom-left-radius: 4px;\n"
"    border-bottom-right-radius: 4px;\n"
"     subcontrol-position: bottom;\n"
"     su"
                        "bcontrol-origin: margin;\n"
" }\n"
" QScrollBar::sub-line:vertical {\n"
"	border: none;\n"
"    background: rgb(55, 63, 77);\n"
"     height: 20px;\n"
"	border-top-left-radius: 4px;\n"
"    border-top-right-radius: 4px;\n"
"     subcontrol-position: top;\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
"     background: none;\n"
" }\n"
"\n"
" QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
"     background: none;\n"
" }\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"CheckBox */\n"
"QCheckBox::indicator {\n"
"    border: 3px solid rgb(52, 59, 72);\n"
"	width: 15px;\n"
"	height: 15px;\n"
"	border-radius: 10px;\n"
"    background: rgb(44, 49, 60);\n"
"}\n"
"QCheckBox::indicator:hover {\n"
"    border: 3px solid rgb(58, 66, 81);\n"
"}\n"
"QCheckBox::indicator:checked {\n"
"    background: 3px solid rgb(52, 59, 72);\n"
"	border: 3px solid rgb(52, 59, 72);	\n"
"	back"
                        "ground-image: url(:/icons/images/icons/cil-check-alt.png);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"RadioButton */\n"
"QRadioButton::indicator {\n"
"    border: 3px solid rgb(52, 59, 72);\n"
"	width: 15px;\n"
"	height: 15px;\n"
"	border-radius: 10px;\n"
"    background: rgb(44, 49, 60);\n"
"}\n"
"QRadioButton::indicator:hover {\n"
"    border: 3px solid rgb(58, 66, 81);\n"
"}\n"
"QRadioButton::indicator:checked {\n"
"    background: 3px solid rgb(94, 106, 130);\n"
"	border: 3px solid rgb(52, 59, 72);	\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"ComboBox */\n"
"QComboBox{\n"
"	background-color: rgb(27, 29, 35);\n"
"	border-radius: 5px;\n"
"	border: 2px solid rgb(33, 37, 43);\n"
"	padding: 5px;\n"
"	padding-left: 10px;\n"
"}\n"
"QComboBox:hover{\n"
"	border: 2px solid rgb(64, 71, 88);\n"
"}\n"
"QComboBox::drop-down {\n"
"	subcontrol-origin: padding;\n"
"	subco"
                        "ntrol-position: top right;\n"
"	width: 25px; \n"
"	border-left-width: 3px;\n"
"	border-left-color: rgba(39, 44, 54, 150);\n"
"	border-left-style: solid;\n"
"	border-top-right-radius: 3px;\n"
"	border-bottom-right-radius: 3px;	\n"
"	background-image: url(:/icons/images/icons/cil-arrow-bottom.png);\n"
"	background-position: center;\n"
"	background-repeat: no-reperat;\n"
" }\n"
"QComboBox QAbstractItemView {\n"
"	color: rgb(255, 121, 198);	\n"
"	background-color: rgb(33, 37, 43);\n"
"	padding: 10px;\n"
"	selection-background-color: rgb(39, 44, 54);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Sliders */\n"
"QSlider::groove:horizontal {\n"
"    border-radius: 5px;\n"
"    height: 10px;\n"
"	margin: 0px;\n"
"	background-color: rgb(52, 59, 72);\n"
"}\n"
"QSlider::groove:horizontal:hover {\n"
"	background-color: rgb(55, 62, 76);\n"
"}\n"
"QSlider::handle:horizontal {\n"
"    background-color: rgb(189, 147, 249);\n"
"    border: none;\n"
"    h"
                        "eight: 10px;\n"
"    width: 10px;\n"
"    margin: 0px;\n"
"	border-radius: 5px;\n"
"}\n"
"QSlider::handle:horizontal:hover {\n"
"    background-color: rgb(195, 155, 255);\n"
"}\n"
"QSlider::handle:horizontal:pressed {\n"
"    background-color: rgb(255, 121, 198);\n"
"}\n"
"\n"
"QSlider::groove:vertical {\n"
"    border-radius: 5px;\n"
"    width: 10px;\n"
"    margin: 0px;\n"
"	background-color: rgb(52, 59, 72);\n"
"}\n"
"QSlider::groove:vertical:hover {\n"
"	background-color: rgb(55, 62, 76);\n"
"}\n"
"QSlider::handle:vertical {\n"
"    background-color: rgb(189, 147, 249);\n"
"	border: none;\n"
"    height: 10px;\n"
"    width: 10px;\n"
"    margin: 0px;\n"
"	border-radius: 5px;\n"
"}\n"
"QSlider::handle:vertical:hover {\n"
"    background-color: rgb(195, 155, 255);\n"
"}\n"
"QSlider::handle:vertical:pressed {\n"
"    background-color: rgb(255, 121, 198);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"CommandLinkButton */\n"
"QCommandLi"
                        "nkButton {	\n"
"	color: rgb(255, 121, 198);\n"
"	border-radius: 5px;\n"
"	padding: 5px;\n"
"	color: rgb(255, 170, 255);\n"
"}\n"
"QCommandLinkButton:hover {	\n"
"	color: rgb(255, 170, 255);\n"
"	background-color: rgb(44, 49, 60);\n"
"}\n"
"QCommandLinkButton:pressed {	\n"
"	color: rgb(189, 147, 249);\n"
"	background-color: rgb(52, 58, 71);\n"
"}\n"
"\n"
"/* /////////////////////////////////////////////////////////////////////////////////////////////////\n"
"Button */\n"
"#pagesContainer QPushButton {\n"
"	border: 2px solid rgb(52, 59, 72);\n"
"	border-radius: 5px;	\n"
"	background-color: rgb(52, 59, 72);\n"
"}\n"
"#pagesContainer QPushButton:hover {\n"
"	background-color: rgb(57, 65, 80);\n"
"	border: 2px solid rgb(61, 70, 86);\n"
"}\n"
"#pagesContainer QPushButton:pressed {	\n"
"	background-color: rgb(35, 40, 49);\n"
"	border: 2px solid rgb(43, 50, 61);\n"
"}\n"
"\n"
"")
        self.appMargins = QVBoxLayout(self.styleSheet)
        self.appMargins.setSpacing(0)
        self.appMargins.setObjectName(u"appMargins")
        self.appMargins.setContentsMargins(10, 10, 10, 10)
        self.bgApp = QFrame(self.styleSheet)
        self.bgApp.setObjectName(u"bgApp")
        self.bgApp.setStyleSheet(u"")
        self.bgApp.setFrameShape(QFrame.NoFrame)
        self.appLayout = QHBoxLayout(self.bgApp)
        self.appLayout.setSpacing(0)
        self.appLayout.setObjectName(u"appLayout")
        self.appLayout.setContentsMargins(0, 0, 0, 0)
        self.leftMenuBg = QFrame(self.bgApp)
        self.leftMenuBg.setObjectName(u"leftMenuBg")
        self.leftMenuBg.setMinimumSize(QSize(60, 0))
        self.leftMenuBg.setMaximumSize(QSize(60, 16777215))
        self.leftMenuBg.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_3 = QVBoxLayout(self.leftMenuBg)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.topLogoInfo = QFrame(self.leftMenuBg)
        self.topLogoInfo.setObjectName(u"topLogoInfo")
        self.topLogoInfo.setMinimumSize(QSize(0, 50))
        self.topLogoInfo.setMaximumSize(QSize(16777215, 50))
        self.topLogoInfo.setFrameShape(QFrame.NoFrame)
        self.topLogo = QFrame(self.topLogoInfo)
        self.topLogo.setObjectName(u"topLogo")
        self.topLogo.setGeometry(QRect(10, 5, 42, 42))
        self.topLogo.setMinimumSize(QSize(42, 42))
        self.topLogo.setMaximumSize(QSize(42, 42))
        self.topLogo.setFrameShape(QFrame.NoFrame)
        self.titleLeftApp = QLabel(self.topLogoInfo)
        self.titleLeftApp.setObjectName(u"titleLeftApp")
        self.titleLeftApp.setGeometry(QRect(70, 8, 160, 20))
        font1 = QFont()
        font1.setFamily(u"Segoe UI Semibold")
        font1.setPointSize(12)
        font1.setBold(False)
        font1.setItalic(False)
        font1.setWeight(QFont.Normal)
        self.titleLeftApp.setFont(font1)
        self.titleLeftDescription = QLabel(self.topLogoInfo)
        self.titleLeftDescription.setObjectName(u"titleLeftDescription")
        self.titleLeftDescription.setGeometry(QRect(70, 27, 160, 16))
        self.titleLeftDescription.setMaximumSize(QSize(16777215, 16))
        font2 = QFont()
        font2.setFamily(u"Segoe UI")
        font2.setPointSize(8)
        font2.setBold(False)
        font2.setItalic(False)
        font2.setWeight(QFont.Normal)
        self.titleLeftDescription.setFont(font2)

        self.verticalLayout_3.addWidget(self.topLogoInfo)

        self.leftMenuFrame = QFrame(self.leftMenuBg)
        self.leftMenuFrame.setObjectName(u"leftMenuFrame")
        self.leftMenuFrame.setFrameShape(QFrame.NoFrame)
        self.verticalMenuLayout = QVBoxLayout(self.leftMenuFrame)
        self.verticalMenuLayout.setSpacing(0)
        self.verticalMenuLayout.setObjectName(u"verticalMenuLayout")
        self.verticalMenuLayout.setContentsMargins(0, 0, 0, 0)
        self.toggleBox = QFrame(self.leftMenuFrame)
        self.toggleBox.setObjectName(u"toggleBox")
        self.toggleBox.setMaximumSize(QSize(16777215, 45))
        self.toggleBox.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_4 = QVBoxLayout(self.toggleBox)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.toggleButton = QPushButton(self.toggleBox)
        self.toggleButton.setObjectName(u"toggleButton")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toggleButton.sizePolicy().hasHeightForWidth())
        self.toggleButton.setSizePolicy(sizePolicy)
        self.toggleButton.setMinimumSize(QSize(0, 45))
        self.toggleButton.setFont(font)
        self.toggleButton.setCursor(QCursor(Qt.PointingHandCursor))
        self.toggleButton.setLayoutDirection(Qt.LeftToRight)
        self.toggleButton.setStyleSheet(u"background-image: url(:/icons/images/icons/icon_menu.png);")

        self.verticalLayout_4.addWidget(self.toggleButton)


        self.verticalMenuLayout.addWidget(self.toggleBox)

        self.topMenu = QFrame(self.leftMenuFrame)
        self.topMenu.setObjectName(u"topMenu")
        self.topMenu.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_8 = QVBoxLayout(self.topMenu)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.btn_home = QPushButton(self.topMenu)
        self.btn_home.setObjectName(u"btn_home")
        sizePolicy.setHeightForWidth(self.btn_home.sizePolicy().hasHeightForWidth())
        self.btn_home.setSizePolicy(sizePolicy)
        self.btn_home.setMinimumSize(QSize(0, 45))
        self.btn_home.setFont(font)
        self.btn_home.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_home.setLayoutDirection(Qt.LeftToRight)
        self.btn_home.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-home.png);")

        self.verticalLayout_8.addWidget(self.btn_home)

        self.btn_widgets = QPushButton(self.topMenu)
        self.btn_widgets.setObjectName(u"btn_widgets")
        sizePolicy.setHeightForWidth(self.btn_widgets.sizePolicy().hasHeightForWidth())
        self.btn_widgets.setSizePolicy(sizePolicy)
        self.btn_widgets.setMinimumSize(QSize(0, 45))
        self.btn_widgets.setFont(font)
        self.btn_widgets.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_widgets.setLayoutDirection(Qt.LeftToRight)
        self.btn_widgets.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-wrap-text.png);")

        self.verticalLayout_8.addWidget(self.btn_widgets)

        self.btn_new = QPushButton(self.topMenu)
        self.btn_new.setObjectName(u"btn_new")
        sizePolicy.setHeightForWidth(self.btn_new.sizePolicy().hasHeightForWidth())
        self.btn_new.setSizePolicy(sizePolicy)
        self.btn_new.setMinimumSize(QSize(0, 45))
        self.btn_new.setFont(font)
        self.btn_new.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_new.setLayoutDirection(Qt.LeftToRight)
        self.btn_new.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-media-play.png);")

        self.verticalLayout_8.addWidget(self.btn_new)

        self.btn_save = QPushButton(self.topMenu)
        self.btn_save.setObjectName(u"btn_save")
        sizePolicy.setHeightForWidth(self.btn_save.sizePolicy().hasHeightForWidth())
        self.btn_save.setSizePolicy(sizePolicy)
        self.btn_save.setMinimumSize(QSize(0, 45))
        self.btn_save.setFont(font)
        self.btn_save.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_save.setLayoutDirection(Qt.LeftToRight)
        self.btn_save.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-media-stop.png);")

        self.verticalLayout_8.addWidget(self.btn_save)

        self.btn_exit = QPushButton(self.topMenu)
        self.btn_exit.setObjectName(u"btn_exit")
        sizePolicy.setHeightForWidth(self.btn_exit.sizePolicy().hasHeightForWidth())
        self.btn_exit.setSizePolicy(sizePolicy)
        self.btn_exit.setMinimumSize(QSize(0, 45))
        self.btn_exit.setFont(font)
        self.btn_exit.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_exit.setLayoutDirection(Qt.LeftToRight)
        self.btn_exit.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-power-standby.png);")

        self.verticalLayout_8.addWidget(self.btn_exit)

        self.btn_tasks = QPushButton(self.topMenu)
        self.btn_tasks.setObjectName(u"btn_tasks")
        sizePolicy.setHeightForWidth(self.btn_tasks.sizePolicy().hasHeightForWidth())
        self.btn_tasks.setSizePolicy(sizePolicy)
        self.btn_tasks.setMinimumSize(QSize(0, 45))
        self.btn_tasks.setFont(font)
        self.btn_tasks.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_tasks.setLayoutDirection(Qt.LeftToRight)
        self.btn_tasks.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-task.png);")

        self.verticalLayout_8.addWidget(self.btn_tasks)


        self.verticalMenuLayout.addWidget(self.topMenu)

        self.bottomMenu = QFrame(self.leftMenuFrame)
        self.bottomMenu.setObjectName(u"bottomMenu")
        self.bottomMenu.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_9 = QVBoxLayout(self.bottomMenu)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.toggleLeftBox = QPushButton(self.bottomMenu)
        self.toggleLeftBox.setObjectName(u"toggleLeftBox")
        sizePolicy.setHeightForWidth(self.toggleLeftBox.sizePolicy().hasHeightForWidth())
        self.toggleLeftBox.setSizePolicy(sizePolicy)
        self.toggleLeftBox.setMinimumSize(QSize(0, 45))
        self.toggleLeftBox.setFont(font)
        self.toggleLeftBox.setCursor(QCursor(Qt.PointingHandCursor))
        self.toggleLeftBox.setLayoutDirection(Qt.LeftToRight)
        self.toggleLeftBox.setStyleSheet(u"background-image: url(:/icons/images/icons/icon_settings.png);")

        self.verticalLayout_9.addWidget(self.toggleLeftBox)


        self.verticalMenuLayout.addWidget(self.bottomMenu)


        self.verticalLayout_3.addWidget(self.leftMenuFrame)


        self.appLayout.addWidget(self.leftMenuBg)

        self.extraLeftBox = QFrame(self.bgApp)
        self.extraLeftBox.setObjectName(u"extraLeftBox")
        self.extraLeftBox.setMinimumSize(QSize(0, 0))
        self.extraLeftBox.setMaximumSize(QSize(0, 16777215))
        self.extraLeftBox.setFrameShape(QFrame.NoFrame)
        self.extraColumLayout = QVBoxLayout(self.extraLeftBox)
        self.extraColumLayout.setSpacing(0)
        self.extraColumLayout.setObjectName(u"extraColumLayout")
        self.extraColumLayout.setContentsMargins(0, 0, 0, 0)
        self.extraTopBg = QFrame(self.extraLeftBox)
        self.extraTopBg.setObjectName(u"extraTopBg")
        self.extraTopBg.setMinimumSize(QSize(0, 50))
        self.extraTopBg.setMaximumSize(QSize(16777215, 50))
        self.extraTopBg.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_5 = QVBoxLayout(self.extraTopBg)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.extraTopLayout = QGridLayout()
        self.extraTopLayout.setObjectName(u"extraTopLayout")
        self.extraTopLayout.setHorizontalSpacing(10)
        self.extraTopLayout.setVerticalSpacing(0)
        self.extraTopLayout.setContentsMargins(10, -1, 10, -1)
        self.extraIcon = QFrame(self.extraTopBg)
        self.extraIcon.setObjectName(u"extraIcon")
        self.extraIcon.setMinimumSize(QSize(20, 0))
        self.extraIcon.setMaximumSize(QSize(20, 20))
        self.extraIcon.setFrameShape(QFrame.NoFrame)

        self.extraTopLayout.addWidget(self.extraIcon, 0, 0, 1, 1)

        self.extraLabel = QLabel(self.extraTopBg)
        self.extraLabel.setObjectName(u"extraLabel")
        self.extraLabel.setMinimumSize(QSize(150, 0))

        self.extraTopLayout.addWidget(self.extraLabel, 0, 1, 1, 1)

        self.extraCloseColumnBtn = QPushButton(self.extraTopBg)
        self.extraCloseColumnBtn.setObjectName(u"extraCloseColumnBtn")
        self.extraCloseColumnBtn.setMinimumSize(QSize(28, 28))
        self.extraCloseColumnBtn.setMaximumSize(QSize(28, 28))
        self.extraCloseColumnBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon = QIcon()
        icon.addFile(u":/icons/images/icons/icon_close.png", QSize(), QIcon.Normal, QIcon.Off)
        self.extraCloseColumnBtn.setIcon(icon)
        self.extraCloseColumnBtn.setIconSize(QSize(20, 20))

        self.extraTopLayout.addWidget(self.extraCloseColumnBtn, 0, 2, 1, 1)


        self.verticalLayout_5.addLayout(self.extraTopLayout)


        self.extraColumLayout.addWidget(self.extraTopBg)

        self.extraContent = QFrame(self.extraLeftBox)
        self.extraContent.setObjectName(u"extraContent")
        self.extraContent.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_12 = QVBoxLayout(self.extraContent)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.extraTopMenu = QFrame(self.extraContent)
        self.extraTopMenu.setObjectName(u"extraTopMenu")
        self.extraTopMenu.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_11 = QVBoxLayout(self.extraTopMenu)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.btn_share = QPushButton(self.extraTopMenu)
        self.btn_share.setObjectName(u"btn_share")
        sizePolicy.setHeightForWidth(self.btn_share.sizePolicy().hasHeightForWidth())
        self.btn_share.setSizePolicy(sizePolicy)
        self.btn_share.setMinimumSize(QSize(0, 45))
        self.btn_share.setFont(font)
        self.btn_share.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_share.setLayoutDirection(Qt.LeftToRight)
        self.btn_share.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-share-boxed.png);")

        self.verticalLayout_11.addWidget(self.btn_share)

        self.btn_adjustments = QPushButton(self.extraTopMenu)
        self.btn_adjustments.setObjectName(u"btn_adjustments")
        sizePolicy.setHeightForWidth(self.btn_adjustments.sizePolicy().hasHeightForWidth())
        self.btn_adjustments.setSizePolicy(sizePolicy)
        self.btn_adjustments.setMinimumSize(QSize(0, 45))
        self.btn_adjustments.setFont(font)
        self.btn_adjustments.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_adjustments.setLayoutDirection(Qt.LeftToRight)
        self.btn_adjustments.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-equalizer.png);")

        self.verticalLayout_11.addWidget(self.btn_adjustments)

        self.btn_more = QPushButton(self.extraTopMenu)
        self.btn_more.setObjectName(u"btn_more")
        sizePolicy.setHeightForWidth(self.btn_more.sizePolicy().hasHeightForWidth())
        self.btn_more.setSizePolicy(sizePolicy)
        self.btn_more.setMinimumSize(QSize(0, 45))
        self.btn_more.setFont(font)
        self.btn_more.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_more.setLayoutDirection(Qt.LeftToRight)
        self.btn_more.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-layers.png);")

        self.verticalLayout_11.addWidget(self.btn_more)


        self.verticalLayout_12.addWidget(self.extraTopMenu)

        self.extraCenter = QFrame(self.extraContent)
        self.extraCenter.setObjectName(u"extraCenter")
        self.extraCenter.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_10 = QVBoxLayout(self.extraCenter)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.textEdit = QTextEdit(self.extraCenter)
        self.textEdit.setObjectName(u"textEdit")
        self.textEdit.setMinimumSize(QSize(222, 0))
        self.textEdit.setStyleSheet(u"background: transparent;")
        self.textEdit.setFrameShape(QFrame.NoFrame)
        self.textEdit.setReadOnly(True)

        self.verticalLayout_10.addWidget(self.textEdit)


        self.verticalLayout_12.addWidget(self.extraCenter)

        self.extraBottom = QFrame(self.extraContent)
        self.extraBottom.setObjectName(u"extraBottom")
        self.extraBottom.setFrameShape(QFrame.NoFrame)

        self.verticalLayout_12.addWidget(self.extraBottom)


        self.extraColumLayout.addWidget(self.extraContent)


        self.appLayout.addWidget(self.extraLeftBox)

        self.contentBox = QFrame(self.bgApp)
        self.contentBox.setObjectName(u"contentBox")
        self.contentBox.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_2 = QVBoxLayout(self.contentBox)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.contentTopBg = QFrame(self.contentBox)
        self.contentTopBg.setObjectName(u"contentTopBg")
        self.contentTopBg.setMinimumSize(QSize(0, 50))
        self.contentTopBg.setMaximumSize(QSize(16777215, 50))
        self.contentTopBg.setFrameShape(QFrame.NoFrame)
        self.horizontalLayout = QHBoxLayout(self.contentTopBg)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 10, 0)
        self.leftBox = QFrame(self.contentTopBg)
        self.leftBox.setObjectName(u"leftBox")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.leftBox.sizePolicy().hasHeightForWidth())
        self.leftBox.setSizePolicy(sizePolicy1)
        self.leftBox.setFrameShape(QFrame.NoFrame)
        self.horizontalLayout_3 = QHBoxLayout(self.leftBox)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.titleRightInfo = QLabel(self.leftBox)
        self.titleRightInfo.setObjectName(u"titleRightInfo")
        sizePolicy2 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.titleRightInfo.sizePolicy().hasHeightForWidth())
        self.titleRightInfo.setSizePolicy(sizePolicy2)
        self.titleRightInfo.setMaximumSize(QSize(16777215, 45))
        self.titleRightInfo.setFont(font)

        self.horizontalLayout_3.addWidget(self.titleRightInfo)


        self.horizontalLayout.addWidget(self.leftBox)

        self.rightButtons = QFrame(self.contentTopBg)
        self.rightButtons.setObjectName(u"rightButtons")
        self.rightButtons.setMinimumSize(QSize(0, 28))
        self.rightButtons.setFrameShape(QFrame.NoFrame)
        self.horizontalLayout_2 = QHBoxLayout(self.rightButtons)
        self.horizontalLayout_2.setSpacing(5)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.settingsTopBtn = QPushButton(self.rightButtons)
        self.settingsTopBtn.setObjectName(u"settingsTopBtn")
        self.settingsTopBtn.setMinimumSize(QSize(28, 28))
        self.settingsTopBtn.setMaximumSize(QSize(28, 28))
        self.settingsTopBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon1 = QIcon()
        icon1.addFile(u":/icons/images/icons/icon_settings.png", QSize(), QIcon.Normal, QIcon.Off)
        self.settingsTopBtn.setIcon(icon1)
        self.settingsTopBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.settingsTopBtn)

        self.minimizeAppBtn = QPushButton(self.rightButtons)
        self.minimizeAppBtn.setObjectName(u"minimizeAppBtn")
        self.minimizeAppBtn.setMinimumSize(QSize(28, 28))
        self.minimizeAppBtn.setMaximumSize(QSize(28, 28))
        self.minimizeAppBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon2 = QIcon()
        icon2.addFile(u":/icons/images/icons/icon_minimize.png", QSize(), QIcon.Normal, QIcon.Off)
        self.minimizeAppBtn.setIcon(icon2)
        self.minimizeAppBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.minimizeAppBtn)

        self.maximizeRestoreAppBtn = QPushButton(self.rightButtons)
        self.maximizeRestoreAppBtn.setObjectName(u"maximizeRestoreAppBtn")
        self.maximizeRestoreAppBtn.setMinimumSize(QSize(28, 28))
        self.maximizeRestoreAppBtn.setMaximumSize(QSize(28, 28))
        font3 = QFont()
        font3.setFamily(u"Segoe UI")
        font3.setPointSize(10)
        font3.setBold(False)
        font3.setItalic(False)
        font3.setWeight(QFont.Normal)
        font3.setStyleStrategy(QFont.PreferDefault)
        self.maximizeRestoreAppBtn.setFont(font3)
        self.maximizeRestoreAppBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon3 = QIcon()
        icon3.addFile(u":/icons/images/icons/icon_maximize.png", QSize(), QIcon.Normal, QIcon.Off)
        self.maximizeRestoreAppBtn.setIcon(icon3)
        self.maximizeRestoreAppBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.maximizeRestoreAppBtn)

        self.closeAppBtn = QPushButton(self.rightButtons)
        self.closeAppBtn.setObjectName(u"closeAppBtn")
        self.closeAppBtn.setMinimumSize(QSize(28, 28))
        self.closeAppBtn.setMaximumSize(QSize(28, 28))
        self.closeAppBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.closeAppBtn.setIcon(icon)
        self.closeAppBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.closeAppBtn)


        self.horizontalLayout.addWidget(self.rightButtons)


        self.verticalLayout_2.addWidget(self.contentTopBg)

        self.contentBottom = QFrame(self.contentBox)
        self.contentBottom.setObjectName(u"contentBottom")
        self.contentBottom.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_6 = QVBoxLayout(self.contentBottom)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.content = QFrame(self.contentBottom)
        self.content.setObjectName(u"content")
        self.content.setFrameShape(QFrame.NoFrame)
        self.horizontalLayout_4 = QHBoxLayout(self.content)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.pagesContainer = QFrame(self.content)
        self.pagesContainer.setObjectName(u"pagesContainer")
        self.pagesContainer.setStyleSheet(u"")
        self.pagesContainer.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_15 = QVBoxLayout(self.pagesContainer)
        self.verticalLayout_15.setSpacing(0)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(10, 10, 10, 10)
        self.stackedWidget = QStackedWidget(self.pagesContainer)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setStyleSheet(u"background: transparent;")
        self.home = QWidget()
        self.home.setObjectName(u"home")
        self.home.setStyleSheet(u"")
        self.tabWidget = QTabWidget(self.home)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(10, 20, 1251, 631))
        self.tabWidget.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.tab_1 = QWidget()
        self.tab_1.setObjectName(u"tab_1")
        self.ChassisinformationButton = QPushButton(self.tab_1)
        self.ChassisinformationButton.setObjectName(u"ChassisinformationButton")
        self.ChassisinformationButton.setGeometry(QRect(20, 250, 82, 22))
        self.ChassisinformationButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.HeadinterruptionButton_3 = QPushButton(self.tab_1)
        self.HeadinterruptionButton_3.setObjectName(u"HeadinterruptionButton_3")
        self.HeadinterruptionButton_3.setGeometry(QRect(580, 250, 30, 22))
        self.HeadinterruptionButton_3.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.HeadmotionButton_3 = QPushButton(self.tab_1)
        self.HeadmotionButton_3.setObjectName(u"HeadmotionButton_3")
        self.HeadmotionButton_3.setGeometry(QRect(510, 250, 56, 22))
        self.HeadmotionButton_3.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.ChassistextEdit = QTextEdit(self.tab_1)
        self.ChassistextEdit.setObjectName(u"ChassistextEdit")
        self.ChassistextEdit.setGeometry(QRect(120, 250, 291, 21))
        self.LHmotionButton_4 = QPushButton(self.tab_1)
        self.LHmotionButton_4.setObjectName(u"LHmotionButton_4")
        self.LHmotionButton_4.setGeometry(QRect(440, 250, 56, 22))
        self.LHmotionButton_4.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.stardragmode = QPushButton(self.tab_1)
        self.stardragmode.setObjectName(u"stardragmode")
        self.stardragmode.setGeometry(QRect(20, 520, 82, 21))
        self.stardragmode.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.closedragmode = QPushButton(self.tab_1)
        self.closedragmode.setObjectName(u"closedragmode")
        self.closedragmode.setGeometry(QRect(110, 520, 82, 21))
        self.closedragmode.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.HeadinformationButton = QPushButton(self.tab_1)
        self.HeadinformationButton.setObjectName(u"HeadinformationButton")
        self.HeadinformationButton.setGeometry(QRect(20, 210, 82, 22))
        self.HeadinformationButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.HeadtextEdit = QTextEdit(self.tab_1)
        self.HeadtextEdit.setObjectName(u"HeadtextEdit")
        self.HeadtextEdit.setGeometry(QRect(120, 210, 291, 23))
        self.HeadmotionButton = QPushButton(self.tab_1)
        self.HeadmotionButton.setObjectName(u"HeadmotionButton")
        self.HeadmotionButton.setGeometry(QRect(440, 210, 56, 22))
        self.HeadmotionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.HeadinterruptionButton = QPushButton(self.tab_1)
        self.HeadinterruptionButton.setObjectName(u"HeadinterruptionButton")
        self.HeadinterruptionButton.setGeometry(QRect(580, 210, 30, 22))
        self.HeadinterruptionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.TrunkinformationButton = QPushButton(self.tab_1)
        self.TrunkinformationButton.setObjectName(u"TrunkinformationButton")
        self.TrunkinformationButton.setGeometry(QRect(20, 170, 82, 22))
        self.TrunkinformationButton.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"")
        self.TrunktextEdit = QTextEdit(self.tab_1)
        self.TrunktextEdit.setObjectName(u"TrunktextEdit")
        self.TrunktextEdit.setGeometry(QRect(120, 170, 291, 21))
        self.TrunkmotionButton = QPushButton(self.tab_1)
        self.TrunkmotionButton.setObjectName(u"TrunkmotionButton")
        self.TrunkmotionButton.setGeometry(QRect(440, 170, 56, 22))
        self.TrunkmotionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.TrunkinterruptionButton = QPushButton(self.tab_1)
        self.TrunkinterruptionButton.setObjectName(u"TrunkinterruptionButton")
        self.TrunkinterruptionButton.setGeometry(QRect(580, 170, 30, 22))
        self.TrunkinterruptionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.LHinformationButton = QPushButton(self.tab_1)
        self.LHinformationButton.setObjectName(u"LHinformationButton")
        self.LHinformationButton.setGeometry(QRect(20, 130, 82, 22))
        self.LHinformationButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.LHtextEdit = QTextEdit(self.tab_1)
        self.LHtextEdit.setObjectName(u"LHtextEdit")
        self.LHtextEdit.setGeometry(QRect(120, 130, 291, 21))
        self.LHmotionButton = QPushButton(self.tab_1)
        self.LHmotionButton.setObjectName(u"LHmotionButton")
        self.LHmotionButton.setGeometry(QRect(440, 130, 56, 22))
        self.LHmotionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.JLAmotionButton_4 = QPushButton(self.tab_1)
        self.JLAmotionButton_4.setObjectName(u"JLAmotionButton_4")
        self.JLAmotionButton_4.setGeometry(QRect(510, 130, 56, 22))
        self.JLAmotionButton_4.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"")
        self.LHMinterruptionButton = QPushButton(self.tab_1)
        self.LHMinterruptionButton.setObjectName(u"LHMinterruptionButton")
        self.LHMinterruptionButton.setGeometry(QRect(580, 130, 30, 22))
        self.LHMinterruptionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.RHinformationButton = QPushButton(self.tab_1)
        self.RHinformationButton.setObjectName(u"RHinformationButton")
        self.RHinformationButton.setGeometry(QRect(20, 90, 82, 22))
        self.RHinformationButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.LAinformationButton = QPushButton(self.tab_1)
        self.LAinformationButton.setObjectName(u"LAinformationButton")
        self.LAinformationButton.setGeometry(QRect(20, 50, 82, 22))
        self.LAinformationButton.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"")
        self.RAinformationButton = QPushButton(self.tab_1)
        self.RAinformationButton.setObjectName(u"RAinformationButton")
        self.RAinformationButton.setGeometry(QRect(20, 10, 82, 22))
        self.RAinformationButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.RHtextEdit = QTextEdit(self.tab_1)
        self.RHtextEdit.setObjectName(u"RHtextEdit")
        self.RHtextEdit.setGeometry(QRect(120, 90, 291, 21))
        self.RHmotionButton = QPushButton(self.tab_1)
        self.RHmotionButton.setObjectName(u"RHmotionButton")
        self.RHmotionButton.setGeometry(QRect(440, 90, 56, 22))
        self.RHmotionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.JLAmotionButton_2 = QPushButton(self.tab_1)
        self.JLAmotionButton_2.setObjectName(u"JLAmotionButton_2")
        self.JLAmotionButton_2.setGeometry(QRect(510, 90, 56, 22))
        self.JLAmotionButton_2.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"")
        self.RHMinterruptionButton = QPushButton(self.tab_1)
        self.RHMinterruptionButton.setObjectName(u"RHMinterruptionButton")
        self.RHMinterruptionButton.setGeometry(QRect(580, 90, 30, 22))
        self.RHMinterruptionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.LAtextEdit = QTextEdit(self.tab_1)
        self.LAtextEdit.setObjectName(u"LAtextEdit")
        self.LAtextEdit.setGeometry(QRect(120, 50, 291, 21))
        self.LAmotionButton = QPushButton(self.tab_1)
        self.LAmotionButton.setObjectName(u"LAmotionButton")
        self.LAmotionButton.setGeometry(QRect(440, 50, 56, 22))
        self.LAmotionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"")
        self.JLAmotionButton = QPushButton(self.tab_1)
        self.JLAmotionButton.setObjectName(u"JLAmotionButton")
        self.JLAmotionButton.setGeometry(QRect(510, 50, 56, 22))
        self.JLAmotionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"")
        self.LAMinterruptionButton = QPushButton(self.tab_1)
        self.LAMinterruptionButton.setObjectName(u"LAMinterruptionButton")
        self.LAMinterruptionButton.setGeometry(QRect(580, 50, 30, 22))
        self.LAMinterruptionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.RAtextEdit = QTextEdit(self.tab_1)
        self.RAtextEdit.setObjectName(u"RAtextEdit")
        self.RAtextEdit.setGeometry(QRect(120, 10, 291, 21))
        self.RAmotionButton = QPushButton(self.tab_1)
        self.RAmotionButton.setObjectName(u"RAmotionButton")
        self.RAmotionButton.setGeometry(QRect(440, 10, 61, 21))
        self.RAmotionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"")
        self.JRAmotionButton = QPushButton(self.tab_1)
        self.JRAmotionButton.setObjectName(u"JRAmotionButton")
        self.JRAmotionButton.setGeometry(QRect(510, 10, 61, 21))
        self.JRAmotionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.RAMinterruptionButton = QPushButton(self.tab_1)
        self.RAMinterruptionButton.setObjectName(u"RAMinterruptionButton")
        self.RAMinterruptionButton.setGeometry(QRect(580, 10, 31, 21))
        self.RAMinterruptionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.dragstatus = QLabel(self.tab_1)
        self.dragstatus.setObjectName(u"dragstatus")
        self.dragstatus.setGeometry(QRect(80, 490, 53, 15))
        self.tabWidget.addTab(self.tab_1, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.label_2 = QLabel(self.tab_2)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(480, 10, 211, 561))
        self.label_2.setTextFormat(Qt.PlainText)
        self.label_2.setPixmap(QPixmap(u":/images/W1.png"))
        self.groupBox = QGroupBox(self.tab_2)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(160, 140, 311, 141))
        self.LAXPButton = QPushButton(self.groupBox)
        self.LAXPButton.setObjectName(u"LAXPButton")
        self.LAXPButton.setGeometry(QRect(10, 40, 40, 40))
        self.LAYPButton = QPushButton(self.groupBox)
        self.LAYPButton.setObjectName(u"LAYPButton")
        self.LAYPButton.setGeometry(QRect(60, 40, 40, 40))
        self.LAZPButton = QPushButton(self.groupBox)
        self.LAZPButton.setObjectName(u"LAZPButton")
        self.LAZPButton.setGeometry(QRect(110, 40, 40, 40))
        self.LARXPButton = QPushButton(self.groupBox)
        self.LARXPButton.setObjectName(u"LARXPButton")
        self.LARXPButton.setGeometry(QRect(160, 40, 40, 40))
        self.LARYPButton = QPushButton(self.groupBox)
        self.LARYPButton.setObjectName(u"LARYPButton")
        self.LARYPButton.setGeometry(QRect(210, 40, 40, 40))
        self.LARZPButton = QPushButton(self.groupBox)
        self.LARZPButton.setObjectName(u"LARZPButton")
        self.LARZPButton.setGeometry(QRect(260, 40, 40, 40))
        self.LAXRButton = QPushButton(self.groupBox)
        self.LAXRButton.setObjectName(u"LAXRButton")
        self.LAXRButton.setGeometry(QRect(10, 90, 40, 40))
        self.LAYRButton = QPushButton(self.groupBox)
        self.LAYRButton.setObjectName(u"LAYRButton")
        self.LAYRButton.setGeometry(QRect(60, 90, 40, 40))
        self.LAZRButton = QPushButton(self.groupBox)
        self.LAZRButton.setObjectName(u"LAZRButton")
        self.LAZRButton.setGeometry(QRect(110, 90, 40, 40))
        self.LARXRButton = QPushButton(self.groupBox)
        self.LARXRButton.setObjectName(u"LARXRButton")
        self.LARXRButton.setGeometry(QRect(160, 90, 40, 40))
        self.LARYRButton = QPushButton(self.groupBox)
        self.LARYRButton.setObjectName(u"LARYRButton")
        self.LARYRButton.setGeometry(QRect(210, 90, 40, 40))
        self.LARZRButton = QPushButton(self.groupBox)
        self.LARZRButton.setObjectName(u"LARZRButton")
        self.LARZRButton.setGeometry(QRect(260, 90, 40, 40))
        self.label_3 = QLabel(self.groupBox)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(25, 20, 20, 20))
        self.label_4 = QLabel(self.groupBox)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(75, 20, 20, 20))
        self.label_5 = QLabel(self.groupBox)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(125, 20, 20, 20))
        self.label_6 = QLabel(self.groupBox)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(175, 20, 20, 20))
        self.label_7 = QLabel(self.groupBox)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(225, 20, 20, 20))
        self.label_8 = QLabel(self.groupBox)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(275, 20, 20, 20))
        self.groupBox_2 = QGroupBox(self.tab_2)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.groupBox_2.setGeometry(QRect(710, 140, 311, 141))
        self.pushButton_13 = QPushButton(self.groupBox_2)
        self.pushButton_13.setObjectName(u"pushButton_13")
        self.pushButton_13.setGeometry(QRect(10, 40, 40, 40))
        self.pushButton_14 = QPushButton(self.groupBox_2)
        self.pushButton_14.setObjectName(u"pushButton_14")
        self.pushButton_14.setGeometry(QRect(60, 40, 40, 40))
        self.pushButton_15 = QPushButton(self.groupBox_2)
        self.pushButton_15.setObjectName(u"pushButton_15")
        self.pushButton_15.setGeometry(QRect(110, 40, 40, 40))
        self.pushButton_16 = QPushButton(self.groupBox_2)
        self.pushButton_16.setObjectName(u"pushButton_16")
        self.pushButton_16.setGeometry(QRect(160, 40, 40, 40))
        self.pushButton_17 = QPushButton(self.groupBox_2)
        self.pushButton_17.setObjectName(u"pushButton_17")
        self.pushButton_17.setGeometry(QRect(210, 40, 40, 40))
        self.pushButton_18 = QPushButton(self.groupBox_2)
        self.pushButton_18.setObjectName(u"pushButton_18")
        self.pushButton_18.setGeometry(QRect(260, 40, 40, 40))
        self.pushButton_19 = QPushButton(self.groupBox_2)
        self.pushButton_19.setObjectName(u"pushButton_19")
        self.pushButton_19.setGeometry(QRect(10, 90, 40, 40))
        self.pushButton_20 = QPushButton(self.groupBox_2)
        self.pushButton_20.setObjectName(u"pushButton_20")
        self.pushButton_20.setGeometry(QRect(60, 90, 40, 40))
        self.pushButton_21 = QPushButton(self.groupBox_2)
        self.pushButton_21.setObjectName(u"pushButton_21")
        self.pushButton_21.setGeometry(QRect(110, 90, 40, 40))
        self.pushButton_22 = QPushButton(self.groupBox_2)
        self.pushButton_22.setObjectName(u"pushButton_22")
        self.pushButton_22.setGeometry(QRect(160, 90, 40, 40))
        self.pushButton_23 = QPushButton(self.groupBox_2)
        self.pushButton_23.setObjectName(u"pushButton_23")
        self.pushButton_23.setGeometry(QRect(210, 90, 40, 40))
        self.pushButton_24 = QPushButton(self.groupBox_2)
        self.pushButton_24.setObjectName(u"pushButton_24")
        self.pushButton_24.setGeometry(QRect(260, 90, 40, 40))
        self.label_9 = QLabel(self.groupBox_2)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(25, 20, 20, 20))
        self.label_10 = QLabel(self.groupBox_2)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(75, 20, 20, 20))
        self.label_11 = QLabel(self.groupBox_2)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(125, 20, 20, 20))
        self.label_12 = QLabel(self.groupBox_2)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setGeometry(QRect(175, 20, 20, 20))
        self.label_13 = QLabel(self.groupBox_2)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setGeometry(QRect(225, 20, 20, 20))
        self.label_14 = QLabel(self.groupBox_2)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setGeometry(QRect(275, 20, 20, 20))
        self.groupBox_3 = QGroupBox(self.tab_2)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.groupBox_3.setGeometry(QRect(360, 0, 111, 141))
        self.HeadRPButton = QPushButton(self.groupBox_3)
        self.HeadRPButton.setObjectName(u"HeadRPButton")
        self.HeadRPButton.setGeometry(QRect(10, 40, 40, 40))
        self.HeadPPButton = QPushButton(self.groupBox_3)
        self.HeadPPButton.setObjectName(u"HeadPPButton")
        self.HeadPPButton.setGeometry(QRect(60, 40, 40, 40))
        self.HeadRRButton = QPushButton(self.groupBox_3)
        self.HeadRRButton.setObjectName(u"HeadRRButton")
        self.HeadRRButton.setGeometry(QRect(10, 90, 40, 40))
        self.HeadPRButton = QPushButton(self.groupBox_3)
        self.HeadPRButton.setObjectName(u"HeadPRButton")
        self.HeadPRButton.setGeometry(QRect(60, 90, 40, 40))
        self.label_15 = QLabel(self.groupBox_3)
        self.label_15.setObjectName(u"label_15")
        self.label_15.setGeometry(QRect(25, 20, 20, 20))
        self.label_16 = QLabel(self.groupBox_3)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setGeometry(QRect(75, 20, 20, 20))
        self.groupBox_4 = QGroupBox(self.tab_2)
        self.groupBox_4.setObjectName(u"groupBox_4")
        self.groupBox_4.setGeometry(QRect(160, 280, 311, 141))
        self.pushButton_37 = QPushButton(self.groupBox_4)
        self.pushButton_37.setObjectName(u"pushButton_37")
        self.pushButton_37.setGeometry(QRect(10, 40, 40, 40))
        self.pushButton_38 = QPushButton(self.groupBox_4)
        self.pushButton_38.setObjectName(u"pushButton_38")
        self.pushButton_38.setGeometry(QRect(60, 40, 40, 40))
        self.pushButton_39 = QPushButton(self.groupBox_4)
        self.pushButton_39.setObjectName(u"pushButton_39")
        self.pushButton_39.setGeometry(QRect(110, 40, 40, 40))
        self.pushButton_40 = QPushButton(self.groupBox_4)
        self.pushButton_40.setObjectName(u"pushButton_40")
        self.pushButton_40.setGeometry(QRect(160, 40, 40, 40))
        self.pushButton_41 = QPushButton(self.groupBox_4)
        self.pushButton_41.setObjectName(u"pushButton_41")
        self.pushButton_41.setGeometry(QRect(210, 40, 40, 40))
        self.pushButton_42 = QPushButton(self.groupBox_4)
        self.pushButton_42.setObjectName(u"pushButton_42")
        self.pushButton_42.setGeometry(QRect(260, 40, 40, 40))
        self.pushButton_43 = QPushButton(self.groupBox_4)
        self.pushButton_43.setObjectName(u"pushButton_43")
        self.pushButton_43.setGeometry(QRect(10, 90, 40, 40))
        self.pushButton_44 = QPushButton(self.groupBox_4)
        self.pushButton_44.setObjectName(u"pushButton_44")
        self.pushButton_44.setGeometry(QRect(60, 90, 40, 40))
        self.pushButton_45 = QPushButton(self.groupBox_4)
        self.pushButton_45.setObjectName(u"pushButton_45")
        self.pushButton_45.setGeometry(QRect(110, 90, 40, 40))
        self.pushButton_46 = QPushButton(self.groupBox_4)
        self.pushButton_46.setObjectName(u"pushButton_46")
        self.pushButton_46.setGeometry(QRect(160, 90, 40, 40))
        self.pushButton_47 = QPushButton(self.groupBox_4)
        self.pushButton_47.setObjectName(u"pushButton_47")
        self.pushButton_47.setGeometry(QRect(210, 90, 40, 40))
        self.pushButton_48 = QPushButton(self.groupBox_4)
        self.pushButton_48.setObjectName(u"pushButton_48")
        self.pushButton_48.setGeometry(QRect(260, 90, 40, 40))
        self.label_21 = QLabel(self.groupBox_4)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setGeometry(QRect(25, 20, 20, 20))
        self.label_22 = QLabel(self.groupBox_4)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setGeometry(QRect(75, 20, 20, 20))
        self.label_23 = QLabel(self.groupBox_4)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setGeometry(QRect(125, 20, 20, 20))
        self.label_24 = QLabel(self.groupBox_4)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setGeometry(QRect(175, 20, 20, 20))
        self.label_25 = QLabel(self.groupBox_4)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setGeometry(QRect(225, 20, 20, 20))
        self.label_26 = QLabel(self.groupBox_4)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setGeometry(QRect(275, 20, 20, 20))
        self.groupBox_5 = QGroupBox(self.tab_2)
        self.groupBox_5.setObjectName(u"groupBox_5")
        self.groupBox_5.setGeometry(QRect(710, 280, 311, 141))
        self.pushButton_49 = QPushButton(self.groupBox_5)
        self.pushButton_49.setObjectName(u"pushButton_49")
        self.pushButton_49.setGeometry(QRect(10, 40, 40, 40))
        self.pushButton_50 = QPushButton(self.groupBox_5)
        self.pushButton_50.setObjectName(u"pushButton_50")
        self.pushButton_50.setGeometry(QRect(60, 40, 40, 40))
        self.pushButton_51 = QPushButton(self.groupBox_5)
        self.pushButton_51.setObjectName(u"pushButton_51")
        self.pushButton_51.setGeometry(QRect(110, 40, 40, 40))
        self.pushButton_52 = QPushButton(self.groupBox_5)
        self.pushButton_52.setObjectName(u"pushButton_52")
        self.pushButton_52.setGeometry(QRect(160, 40, 40, 40))
        self.pushButton_53 = QPushButton(self.groupBox_5)
        self.pushButton_53.setObjectName(u"pushButton_53")
        self.pushButton_53.setGeometry(QRect(210, 40, 40, 40))
        self.pushButton_54 = QPushButton(self.groupBox_5)
        self.pushButton_54.setObjectName(u"pushButton_54")
        self.pushButton_54.setGeometry(QRect(260, 40, 40, 40))
        self.pushButton_55 = QPushButton(self.groupBox_5)
        self.pushButton_55.setObjectName(u"pushButton_55")
        self.pushButton_55.setGeometry(QRect(10, 90, 40, 40))
        self.pushButton_56 = QPushButton(self.groupBox_5)
        self.pushButton_56.setObjectName(u"pushButton_56")
        self.pushButton_56.setGeometry(QRect(60, 90, 40, 40))
        self.pushButton_57 = QPushButton(self.groupBox_5)
        self.pushButton_57.setObjectName(u"pushButton_57")
        self.pushButton_57.setGeometry(QRect(110, 90, 40, 40))
        self.pushButton_58 = QPushButton(self.groupBox_5)
        self.pushButton_58.setObjectName(u"pushButton_58")
        self.pushButton_58.setGeometry(QRect(160, 90, 40, 40))
        self.pushButton_59 = QPushButton(self.groupBox_5)
        self.pushButton_59.setObjectName(u"pushButton_59")
        self.pushButton_59.setGeometry(QRect(210, 90, 40, 40))
        self.pushButton_60 = QPushButton(self.groupBox_5)
        self.pushButton_60.setObjectName(u"pushButton_60")
        self.pushButton_60.setGeometry(QRect(260, 90, 40, 40))
        self.label_27 = QLabel(self.groupBox_5)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setGeometry(QRect(25, 20, 20, 20))
        self.label_28 = QLabel(self.groupBox_5)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setGeometry(QRect(75, 20, 20, 20))
        self.label_29 = QLabel(self.groupBox_5)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setGeometry(QRect(125, 20, 20, 20))
        self.label_30 = QLabel(self.groupBox_5)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setGeometry(QRect(175, 20, 20, 20))
        self.label_31 = QLabel(self.groupBox_5)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setGeometry(QRect(225, 20, 20, 20))
        self.label_32 = QLabel(self.groupBox_5)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setGeometry(QRect(275, 20, 20, 20))
        self.groupBox_6 = QGroupBox(self.tab_2)
        self.groupBox_6.setObjectName(u"groupBox_6")
        self.groupBox_6.setGeometry(QRect(710, 430, 211, 141))
        self.pushButton_61 = QPushButton(self.groupBox_6)
        self.pushButton_61.setObjectName(u"pushButton_61")
        self.pushButton_61.setGeometry(QRect(10, 40, 40, 40))
        self.pushButton_62 = QPushButton(self.groupBox_6)
        self.pushButton_62.setObjectName(u"pushButton_62")
        self.pushButton_62.setGeometry(QRect(60, 40, 40, 40))
        self.pushButton_63 = QPushButton(self.groupBox_6)
        self.pushButton_63.setObjectName(u"pushButton_63")
        self.pushButton_63.setGeometry(QRect(110, 40, 40, 40))
        self.pushButton_64 = QPushButton(self.groupBox_6)
        self.pushButton_64.setObjectName(u"pushButton_64")
        self.pushButton_64.setGeometry(QRect(160, 40, 40, 40))
        self.pushButton_67 = QPushButton(self.groupBox_6)
        self.pushButton_67.setObjectName(u"pushButton_67")
        self.pushButton_67.setGeometry(QRect(10, 90, 40, 40))
        self.pushButton_68 = QPushButton(self.groupBox_6)
        self.pushButton_68.setObjectName(u"pushButton_68")
        self.pushButton_68.setGeometry(QRect(60, 90, 40, 40))
        self.pushButton_69 = QPushButton(self.groupBox_6)
        self.pushButton_69.setObjectName(u"pushButton_69")
        self.pushButton_69.setGeometry(QRect(110, 90, 40, 40))
        self.pushButton_70 = QPushButton(self.groupBox_6)
        self.pushButton_70.setObjectName(u"pushButton_70")
        self.pushButton_70.setGeometry(QRect(160, 90, 40, 40))
        self.label_33 = QLabel(self.groupBox_6)
        self.label_33.setObjectName(u"label_33")
        self.label_33.setGeometry(QRect(25, 20, 20, 20))
        self.label_34 = QLabel(self.groupBox_6)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setGeometry(QRect(75, 20, 20, 20))
        self.label_35 = QLabel(self.groupBox_6)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setGeometry(QRect(125, 20, 20, 20))
        self.label_36 = QLabel(self.groupBox_6)
        self.label_36.setObjectName(u"label_36")
        self.label_36.setGeometry(QRect(175, 20, 20, 20))
        self.groupBox_7 = QGroupBox(self.tab_2)
        self.groupBox_7.setObjectName(u"groupBox_7")
        self.groupBox_7.setGeometry(QRect(310, 430, 161, 141))
        self.pushButton_85 = QPushButton(self.groupBox_7)
        self.pushButton_85.setObjectName(u"pushButton_85")
        self.pushButton_85.setGeometry(QRect(10, 40, 40, 40))
        self.pushButton_86 = QPushButton(self.groupBox_7)
        self.pushButton_86.setObjectName(u"pushButton_86")
        self.pushButton_86.setGeometry(QRect(60, 40, 40, 40))
        self.pushButton_87 = QPushButton(self.groupBox_7)
        self.pushButton_87.setObjectName(u"pushButton_87")
        self.pushButton_87.setGeometry(QRect(110, 40, 40, 40))
        self.pushButton_89 = QPushButton(self.groupBox_7)
        self.pushButton_89.setObjectName(u"pushButton_89")
        self.pushButton_89.setGeometry(QRect(10, 90, 40, 40))
        self.pushButton_90 = QPushButton(self.groupBox_7)
        self.pushButton_90.setObjectName(u"pushButton_90")
        self.pushButton_90.setGeometry(QRect(60, 90, 40, 40))
        self.pushButton_91 = QPushButton(self.groupBox_7)
        self.pushButton_91.setObjectName(u"pushButton_91")
        self.pushButton_91.setGeometry(QRect(110, 90, 40, 40))
        self.label_45 = QLabel(self.groupBox_7)
        self.label_45.setObjectName(u"label_45")
        self.label_45.setGeometry(QRect(25, 20, 20, 20))
        self.label_46 = QLabel(self.groupBox_7)
        self.label_46.setObjectName(u"label_46")
        self.label_46.setGeometry(QRect(75, 20, 20, 20))
        self.label_47 = QLabel(self.groupBox_7)
        self.label_47.setObjectName(u"label_47")
        self.label_47.setGeometry(QRect(125, 20, 20, 20))
        self.groupBox_12 = QGroupBox(self.tab_2)
        self.groupBox_12.setObjectName(u"groupBox_12")
        self.groupBox_12.setGeometry(QRect(710, 0, 471, 141))
        self.label_50 = QLabel(self.groupBox_12)
        self.label_50.setObjectName(u"label_50")
        self.label_50.setGeometry(QRect(10, 20, 53, 15))
        self.label_51 = QLabel(self.groupBox_12)
        self.label_51.setObjectName(u"label_51")
        self.label_51.setGeometry(QRect(10, 40, 53, 15))
        self.label_52 = QLabel(self.groupBox_12)
        self.label_52.setObjectName(u"label_52")
        self.label_52.setGeometry(QRect(10, 60, 53, 15))
        self.label_53 = QLabel(self.groupBox_12)
        self.label_53.setObjectName(u"label_53")
        self.label_53.setGeometry(QRect(10, 80, 53, 15))
        self.label_54 = QLabel(self.groupBox_12)
        self.label_54.setObjectName(u"label_54")
        self.label_54.setGeometry(QRect(10, 100, 53, 15))
        self.label_55 = QLabel(self.groupBox_12)
        self.label_55.setObjectName(u"label_55")
        self.label_55.setGeometry(QRect(10, 120, 53, 15))
        self.label_56 = QLabel(self.groupBox_12)
        self.label_56.setObjectName(u"label_56")
        self.label_56.setGeometry(QRect(40, 20, 53, 15))
        self.label_57 = QLabel(self.groupBox_12)
        self.label_57.setObjectName(u"label_57")
        self.label_57.setGeometry(QRect(40, 40, 53, 16))
        self.label_58 = QLabel(self.groupBox_12)
        self.label_58.setObjectName(u"label_58")
        self.label_58.setGeometry(QRect(40, 60, 53, 16))
        self.label_59 = QLabel(self.groupBox_12)
        self.label_59.setObjectName(u"label_59")
        self.label_59.setGeometry(QRect(40, 80, 53, 16))
        self.label_60 = QLabel(self.groupBox_12)
        self.label_60.setObjectName(u"label_60")
        self.label_60.setGeometry(QRect(40, 100, 53, 16))
        self.label_61 = QLabel(self.groupBox_12)
        self.label_61.setObjectName(u"label_61")
        self.label_61.setGeometry(QRect(40, 120, 53, 16))
        self.tabWidget.addTab(self.tab_2, "")
        self.groupBox.raise_()
        self.groupBox_2.raise_()
        self.groupBox_3.raise_()
        self.groupBox_4.raise_()
        self.groupBox_5.raise_()
        self.groupBox_6.raise_()
        self.groupBox_7.raise_()
        self.label_2.raise_()
        self.groupBox_12.raise_()
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.groupBox_10 = QGroupBox(self.tab_3)
        self.groupBox_10.setObjectName(u"groupBox_10")
        self.groupBox_10.setGeometry(QRect(20, 10, 581, 561))
        self.pointlistWidget = QListWidget(self.groupBox_10)
        self.pointlistWidget.setObjectName(u"pointlistWidget")
        self.pointlistWidget.setGeometry(QRect(10, 60, 181, 491))
        self.pointcomboBox = QComboBox(self.groupBox_10)
        self.pointcomboBox.addItem("")
        self.pointcomboBox.addItem("")
        self.pointcomboBox.addItem("")
        self.pointcomboBox.addItem("")
        self.pointcomboBox.addItem("")
        self.pointcomboBox.addItem("")
        self.pointcomboBox.setObjectName(u"pointcomboBox")
        self.pointcomboBox.setGeometry(QRect(10, 20, 181, 31))
        self.groupBox_9 = QGroupBox(self.groupBox_10)
        self.groupBox_9.setObjectName(u"groupBox_9")
        self.groupBox_9.setGeometry(QRect(210, 20, 361, 531))
        self.groupBox_9.setMouseTracking(False)
        self.groupBox_9.setAcceptDrops(True)
        self.label_40 = QLabel(self.groupBox_9)
        self.label_40.setObjectName(u"label_40")
        self.label_40.setGeometry(QRect(140, 20, 61, 31))
        self.label_40.setFont(font)
        self.label_41 = QLabel(self.groupBox_9)
        self.label_41.setObjectName(u"label_41")
        self.label_41.setGeometry(QRect(70, 70, 61, 31))
        self.label_41.setFont(font)
        self.label_42 = QLabel(self.groupBox_9)
        self.label_42.setObjectName(u"label_42")
        self.label_42.setGeometry(QRect(160, 70, 61, 31))
        self.label_42.setFont(font)
        self.label_43 = QLabel(self.groupBox_9)
        self.label_43.setObjectName(u"label_43")
        self.label_43.setGeometry(QRect(260, 70, 61, 31))
        self.label_43.setFont(font)
        self.label_44 = QLabel(self.groupBox_9)
        self.label_44.setObjectName(u"label_44")
        self.label_44.setGeometry(QRect(70, 140, 61, 31))
        self.label_44.setFont(font)
        self.label_48 = QLabel(self.groupBox_9)
        self.label_48.setObjectName(u"label_48")
        self.label_48.setGeometry(QRect(160, 140, 61, 31))
        self.label_48.setFont(font)
        self.label_49 = QLabel(self.groupBox_9)
        self.label_49.setObjectName(u"label_49")
        self.label_49.setGeometry(QRect(260, 140, 61, 31))
        self.label_49.setFont(font)
        self.XPC = QTextEdit(self.groupBox_9)
        self.XPC.setObjectName(u"XPC")
        self.XPC.setGeometry(QRect(40, 100, 71, 31))
        self.XPC.setStyleSheet(u"color: rgb(255, 0, 0); /* \u8bbe\u7f6e\u5b57\u4f53\u989c\u8272\u4e3a\u7ea2\u8272 */")
        self.YPC = QTextEdit(self.groupBox_9)
        self.YPC.setObjectName(u"YPC")
        self.YPC.setGeometry(QRect(130, 100, 71, 31))
        self.YPC.setStyleSheet(u"color: rgb(255, 0, 0); /* \u8bbe\u7f6e\u5b57\u4f53\u989c\u8272\u4e3a\u7ea2\u8272 */")
        self.ZPC = QTextEdit(self.groupBox_9)
        self.ZPC.setObjectName(u"ZPC")
        self.ZPC.setGeometry(QRect(230, 100, 71, 31))
        self.ZPC.setStyleSheet(u"color: rgb(255, 0, 0); /* \u8bbe\u7f6e\u5b57\u4f53\u989c\u8272\u4e3a\u7ea2\u8272 */")
        self.RXPC = QTextEdit(self.groupBox_9)
        self.RXPC.setObjectName(u"RXPC")
        self.RXPC.setGeometry(QRect(40, 170, 71, 31))
        self.RXPC.setStyleSheet(u"color: rgb(255, 0, 0); /* \u8bbe\u7f6e\u5b57\u4f53\u989c\u8272\u4e3a\u7ea2\u8272 */")
        self.RYPC = QTextEdit(self.groupBox_9)
        self.RYPC.setObjectName(u"RYPC")
        self.RYPC.setGeometry(QRect(130, 170, 71, 31))
        self.RYPC.setStyleSheet(u"color: rgb(255, 0, 0); /* \u8bbe\u7f6e\u5b57\u4f53\u989c\u8272\u4e3a\u7ea2\u8272 */")
        self.RZPC = QTextEdit(self.groupBox_9)
        self.RZPC.setObjectName(u"RZPC")
        self.RZPC.setGeometry(QRect(230, 170, 71, 31))
        self.RZPC.setStyleSheet(u"color: rgb(255, 0, 0); /* \u8bbe\u7f6e\u5b57\u4f53\u989c\u8272\u4e3a\u7ea2\u8272 */")
        self.ChangePointButton = QPushButton(self.groupBox_9)
        self.ChangePointButton.setObjectName(u"ChangePointButton")
        self.ChangePointButton.setGeometry(QRect(110, 250, 111, 21))
        self.ChangePointButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.DeletePointButton = QPushButton(self.groupBox_9)
        self.DeletePointButton.setObjectName(u"DeletePointButton")
        self.DeletePointButton.setGeometry(QRect(110, 290, 111, 21))
        self.DeletePointButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.AddPointButton = QPushButton(self.groupBox_9)
        self.AddPointButton.setObjectName(u"AddPointButton")
        self.AddPointButton.setGeometry(QRect(110, 330, 111, 21))
        self.AddPointButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.MovePointButton = QPushButton(self.groupBox_9)
        self.MovePointButton.setObjectName(u"MovePointButton")
        self.MovePointButton.setGeometry(QRect(110, 370, 111, 21))
        self.MovePointButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.GetPointButton = QPushButton(self.groupBox_9)
        self.GetPointButton.setObjectName(u"GetPointButton")
        self.GetPointButton.setGeometry(QRect(110, 410, 111, 21))
        self.GetPointButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.groupBox_11 = QGroupBox(self.tab_3)
        self.groupBox_11.setObjectName(u"groupBox_11")
        self.groupBox_11.setGeometry(QRect(620, 10, 561, 561))
        self.TasklistWidget = QListWidget(self.groupBox_11)
        self.TasklistWidget.setObjectName(u"TasklistWidget")
        self.TasklistWidget.setGeometry(QRect(10, 30, 411, 521))
        self.StartTaskButton = QPushButton(self.groupBox_11)
        self.StartTaskButton.setObjectName(u"StartTaskButton")
        self.StartTaskButton.setGeometry(QRect(430, 30, 121, 21))
        self.StartTaskButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.EndTaskButton = QPushButton(self.groupBox_11)
        self.EndTaskButton.setObjectName(u"EndTaskButton")
        self.EndTaskButton.setGeometry(QRect(430, 60, 121, 21))
        self.EndTaskButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.VisionButton = QPushButton(self.groupBox_11)
        self.VisionButton.setObjectName(u"VisionButton")
        self.VisionButton.setGeometry(QRect(430, 160, 121, 21))
        self.VisionButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.StartPickwizButton = QPushButton(self.groupBox_11)
        self.StartPickwizButton.setObjectName(u"StartPickwizButton")
        self.StartPickwizButton.setGeometry(QRect(430, 190, 121, 21))
        self.StartPickwizButton.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.visionstatus = QLabel(self.groupBox_11)
        self.visionstatus.setObjectName(u"visionstatus")
        self.visionstatus.setGeometry(QRect(460, 220, 53, 15))
        self.Taskstatus = QLabel(self.tab_3)
        self.Taskstatus.setObjectName(u"Taskstatus")
        self.Taskstatus.setGeometry(QRect(1080, 100, 53, 15))
        self.tabWidget.addTab(self.tab_3, "")
        self.stackedWidget.addWidget(self.home)
        self.task_page = QWidget()
        self.task_page.setObjectName(u"task_page")
        self.task_main_hlayout = QHBoxLayout(self.task_page)
        self.task_main_hlayout.setSpacing(12)
        self.task_main_hlayout.setObjectName(u"task_main_hlayout")
        self.task_main_hlayout.setContentsMargins(10, 10, 10, 10)
        self.task_list_frame = QFrame(self.task_page)
        self.task_list_frame.setObjectName(u"task_list_frame")
        self.task_list_frame.setFrameShape(QFrame.NoFrame)
        self.task_list_layout = QVBoxLayout(self.task_list_frame)
        self.task_list_layout.setSpacing(6)
        self.task_list_layout.setObjectName(u"task_list_layout")
        self.task_list_layout.setContentsMargins(0, 0, 0, 0)
        self.taskListWidget = QListWidget(self.task_list_frame)
        self.taskListWidget.setObjectName(u"taskListWidget")
        self.taskListWidget.setMinimumSize(QSize(300, 0))

        self.task_list_layout.addWidget(self.taskListWidget)


        self.task_main_hlayout.addWidget(self.task_list_frame)

        self.task_right_frame = QFrame(self.task_page)
        self.task_right_frame.setObjectName(u"task_right_frame")
        self.task_right_frame.setFrameShape(QFrame.NoFrame)
        self.task_right_layout = QVBoxLayout(self.task_right_frame)
        self.task_right_layout.setSpacing(8)
        self.task_right_layout.setObjectName(u"task_right_layout")
        self.task_right_layout.setContentsMargins(0, 0, 0, 0)
        self.label_task_name = QLabel(self.task_right_frame)
        self.label_task_name.setObjectName(u"label_task_name")

        self.task_right_layout.addWidget(self.label_task_name)

        self.taskNameEdit = QLineEdit(self.task_right_frame)
        self.taskNameEdit.setObjectName(u"taskNameEdit")

        self.task_right_layout.addWidget(self.taskNameEdit)

        self.label_nav_point = QLabel(self.task_right_frame)
        self.label_nav_point.setObjectName(u"label_nav_point")

        self.task_right_layout.addWidget(self.label_nav_point)

        self.navPointEdit = QTextEdit(self.task_right_frame)
        self.navPointEdit.setObjectName(u"navPointEdit")
        self.navPointEdit.setMaximumSize(QSize(16777215, 80))

        self.task_right_layout.addWidget(self.navPointEdit)

        self.spacer_motion = QSpacerItem(20, 10, QSizePolicy.Minimum, QSizePolicy.Fixed)

        self.task_right_layout.addItem(self.spacer_motion)

        self.label_motion_type = QLabel(self.task_right_frame)
        self.label_motion_type.setObjectName(u"label_motion_type")

        self.task_right_layout.addWidget(self.label_motion_type)

        self.motionTypeComboBox = QComboBox(self.task_right_frame)
        self.motionTypeComboBox.addItem("")
        self.motionTypeComboBox.addItem("")
        self.motionTypeComboBox.setObjectName(u"motionTypeComboBox")

        self.task_right_layout.addWidget(self.motionTypeComboBox)

        self.spacer_buttons = QSpacerItem(20, 65, QSizePolicy.Minimum, QSizePolicy.Fixed)

        self.task_right_layout.addItem(self.spacer_buttons)

        self.conf_row = QHBoxLayout()
        self.conf_row.setSpacing(8)
        self.conf_row.setObjectName(u"conf_row")
        self.confirmTaskButton = QPushButton(self.task_right_frame)
        self.confirmTaskButton.setObjectName(u"confirmTaskButton")
        self.confirmTaskButton.setMinimumSize(QSize(90, 28))

        self.conf_row.addWidget(self.confirmTaskButton)

        self.cancelTaskButton = QPushButton(self.task_right_frame)
        self.cancelTaskButton.setObjectName(u"cancelTaskButton")
        self.cancelTaskButton.setMinimumSize(QSize(90, 28))

        self.conf_row.addWidget(self.cancelTaskButton)


        self.task_right_layout.addLayout(self.conf_row)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.task_right_layout.addItem(self.verticalSpacer)

        self.eventSelectButton = QPushButton(self.task_right_frame)
        self.eventSelectButton.setObjectName(u"eventSelectButton")
        self.eventSelectButton.setMinimumSize(QSize(120, 28))

        self.task_right_layout.addWidget(self.eventSelectButton)

        self.eventSelectionFrame = QFrame(self.task_right_frame)
        self.eventSelectionFrame.setObjectName(u"eventSelectionFrame")
        self.eventSelectionFrame.setVisible(False)
        self.eventSelectionFrame.setFrameShape(QFrame.StyledPanel)
        self.eventSelectionLayout = QVBoxLayout(self.eventSelectionFrame)
        self.eventSelectionLayout.setSpacing(6)
        self.eventSelectionLayout.setObjectName(u"eventSelectionLayout")
        self.eventSelectionLayout.setContentsMargins(4, 4, 4, 4)
        self.eventListWidget = QListWidget(self.eventSelectionFrame)
        self.eventListWidget.setObjectName(u"eventListWidget")
        self.eventListWidget.setSelectionMode(QAbstractItemView.MultiSelection)

        self.eventSelectionLayout.addWidget(self.eventListWidget)

        self.eventButtonsRow = QHBoxLayout()
        self.eventButtonsRow.setObjectName(u"eventButtonsRow")
        self.eventConfirmButton = QPushButton(self.eventSelectionFrame)
        self.eventConfirmButton.setObjectName(u"eventConfirmButton")
        self.eventConfirmButton.setMinimumSize(QSize(90, 28))

        self.eventButtonsRow.addWidget(self.eventConfirmButton)

        self.eventCancelButton = QPushButton(self.eventSelectionFrame)
        self.eventCancelButton.setObjectName(u"eventCancelButton")
        self.eventCancelButton.setMinimumSize(QSize(90, 28))

        self.eventButtonsRow.addWidget(self.eventCancelButton)


        self.eventSelectionLayout.addLayout(self.eventButtonsRow)


        self.task_right_layout.addWidget(self.eventSelectionFrame)

        self.action_row = QHBoxLayout()
        self.action_row.setSpacing(8)
        self.action_row.setObjectName(u"action_row")
        self.addTaskButton = QPushButton(self.task_right_frame)
        self.addTaskButton.setObjectName(u"addTaskButton")
        self.addTaskButton.setMinimumSize(QSize(110, 32))

        self.action_row.addWidget(self.addTaskButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.action_row.addItem(self.horizontalSpacer)

        self.emergencyStopButton = QPushButton(self.task_right_frame)
        self.emergencyStopButton.setObjectName(u"emergencyStopButton")
        self.emergencyStopButton.setMinimumSize(QSize(110, 32))

        self.action_row.addWidget(self.emergencyStopButton)


        self.task_right_layout.addLayout(self.action_row)


        self.task_main_hlayout.addWidget(self.task_right_frame)

        self.stackedWidget.addWidget(self.task_page)
        self.widgets = QWidget()
        self.widgets.setObjectName(u"widgets")
        self.widgets.setStyleSheet(u"b")
        self.verticalLayout = QVBoxLayout(self.widgets)
        self.verticalLayout.setSpacing(10)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(10, 10, 10, 10)
        self.row_1 = QFrame(self.widgets)
        self.row_1.setObjectName(u"row_1")
        self.row_1.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_16 = QVBoxLayout(self.row_1)
        self.verticalLayout_16.setSpacing(0)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.frame_div_content_1 = QFrame(self.row_1)
        self.frame_div_content_1.setObjectName(u"frame_div_content_1")
        self.frame_div_content_1.setMinimumSize(QSize(0, 110))
        self.frame_div_content_1.setMaximumSize(QSize(16777215, 110))
        self.frame_div_content_1.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_17 = QVBoxLayout(self.frame_div_content_1)
        self.verticalLayout_17.setSpacing(0)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_17.setContentsMargins(0, 0, 0, 0)
        self.frame_title_wid_1 = QFrame(self.frame_div_content_1)
        self.frame_title_wid_1.setObjectName(u"frame_title_wid_1")
        self.frame_title_wid_1.setMaximumSize(QSize(16777215, 35))
        self.frame_title_wid_1.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_18 = QVBoxLayout(self.frame_title_wid_1)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")

        self.verticalLayout_17.addWidget(self.frame_title_wid_1)


        self.verticalLayout_16.addWidget(self.frame_div_content_1)


        self.verticalLayout.addWidget(self.row_1)

        self.row_3 = QFrame(self.widgets)
        self.row_3.setObjectName(u"row_3")
        self.row_3.setMinimumSize(QSize(0, 150))
        self.row_3.setFrameShape(QFrame.NoFrame)
        self.horizontalLayout_12 = QHBoxLayout(self.row_3)
        self.horizontalLayout_12.setSpacing(0)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout.addWidget(self.row_3)

        self.stackedWidget.addWidget(self.widgets)
        self.new_page = QWidget()
        self.new_page.setObjectName(u"new_page")
        self.verticalLayout_20 = QVBoxLayout(self.new_page)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.label = QLabel(self.new_page)
        self.label.setObjectName(u"label")

        self.verticalLayout_20.addWidget(self.label)

        self.stackedWidget.addWidget(self.new_page)

        self.verticalLayout_15.addWidget(self.stackedWidget)


        self.horizontalLayout_4.addWidget(self.pagesContainer)

        self.extraRightBox = QFrame(self.content)
        self.extraRightBox.setObjectName(u"extraRightBox")
        self.extraRightBox.setMinimumSize(QSize(0, 0))
        self.extraRightBox.setMaximumSize(QSize(0, 16777215))
        self.extraRightBox.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_7 = QVBoxLayout(self.extraRightBox)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.themeSettingsTopDetail = QFrame(self.extraRightBox)
        self.themeSettingsTopDetail.setObjectName(u"themeSettingsTopDetail")
        self.themeSettingsTopDetail.setMaximumSize(QSize(16777215, 3))
        self.themeSettingsTopDetail.setFrameShape(QFrame.NoFrame)

        self.verticalLayout_7.addWidget(self.themeSettingsTopDetail)

        self.contentSettings = QFrame(self.extraRightBox)
        self.contentSettings.setObjectName(u"contentSettings")
        self.contentSettings.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_13 = QVBoxLayout(self.contentSettings)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(0, 0, 0, 0)
        self.topMenus = QFrame(self.contentSettings)
        self.topMenus.setObjectName(u"topMenus")
        self.topMenus.setFrameShape(QFrame.NoFrame)
        self.verticalLayout_14 = QVBoxLayout(self.topMenus)
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(0, 0, 0, 0)
        self.btn_message = QPushButton(self.topMenus)
        self.btn_message.setObjectName(u"btn_message")
        sizePolicy.setHeightForWidth(self.btn_message.sizePolicy().hasHeightForWidth())
        self.btn_message.setSizePolicy(sizePolicy)
        self.btn_message.setMinimumSize(QSize(0, 45))
        self.btn_message.setFont(font)
        self.btn_message.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_message.setLayoutDirection(Qt.LeftToRight)
        self.btn_message.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-envelope-open.png);")

        self.verticalLayout_14.addWidget(self.btn_message)

        self.btn_print = QPushButton(self.topMenus)
        self.btn_print.setObjectName(u"btn_print")
        sizePolicy.setHeightForWidth(self.btn_print.sizePolicy().hasHeightForWidth())
        self.btn_print.setSizePolicy(sizePolicy)
        self.btn_print.setMinimumSize(QSize(0, 45))
        self.btn_print.setFont(font)
        self.btn_print.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_print.setLayoutDirection(Qt.LeftToRight)
        self.btn_print.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-print.png);")

        self.verticalLayout_14.addWidget(self.btn_print)

        self.btn_logout = QPushButton(self.topMenus)
        self.btn_logout.setObjectName(u"btn_logout")
        sizePolicy.setHeightForWidth(self.btn_logout.sizePolicy().hasHeightForWidth())
        self.btn_logout.setSizePolicy(sizePolicy)
        self.btn_logout.setMinimumSize(QSize(0, 45))
        self.btn_logout.setFont(font)
        self.btn_logout.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_logout.setLayoutDirection(Qt.LeftToRight)
        self.btn_logout.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-account-logout.png);")

        self.verticalLayout_14.addWidget(self.btn_logout)

        self.btn_tasks1 = QPushButton(self.topMenus)
        self.btn_tasks1.setObjectName(u"btn_tasks1")
        sizePolicy.setHeightForWidth(self.btn_tasks1.sizePolicy().hasHeightForWidth())
        self.btn_tasks1.setSizePolicy(sizePolicy)
        self.btn_tasks1.setMinimumSize(QSize(0, 45))
        self.btn_tasks1.setFont(font)
        self.btn_tasks1.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_tasks1.setLayoutDirection(Qt.LeftToRight)
        self.btn_tasks1.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-task.png);")

        self.verticalLayout_14.addWidget(self.btn_tasks1)


        self.verticalLayout_13.addWidget(self.topMenus)


        self.verticalLayout_7.addWidget(self.contentSettings)


        self.horizontalLayout_4.addWidget(self.extraRightBox)


        self.verticalLayout_6.addWidget(self.content)

        self.bottomBar = QFrame(self.contentBottom)
        self.bottomBar.setObjectName(u"bottomBar")
        self.bottomBar.setMinimumSize(QSize(0, 22))
        self.bottomBar.setMaximumSize(QSize(16777215, 22))
        self.bottomBar.setFrameShape(QFrame.NoFrame)
        self.horizontalLayout_5 = QHBoxLayout(self.bottomBar)
        self.horizontalLayout_5.setSpacing(0)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.creditsLabel = QLabel(self.bottomBar)
        self.creditsLabel.setObjectName(u"creditsLabel")
        self.creditsLabel.setMaximumSize(QSize(16777215, 16))
        font4 = QFont()
        font4.setFamily(u"Segoe UI")
        font4.setBold(False)
        font4.setItalic(False)
        font4.setWeight(QFont.Normal)
        self.creditsLabel.setFont(font4)

        self.horizontalLayout_5.addWidget(self.creditsLabel)

        self.version = QLabel(self.bottomBar)
        self.version.setObjectName(u"version")

        self.horizontalLayout_5.addWidget(self.version)

        self.frame_size_grip = QFrame(self.bottomBar)
        self.frame_size_grip.setObjectName(u"frame_size_grip")
        self.frame_size_grip.setMinimumSize(QSize(20, 0))
        self.frame_size_grip.setMaximumSize(QSize(20, 16777215))
        self.frame_size_grip.setFrameShape(QFrame.NoFrame)

        self.horizontalLayout_5.addWidget(self.frame_size_grip)


        self.verticalLayout_6.addWidget(self.bottomBar)


        self.verticalLayout_2.addWidget(self.contentBottom)


        self.appLayout.addWidget(self.contentBox)


        self.appMargins.addWidget(self.bgApp)

        MainWindow.setCentralWidget(self.styleSheet)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(1)
        self.tabWidget.setCurrentIndex(2)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.titleLeftApp.setText(QCoreApplication.translate("MainWindow", u"DexFroce W1", None))
        self.titleLeftDescription.setText(QCoreApplication.translate("MainWindow", u"Modern GUI / Flat Style", None))
        self.toggleButton.setText("")
        self.btn_home.setText(QCoreApplication.translate("MainWindow", u"\u5de5\u4f5c\u53f0", None))
        self.btn_widgets.setText(QCoreApplication.translate("MainWindow", u"\u52a8\u4f5c\u914d\u7f6e", None))
        self.btn_new.setText(QCoreApplication.translate("MainWindow", u"\u542f\u52a8", None))
        self.btn_save.setText(QCoreApplication.translate("MainWindow", u"\u7ec8\u6b62", None))
        self.btn_exit.setText(QCoreApplication.translate("MainWindow", u"\u5173\u673a", None))
        self.btn_tasks.setText(QCoreApplication.translate("MainWindow", u"\u4efb\u52a1", None))
        self.toggleLeftBox.setText(QCoreApplication.translate("MainWindow", u"\u8bbe\u7f6e", None))
        self.extraLabel.setText(QCoreApplication.translate("MainWindow", u"Left Box", None))
#if QT_CONFIG(tooltip)
        self.extraCloseColumnBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Close left box", None))
#endif // QT_CONFIG(tooltip)
        self.extraCloseColumnBtn.setText("")
        self.btn_share.setText(QCoreApplication.translate("MainWindow", u"Share", None))
        self.btn_adjustments.setText(QCoreApplication.translate("MainWindow", u"Adjustments", None))
        self.btn_more.setText(QCoreApplication.translate("MainWindow", u"More", None))
        self.textEdit.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#ffaa00;\">DexForce W1 Pro</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#ffffff;\">An interface created using Python and PySide (support for PyQt), and with colors based on the Dracula theme created by Zeno Rocha.</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0p"
                        "x;\"><span style=\" color:#ffffff;\">MIT License</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#bd93f9;\">Created by: Wanderson M. Pimenta</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#ff79c6;\">Convert UI</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt; color:#ffffff;\">pyside6-uic main.ui &gt; ui_main.py</span></p>\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#ff79c6;\">Convert QRC</span></p>\n"
"<p align=\"center\" style=\" margin-top:"
                        "12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt; color:#ffffff;\">pyside6-rcc resources.qrc -o resources_rc.py</span></p></body></html>", None))
        self.titleRightInfo.setText(QCoreApplication.translate("MainWindow", u"DexForce W1 Pro APP - Towards a General Physical World Intelligence", None))
#if QT_CONFIG(tooltip)
        self.settingsTopBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Settings", None))
#endif // QT_CONFIG(tooltip)
        self.settingsTopBtn.setText("")
#if QT_CONFIG(tooltip)
        self.minimizeAppBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Minimize", None))
#endif // QT_CONFIG(tooltip)
        self.minimizeAppBtn.setText("")
#if QT_CONFIG(tooltip)
        self.maximizeRestoreAppBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Maximize", None))
#endif // QT_CONFIG(tooltip)
        self.maximizeRestoreAppBtn.setText("")
#if QT_CONFIG(tooltip)
        self.closeAppBtn.setToolTip(QCoreApplication.translate("MainWindow", u"Close", None))
#endif // QT_CONFIG(tooltip)
        self.closeAppBtn.setText("")
        self.ChassisinformationButton.setText(QCoreApplication.translate("MainWindow", u"\u83b7\u53d6\u5e95\u76d8\u4fe1\u606f", None))
        self.HeadinterruptionButton_3.setText(QCoreApplication.translate("MainWindow", u"\u4e2d\u65ad", None))
        self.HeadmotionButton_3.setText(QCoreApplication.translate("MainWindow", u"\u63a7\u5236\u8fd0\u52a8", None))
        self.LHmotionButton_4.setText(QCoreApplication.translate("MainWindow", u"\u5bfc\u822a\u8fd0\u52a8", None))
        self.stardragmode.setText(QCoreApplication.translate("MainWindow", u"\u5f00\u542f\u62d6\u62fd", None))
        self.closedragmode.setText(QCoreApplication.translate("MainWindow", u"\u5173\u95ed\u62d6\u62fd", None))
        self.HeadinformationButton.setText(QCoreApplication.translate("MainWindow", u"\u83b7\u53d6\u5934\u90e8\u4fe1\u606f", None))
        self.HeadmotionButton.setText(QCoreApplication.translate("MainWindow", u"\u5934\u90e8\u8fd0\u52a8", None))
        self.HeadinterruptionButton.setText(QCoreApplication.translate("MainWindow", u"\u4e2d\u65ad", None))
        self.TrunkinformationButton.setText(QCoreApplication.translate("MainWindow", u"\u83b7\u53d6\u8eaf\u5e72\u4fe1\u606f", None))
        self.TrunkmotionButton.setText(QCoreApplication.translate("MainWindow", u"\u8eaf\u5e72\u8fd0\u52a8", None))
        self.TrunkinterruptionButton.setText(QCoreApplication.translate("MainWindow", u"\u4e2d\u65ad", None))
        self.LHinformationButton.setText(QCoreApplication.translate("MainWindow", u"\u83b7\u53d6\u5de6\u624b\u4fe1\u606f", None))
        self.LHmotionButton.setText(QCoreApplication.translate("MainWindow", u"\u5de5\u5177\u8fd0\u52a8", None))
        self.JLAmotionButton_4.setText(QCoreApplication.translate("MainWindow", u"\u5de6\u624b\u8fd0\u52a8", None))
        self.LHMinterruptionButton.setText(QCoreApplication.translate("MainWindow", u"\u4e2d\u65ad", None))
        self.RHinformationButton.setText(QCoreApplication.translate("MainWindow", u"\u83b7\u53d6\u53f3\u624b\u4fe1\u606f", None))
        self.LAinformationButton.setText(QCoreApplication.translate("MainWindow", u"\u83b7\u53d6\u5de6\u81c2\u4fe1\u606f", None))
        self.RAinformationButton.setText(QCoreApplication.translate("MainWindow", u"\u83b7\u53d6\u53f3\u81c2\u4fe1\u606f", None))
        self.RHmotionButton.setText(QCoreApplication.translate("MainWindow", u"\u5de5\u5177\u8fd0\u52a8", None))
        self.JLAmotionButton_2.setText(QCoreApplication.translate("MainWindow", u"\u53f3\u624b\u8fd0\u52a8", None))
        self.RHMinterruptionButton.setText(QCoreApplication.translate("MainWindow", u"\u4e2d\u65ad", None))
        self.LAmotionButton.setText(QCoreApplication.translate("MainWindow", u"\u5de5\u5177\u8fd0\u52a8", None))
        self.JLAmotionButton.setText(QCoreApplication.translate("MainWindow", u"\u5de6\u81c2\u8fd0\u52a8", None))
        self.LAMinterruptionButton.setText(QCoreApplication.translate("MainWindow", u"\u4e2d\u65ad", None))
        self.RAmotionButton.setText(QCoreApplication.translate("MainWindow", u"\u5de5\u5177\u8fd0\u52a8", None))
        self.JRAmotionButton.setText(QCoreApplication.translate("MainWindow", u"\u53f3\u81c2\u8fd0\u52a8", None))
        self.RAMinterruptionButton.setText(QCoreApplication.translate("MainWindow", u"\u4e2d\u65ad", None))
        self.dragstatus.setText(QCoreApplication.translate("MainWindow", u"\u62d6\u62fd\u72b6\u6001", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_1), QCoreApplication.translate("MainWindow", u"\u5750\u6807\u79fb\u52a8", None))
        self.label_2.setText("")
        self.groupBox.setTitle(QCoreApplication.translate("MainWindow", u"\u5de6\u81c2", None))
        self.LAXPButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.LAYPButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.LAZPButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.LARXPButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.LARYPButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.LARZPButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.LAXRButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.LAYRButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.LAZRButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.LARXRButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.LARYRButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.LARZRButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Y", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Z", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"RX", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"RY", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"RZ", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("MainWindow", u"\u53f3\u81c2", None))
        self.pushButton_13.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_14.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_15.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_16.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_17.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_18.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_19.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_20.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_21.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_22.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_23.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_24.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Y", None))
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"Z", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"RX", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", u"RY", None))
        self.label_14.setText(QCoreApplication.translate("MainWindow", u"RZ", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("MainWindow", u"\u5934\u90e8", None))
        self.HeadRPButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.HeadPPButton.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.HeadRRButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.HeadPRButton.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.label_15.setText(QCoreApplication.translate("MainWindow", u"R", None))
        self.label_16.setText(QCoreApplication.translate("MainWindow", u"P", None))
        self.groupBox_4.setTitle(QCoreApplication.translate("MainWindow", u"\u5de6\u624b", None))
        self.pushButton_37.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_38.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_39.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_40.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_41.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_42.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_43.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_44.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_45.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_46.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_47.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_48.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.label_21.setText(QCoreApplication.translate("MainWindow", u"1", None))
        self.label_22.setText(QCoreApplication.translate("MainWindow", u"2", None))
        self.label_23.setText(QCoreApplication.translate("MainWindow", u"3", None))
        self.label_24.setText(QCoreApplication.translate("MainWindow", u"4", None))
        self.label_25.setText(QCoreApplication.translate("MainWindow", u"5", None))
        self.label_26.setText(QCoreApplication.translate("MainWindow", u"6", None))
        self.groupBox_5.setTitle(QCoreApplication.translate("MainWindow", u"\u53f3\u624b", None))
        self.pushButton_49.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_50.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_51.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_52.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_53.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_54.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_55.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_56.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_57.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_58.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_59.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_60.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.label_27.setText(QCoreApplication.translate("MainWindow", u"1", None))
        self.label_28.setText(QCoreApplication.translate("MainWindow", u"2", None))
        self.label_29.setText(QCoreApplication.translate("MainWindow", u"3", None))
        self.label_30.setText(QCoreApplication.translate("MainWindow", u"4", None))
        self.label_31.setText(QCoreApplication.translate("MainWindow", u"5", None))
        self.label_32.setText(QCoreApplication.translate("MainWindow", u"6", None))
        self.groupBox_6.setTitle(QCoreApplication.translate("MainWindow", u"\u8eaf\u5e72", None))
        self.pushButton_61.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_62.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_63.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_64.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_67.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_68.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_69.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_70.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.label_33.setText(QCoreApplication.translate("MainWindow", u"1", None))
        self.label_34.setText(QCoreApplication.translate("MainWindow", u"2", None))
        self.label_35.setText(QCoreApplication.translate("MainWindow", u"3", None))
        self.label_36.setText(QCoreApplication.translate("MainWindow", u"4", None))
        self.groupBox_7.setTitle(QCoreApplication.translate("MainWindow", u"\u5e95\u76d8", None))
        self.pushButton_85.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_86.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_87.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.pushButton_89.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_90.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.pushButton_91.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.label_45.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.label_46.setText(QCoreApplication.translate("MainWindow", u"Y", None))
        self.label_47.setText(QCoreApplication.translate("MainWindow", u"T", None))
        self.groupBox_12.setTitle(QCoreApplication.translate("MainWindow", u"W1\u4f4d\u7f6e\u4fe1\u606f", None))
        self.label_50.setText(QCoreApplication.translate("MainWindow", u"\u5de6\u81c2", None))
        self.label_51.setText(QCoreApplication.translate("MainWindow", u"\u53f3\u81c2", None))
        self.label_52.setText(QCoreApplication.translate("MainWindow", u"\u5de6\u624b", None))
        self.label_53.setText(QCoreApplication.translate("MainWindow", u"\u53f3\u624b", None))
        self.label_54.setText(QCoreApplication.translate("MainWindow", u"\u5934\u90e8", None))
        self.label_55.setText(QCoreApplication.translate("MainWindow", u"\u8eaf\u5e72", None))
        self.label_56.setText(QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_57.setText(QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_58.setText(QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_59.setText(QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_60.setText(QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_61.setText(QCoreApplication.translate("MainWindow", u"[]", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"\u6309\u94ae\u79fb\u52a8", None))
        self.groupBox_10.setTitle(QCoreApplication.translate("MainWindow", u"\u70b9\u4f4d", None))
        self.pointcomboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"\u5de6\u81c2", None))
        self.pointcomboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"\u53f3\u81c2", None))
        self.pointcomboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"\u5de6\u624b", None))
        self.pointcomboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"\u53f3\u624b", None))
        self.pointcomboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"\u5934\u90e8", None))
        self.pointcomboBox.setItemText(5, QCoreApplication.translate("MainWindow", u"\u8eaf\u5e72", None))

        self.groupBox_9.setTitle("")
        self.label_40.setText(QCoreApplication.translate("MainWindow", u"\u70b9\u4f4d\u540d\u79f0 ", None))
        self.label_41.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.label_42.setText(QCoreApplication.translate("MainWindow", u"Y", None))
        self.label_43.setText(QCoreApplication.translate("MainWindow", u"Z", None))
        self.label_44.setText(QCoreApplication.translate("MainWindow", u"RX", None))
        self.label_48.setText(QCoreApplication.translate("MainWindow", u"RY", None))
        self.label_49.setText(QCoreApplication.translate("MainWindow", u"RZ", None))
        self.ChangePointButton.setText(QCoreApplication.translate("MainWindow", u"\u66f4\u6539", None))
        self.DeletePointButton.setText(QCoreApplication.translate("MainWindow", u"\u5220\u9664", None))
        self.AddPointButton.setText(QCoreApplication.translate("MainWindow", u"\u6dfb\u52a0", None))
        self.MovePointButton.setText(QCoreApplication.translate("MainWindow", u"\u79fb\u52a8\u5230\u5f53\u524d\u70b9\u4f4d", None))
        self.GetPointButton.setText(QCoreApplication.translate("MainWindow", u"\u83b7\u53d6\u5f53\u524d\u5750\u6807", None))
        self.groupBox_11.setTitle(QCoreApplication.translate("MainWindow", u"\u4efb\u52a1", None))
        self.StartTaskButton.setText(QCoreApplication.translate("MainWindow", u"\u5f00\u59cb\u4efb\u52a1", None))
        self.EndTaskButton.setText(QCoreApplication.translate("MainWindow", u"\u4e2d\u65ad\u4efb\u52a1", None))
        self.VisionButton.setText(QCoreApplication.translate("MainWindow", u"\u8fde\u63a5\u89c6\u89c9", None))
        self.StartPickwizButton.setText(QCoreApplication.translate("MainWindow", u"\u542f\u52a8pickwiz", None))
        self.visionstatus.setText(QCoreApplication.translate("MainWindow", u"\u89c6\u89c9\u72b6\u6001", None))
        self.Taskstatus.setText(QCoreApplication.translate("MainWindow", u"\u4efb\u52a1\u72b6\u6001", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), QCoreApplication.translate("MainWindow", u"\u5feb\u6377\u79fb\u52a8", None))
        self.label_task_name.setText(QCoreApplication.translate("MainWindow", u"\u4efb\u52a1\u540d\u79f0", None))
        self.taskNameEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"\u4efb\u52a1\u540d\u79f0", None))
        self.label_nav_point.setText(QCoreApplication.translate("MainWindow", u"\u5bfc\u822a/\u63a7\u5236\u70b9(x, y, z)", None))
        self.navPointEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"x, y, z", None))
        self.label_motion_type.setText(QCoreApplication.translate("MainWindow", u"\u5e95\u76d8\u8fd0\u52a8\u65b9\u5f0f", None))
        self.motionTypeComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"\u5bfc\u822a\u8fd0\u52a8", None))
        self.motionTypeComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"\u63a7\u5236\u8fd0\u52a8", None))
        self.confirmTaskButton.setText(QCoreApplication.translate("MainWindow", u"\u786e\u8ba4", None))
        self.cancelTaskButton.setText(QCoreApplication.translate("MainWindow", u"\u53d6\u6d88", None))
        self.eventSelectButton.setText(QCoreApplication.translate("MainWindow", u"\u9009\u62e9\u4e8b\u4ef6", None))
        self.eventConfirmButton.setText(QCoreApplication.translate("MainWindow", u"\u786e\u8ba4\u9009\u62e9", None))
        self.eventCancelButton.setText(QCoreApplication.translate("MainWindow", u"\u53d6\u6d88", None))
        self.addTaskButton.setText(QCoreApplication.translate("MainWindow", u"\u6dfb\u52a0\u4efb\u52a1", None))
        self.emergencyStopButton.setText(QCoreApplication.translate("MainWindow", u"\u7d27\u6025\u505c\u6b62", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"NEW PAGE TEST", None))
        self.btn_message.setText(QCoreApplication.translate("MainWindow", u"Message", None))
        self.btn_print.setText(QCoreApplication.translate("MainWindow", u"Print", None))
        self.btn_logout.setText(QCoreApplication.translate("MainWindow", u"Logout", None))
        self.btn_tasks1.setText(QCoreApplication.translate("MainWindow", u"\u4efb\u52a1", None))
        self.creditsLabel.setText(QCoreApplication.translate("MainWindow", u"By: DexForce Technology co.,Ltd.", None))
        self.version.setText(QCoreApplication.translate("MainWindow", u"v1.0.3", None))
    # retranslateUi

