import threading

from typing import Callable, List, Any, Optional, Dict, Union

import ctypes
import inspect

import logging
import json
import os

from basic_function import *
from log import *

from PySide6.QtCore import Qt,QThread, Signal,QTimer
from PySide6.QtWidgets import QFileDialog,QMainWindow,QPushButton,QListWidget,\
                            QMessageBox,QDialog,QWidget,QGroupBox,QProgressDialog, \
                            QVBoxLayout, QLineEdit, QLabel,QHBoxLayout,QGraphicsDropShadowEffect,QApplication, QRadioButton,QCheckBox,QButtonGroup


global logger
logger = Logger(
        name="MyApp",
        level="DEBUG",
        log_dir="app_logs",
        console_output=True,
        file_output=True,
        max_file_size=5 * 1024 * 1024,  # 5MB
        backup_count=3
        )


class Initialize:
    def __init__(self):
        pass
    @staticmethod
    def load_json_config(file_path: str, desc: str = "配置文件") -> dict:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data
        except FileNotFoundError:
            logging.error(f"{desc}未找到: {file_path}")
            raise
        except json.JSONDecodeError as e:
            msg = f"{desc} JSON 格式错误: {e}, 出错文件:{file_path}"
            logging.error(msg)
            print(msg)
            raise
    @staticmethod
    def load_config(confile: str) -> dict:
        """
        加载指定路径的 JSON 配置文件, 并返回其内容的字典对象。
        参数:
            confile (str): 配置文件的路径, 必须为字符串类型。
        返回:
            dict: 配置文件内容对应的字典对象。
        异常:
            TypeError: 如果 confile 不是字符串类型, 或读取内容不是字典类型时抛出。
            FileNotFoundError: 如果指定的文件不存在时抛出。
            json.JSONDecodeError: 如果文件内容不是合法的 JSON 时抛出。
        """
        def clear_vision_app_msg(data):
            for pose_name in data['vision_app_pose']:
                data['vision_app_pose'][pose_name]['left_arm'] = "None"
                data['vision_app_pose'][pose_name]['right_arm'] = "None"
            with open(vision_app_pose_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            # 日志: 加载主配置
            if log_msg.get("clear_vision_app_msg", [None, 0])[1] == 1:
                logging.info(log_msg["clear_vision_app_msg config"][0].format())
            return data

        if not isinstance(confile, str):
            raise TypeError("confile 参数必须为字符串类型")

        # 读取主配置文件
        device_data = Initialize.load_json_config(confile, "主配置文件")

        # 获取日志消息
        language = device_data['log']["language"]
        log_msg = device_data['log'][language]

        # 获取各子配置文件路径
        current_dir = os.path.dirname(os.path.abspath(__file__)) + '/parameters'
        parameter_path = os.path.join(current_dir, device_data['config_path']['parameter_path'])
        task_path = os.path.join(current_dir, device_data['config_path']['task_path'])
        calibration_path = os.path.join(current_dir, device_data['config_path']['calibration_config_path'])
        vision_app_pose_path = os.path.join(current_dir, device_data['config_path']['vision_app_pose_path'])

        # 读取各子配置文件
        task_config = Initialize.load_json_config(task_path, "任务配置文件")
        parameter_config = Initialize.load_json_config(parameter_path, "参数配置文件")
        calibration_config = Initialize.load_json_config(calibration_path, "标定配置文件")
        vision_app_pose_config = Initialize.load_json_config(vision_app_pose_path, "vision_app信息初始化")

        # 日志: 加载成功
        if log_msg.get("load_config_success", [None, 0])[1] == 1:
            logging.info(log_msg["load_config_success"][0].format(
                device_data['config_path']['task_path'],
                device_data['config_path']['parameter_path'],
                device_data['config_path']['calibration_config_path']
            ))

        # 返回包含所有配置的字典
        config = {
            "log_msg": log_msg,
            "task_cfg": task_config,
            "parameter_cfg": parameter_config,
            "calibration_cfg": calibration_config,
            "device_cfg": device_data,
            "vision_app_pose_cfg": vision_app_pose_config
        }
        return config
    
    def Create_robot_communication(self):
     
     """创建机器人通信"""  
            
    # 加载新配置

     file_path = os.path.join(os.path.dirname(__file__), 'parameters', 'device.json')

     self.config = Initialize.load_config(file_path)
     self.log_msg = self.config["log_msg"]
     self.device_cfg = self.config['device_cfg']
     self.calibration_cfg = self.config['calibration_cfg']
     self.parameter_cfg = self.config['parameter_cfg']
     self.task_cfg = self.config['task_cfg']['work_sequence']
     self.vision_app = VisionApp(self.config)        
                
     try:
        global w1
        w1 = RobotApp(self.config['log_msg'], self.vision_app, self.parameter_cfg, self.config)
        logger.info("创建机器人通信成功")  
        from basic_function import Function
        function = Function(self.config, self.vision_app, w1)
        return w1,function,self.vision_app, self.device_cfg         
     except Exception as e:
        logger.info("创建机器人通信失败")
        logger.error(e)
        return None, None, None, None



class ThreadManager:
      
      def __init__(self, name: str = "ThreadManager"):
           self._lock = threading.Lock()
           self.name = name
           self.threads: List[threading.Thread] = []
           self.results = {}        
           
    
      def create_thread(self, 
                     target: Callable, 
                     args: tuple = (), 
                     kwargs: dict = None,
                     name: str = None,
                     daemon: bool = False) -> threading.Thread:
        """
        创建线程
        
        Args:
            target: 目标函数
            args: 位置参数
            kwargs: 关键字参数
            name: 线程名称
            daemon: 是否设置为守护线程
            
        Returns:
            threading.Thread: 创建的线程对象
        """
        if kwargs is None:
            kwargs = {}
        
        thread_name = name or f"{self.name}_Thread_{len(self.threads) + 1}"
        
        thread = threading.Thread(
            target=target,
            args=args,
            kwargs=kwargs,
            name=thread_name,
            daemon=daemon
        )
        
        with self._lock:
            self.threads.append(thread)
        
        logger.info(f"创建线程: {thread_name}")
        return thread
      
      def start_thread(self, thread: threading.Thread):
        """启动单个线程"""
        if thread in self.threads:
            thread.start()
            logger.info(f"启动线程: {thread.name}")
        else:
            logger.info(f"线程未在管理器中注册: {thread.name}")


      def stop_thread(self, thread: threading.Thread):
          tid=thread.ident
          exctype=SystemExit
          tid = ctypes.c_long(tid)
          if not inspect.isclass(exctype):
              exctype = type(exctype)
          res = ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, ctypes.py_object(exctype))
          if res == 0:        
              raise ValueError("invalid thread id")
          elif res != 1:           
              ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)
              raise SystemError("PyThreadState_SetAsyncExc failed")
                    
class Json:
    def read_simple_json(self, file_path=None):
        if file_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            file_path = os.path.join(current_dir, 'parameters', 'test.json')
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
        return data
    
    def write_simple_json(self, file_path=None, data=None):
        if file_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            file_path = os.path.join(current_dir, 'parameters', 'test.json')
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, ensure_ascii=False, indent=4)
        return True
    
class one_task_th(QThread):
    update_signal = Signal(str)
    def __init__(self,vision_app,function,tpose_name):
        super().__init__()
        self.vision_app =vision_app
        self.function = function
        self.tpose_name=tpose_name

    def run(self):
        try:          
            if self.function is None:
                logger.error("function 对象为 None，无法执行任务")
                return
            if self.vision_app is None:
                logger.error("vision_app 对象为 None")
            # 执行任务
            self.function.execute_origin_tasks(self.tpose_name)         
        except Exception as e:
            logger.error(f"任务执行异常: {str(e)}")
        finally:
            logger.info("任务执行完成")

class Config:
    """配置管理器"""  
    def __init__(self):
        self.config= None


        
    
            
        


                      
                      

    

          

             

        

          
        




    