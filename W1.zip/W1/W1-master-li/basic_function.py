import json
import logging
import os
import sys
import threading
import time
import traceback
import numpy as np
from copy import deepcopy
from IPython import embed
from math import cos, sin, radians
from scipy.interpolate import CubicSpline
from scipy.spatial.transform import Rotation as R
from socket import *
from typing import List, Union, Sequence
# xiugai
from typing import List, Union, Sequence, Dict
# 添加image_analyzer.py所在目录到系统路径

WS = None
def set_ws(ws):
    global WS
    WS = ws

try:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'qt'))
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import Image
    from cv_bridge import CvBridge
    import cv2
    class ROSImageGetter:
        """独立的ROS图像获取器"""
        def __init__(self, topic_name='/camera/left_eye'):
            self.bridge = CvBridge()
            self.current_image = None
            self.node = None
            self.topic_name = topic_name

        def initialize(self):
            """初始化ROS节点"""
            if not rclpy.ok():
                rclpy.init()
            self.node = rclpy.create_node('image_getter')
            self.subscription = self.node.create_subscription(
                Image,
                self.topic_name,
                self.image_callback,
                10
            )
        def image_callback(self, msg):
            try:
                cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
                self.current_image = cv_image
            except Exception as e:
                print(f'图像处理错误: {str(e)}')
        def get_image(self, timeout=1.0):
            """获取最新图像"""
            if self.node is None:
                self.initialize()
            # 处理ROS事件以获取图像
            start_time = time.time()
            while time.time() - start_time < timeout:
                rclpy.spin_once(self.node, timeout_sec=0.1)
                if self.current_image is not None:
                    return self.current_image.copy()
            return None
except ModuleNotFoundError:
    # 定义一个空的占位类
    class ROSImageGetter:
        def __init__(self, topic_name='/camera/left_eye'):
            logging.error("ROSImageGetter: rclpy不可用，使用空实现")
        def get_image(self):
            return None

class VisionApp:
    def __init__(self, config):
        self.init = config['device_cfg']
        self.calib = config['calibration_cfg']
        self.log_msg = config["log_msg"]
        self.parameter = config["parameter_cfg"]
        self.vision_app = None
        self.work_name = None
  
    def connection(self):
        vision_app_cfg = self.init['vision_app']
        try:
            if self.log_msg["connect_vision_app"][1] == 1:
                logging.info(self.log_msg["connect_vision_app"][0])
            self.vision_app = socket(AF_INET, SOCK_STREAM)
            vision_app_addr = (vision_app_cfg["IP"], vision_app_cfg["PORT"])
            a = self.connect_with_retry(vision_app_addr)
            # self.vision_app.connect(vision_app_addr)
            if self.log_msg["connection_success"][1] == 1:
                logging.info(self.log_msg["connection_success"][0])
            return True
        except Exception as e:
            if self.log_msg["connection_failed"][1] == 1:
                logging.error(self.log_msg["connection_failed"][0])
            logging.error(traceback.format_exc())
            return False

    def connect_with_retry(self, vision_app_addr, max_retries=100, retry_interval=3):
        retries = 0
        while retries < max_retries:
            try:
                self.vision_app.connect(vision_app_addr)
                print("连接成功!")
                return True
            except OSError as e:
                if "already connected" in str(e):
                    print("已经连接，继续执行...")
                    return True
                elif "Transport endpoint is already connected" in str(e):
                    print("端点已连接，继续执行...")
                    return True
                else:
                    retries += 1
                    print(f"连接失败，{retry_interval}秒后重试... ({retries}/{max_retries})")
                    time.sleep(retry_interval)

        print("达到最大重试次数，连接失败")
        return False

    def dis_connection(self, silent=False):
        """安全断开连接（带错误处理和默认日志）"""
        try:
            self.vision_app.close()
            self.vision_app = None
            if self.log_msg["disconnection"][1] == 1:
                logging.error(self.log_msg["disconnection"][0])
            return True
        except Exception as e:
            if self.log_msg["connection_failed"][1] == 1:
                logging.error(self.log_msg["connection_failed"][0])
            logging.error(traceback.format_exc())
            return False

    def osend(self, vision_app_recv: str):
        if self.log_msg["vision_app_recv_msg"][1] == 1:
            logging.info(self.log_msg["vision_app_recv_msg"][0].format(vision_app_recv))
        self.vision_app.send(vision_app_recv.encode())

    def orecv(self, vision_app_recv, calib=2, calib_now=False):
        if calib == 2:
            vision_app_camera_pose = '0,0,0,0,0,0'
            vision_app_camera_pose = self.vision_app.recv(1024).decode("utf-8")
            t2 = 0
            # app_camera_pose ="1,-95.0,3.3,592.9,-16.7,-15.9,3.4"
            # app_camera_pose = True

            if vision_app_camera_pose == True:
                return 1, None,vision_app_camera_pose
            elif vision_app_camera_pose == False:
                return 0, None,vision_app_camera_pose

            if self.log_msg["vision_app_return_msg"][1] == 1:
                logging.info(self.log_msg["vision_app_return_msg"][0].format(vision_app_camera_pose))

            if '0,0,0,0,0,0' in vision_app_camera_pose:
                parts = vision_app_camera_pose.split(',')
                last_value = parts[-1] # 最后一个元素
                if int(last_value) == 100 and parts[3] == '0':
                    return 1, None,vision_app_camera_pose
                elif int(last_value) == 101 and parts[3] == '0':
                    vision_app_camera_pose = '1,10000,10000,10000,10000,10000,10000'
                else:
                    None

            if (calib_now == False and t2 == 0):
                camera_pose_list, pose_param_list, pose_num = self.analysis_vision_app_msg(vision_app_camera_pose)
                robot_1_pose_list, robot_2_pose_list = self.get_calib_robot_pose_list(camera_pose_list,vision_app_recv)
                pose_tuple = {"left_arm": robot_1_pose_list,"right_arm": robot_2_pose_list}
                return pose_tuple, pose_param_list,vision_app_camera_pose
            else:
                return vision_app_camera_pose, None,vision_app_camera_pose
        elif calib == 1:
            vision_app_send = self.vision_app.recv(1024).decode("utf-8")
            if self.log_msg["vision_app_return_msg"][1] == 1:
                logging.info(self.log_msg["vision_app_return_msg"][0].format(vision_app_send))
            return vision_app_send,vision_app_camera_pose

    def send_recv(self, vision_app_recv: str,work_name=None, calib=2):
        """
        说明:
            视觉同时发送两个坐标, 处理两次坐标再返回
        参数:
            vision_app_recv: 发送给vision_app的字符串
            calib: 1表示视觉返回机器人坐标系坐标,使用vision_app的标定, 2表示视觉返回两个相机坐标系坐标, 脚本双臂标定
            recv_num: 接收次数。
        """
        self.work_name = work_name
        pose_tuple_all = {"left_arm": [], "right_arm": []} # 初始化为字典, 包含两个空列表
        if calib == 1:
            while True:
                vision_app_send = []
                if self.log_msg["vision_app_recv_msg"][1] == 1:
                    logging.info(self.log_msg["vision_app_recv_msg"][0].format(vision_app_recv))
                self.vision_app.send(vision_app_recv.encode())
                vision_app_send = self.vision_app.recv(1024).decode("utf-8")
                if self.log_msg["vision_app_return_msg"][1] == 1:
                    logging.info(self.log_msg["vision_app_return_msg"][0].format(vision_app_send))
                return vision_app_send
        elif calib == 2:
            a1 = time.time()
            self.osend(vision_app_recv)
            pose_tuple, pose_param_list,vision_pose = self.orecv(vision_app_recv)
            if pose_tuple == 1:
                return {"left_arm": [[1]],"right_arm": [[1]]}, None,None
            elif pose_tuple == 0:
                return {"left_arm": [[0]],"right_arm": [[0]]}, None,None
            b1 = time.time()
            if self.log_msg["vision_app_time"][1] == 1:
                logging.info(self.log_msg["vision_app_time"][0].format(b1-a1))
            pose_tuple_all["left_arm"].extend(pose_tuple["left_arm"])
            pose_tuple_all["right_arm"].extend(pose_tuple["right_arm"])
            if pose_tuple_all['left_arm'] == []:
                pose_tuple_all['left_arm'] = [[]]

            if pose_tuple_all['right_arm'] == []:
                pose_tuple_all['right_arm'] = [[]]
            return pose_tuple_all, pose_param_list,vision_pose

    def analysis_vision_app_msg(self, msg):
            pose_elements = msg.split(',')
            pose_elements = [item for item in pose_elements if item != ''] #去掉所有空的字符串, 末尾有逗号就会有空字符串
            pose_num = int(pose_elements[0])
            pose_list = []
            pose_param_list = []
            elements_per_pose = self.init["vision_app"]["pose_type_num"]
            for i in range(pose_num):
                start_index = 1 + i * elements_per_pose
                end_index = start_index + elements_per_pose
                pose_list.append([float(item) for item in pose_elements[start_index:end_index]])
            if len(pose_elements) > 7 and self.init["vision_app"]["pose_param_num"] != 0:
                pose_param_list = [float(pose_elements[7]), float(pose_elements[8]), float(pose_elements[9]), float(pose_elements[10])]
                if self.log_msg["25"][1] == 1:
                    logging.info(self.log_msg["25"][0].format(pose_param_list))

            return pose_list, pose_param_list, pose_num

    def get_calib_robot_pose_list(self, camera_pose_list:list,vision_app_recv):
        def poseConvert(pose: list, rotation: str):
            pose_m = [x / 1000 for x in pose[:3]] + pose[3:]
            if rotation == 'xyz':
                rot_matrix = R.from_euler(rotation, [pose_m[3], pose_m[4], pose_m[5]], degrees=True).as_matrix()
            elif rotation == 'ZYX':
                rot_matrix = R.from_euler(rotation, [pose_m[5], pose_m[4], pose_m[3]], degrees=True).as_matrix()
            pose_matrix = np.identity(4)
            pose_matrix[:3, :3] = rot_matrix
            pose_matrix[:3, 3] = [pose_m[0], pose_m[1], pose_m[2]]
            return np.mat(pose_matrix)

        def get_calib_pose_shift(pose_matrix: np.mat, calib_matrix: np.mat, euler: str) -> np.mat: # type: ignore
            new_matrix = calib_matrix * pose_matrix
            new_pose = [
                round(new_matrix[0, 3], 3), round(new_matrix[1, 3], 3), round(new_matrix[2, 3], 3),
                round(R.from_matrix(new_matrix[:3, :3]).as_euler(euler, degrees=True)[0], 3),
                round(R.from_matrix(new_matrix[:3, :3]).as_euler(euler, degrees=True)[1], 3),
                round(R.from_matrix(new_matrix[:3, :3]).as_euler(euler, degrees=True)[2], 3)
            ]
            new_pose_mm = [x * 1000 for x in new_pose[:3]] + new_pose[3:]
            return new_pose_mm

        def increase_rz(pose_list, offset, euler_order):
            # 更新pose_list中每个坐标的RZ值
            for pose in pose_list:
                if euler_order.upper() == 'ZYX':
                    pose[3] += offset
                elif euler_order.upper() == 'XYZ':
                    pose[5] += offset
                elif euler_order.lower() == 'xyz':
                    # 假设内旋'xyz'的RZ是列表中的第6个元素
                    pose[5] += offset
                else:
                    raise ValueError("Invalid euler order: {}".format(euler_order))
            return pose_list

        robot_1_pose_list = [None] * len(camera_pose_list)
        robot_2_pose_list = [None] * len(camera_pose_list)
        for i in range(len(camera_pose_list)):
            list_values = camera_pose_list[i]

            # 查找left_arm配置
            left_config = None
            for use_key, use_config in self.parameter["calib_martix_select"].items():
                if use_config["module"] == self.work_name and use_config["arm"] == "left_arm":
                    left_config = use_config
                    break

            # 处理left_arm
            temp_camera_pose_matrix = poseConvert(list_values, self.calib["robot_1"]["euler"])
            if left_config:
                print(f"new_left - 使用矩阵: {left_config['martix_name']}")
                pose_values = get_calib_pose_shift(temp_camera_pose_matrix, self.calib["robot_1"][left_config["martix_name"]], self.calib["robot_1"]["euler"])
            else:
                pose_values = get_calib_pose_shift(temp_camera_pose_matrix, self.calib["robot_1"]["calib_martix"], self.calib["robot_1"]["euler"])

            robot_1_pose_list[i] = pose_values

            # 查找right_arm配置
            right_config = None
            for use_key, use_config in self.parameter["calib_martix_select"].items():
                if use_config["module"] == self.work_name and use_config["arm"] == "right_arm":
                    right_config = use_config
                    break

            # 处理right_arm
            temp_camera_pose_matrix = poseConvert(list_values, self.calib["robot_2"]["euler"])
            if right_config:
                print(f"new_right - 使用矩阵: {right_config['martix_name']}")
                pose_values = get_calib_pose_shift(temp_camera_pose_matrix, self.calib["robot_2"][right_config["martix_name"]], self.calib["robot_2"]["euler"])
            else:
                pose_values = get_calib_pose_shift(temp_camera_pose_matrix, self.calib["robot_2"]["calib_martix"], self.calib["robot_2"]["euler"])

            robot_2_pose_list[i] = pose_values
        robot_1_pose_list = increase_rz(robot_1_pose_list,self.calib["robot_1"]["ee_rotate"],self.calib["robot_1"]["euler"])
        robot_2_pose_list = increase_rz(robot_2_pose_list,self.calib["robot_2"]["ee_rotate"],self.calib["robot_2"]["euler"])
        for i in range(len(camera_pose_list)):
            if self.log_msg["poseturning"][1]==1: logging.info(self.log_msg["poseturning"][0].format(self.calib["robot_1"]["name"], i+1, robot_1_pose_list[i]))
            if self.log_msg["poseturning"][1]==1: logging.info(self.log_msg["poseturning"][0].format(self.calib["robot_2"]["name"], i+1, robot_2_pose_list[i]))
        return robot_1_pose_list ,robot_2_pose_list

class RobotApp:
    def __init__(self, log_msg, vision_app, parameter_cfg,config):
        self.parameter_cfg = parameter_cfg
        self.log_msg = log_msg
        self.loop = None
        self.vision_app = vision_app
        self.T_matrix = np.eye(4)
        self.config = config
        from dexe_robot_client.common import W1Version, W1ArmType
        from dexe_robot_client.end_effector_client import EndEffectorType
        from dexe_robot_client.w1 import W1Manager
        if self.parameter_cfg["use_robot"] == True:
            self.w1_manager = W1Manager(is_sim=True,
                                        arm_type=W1ArmType.ANTHROPOMORPHIC,
                                        w1_version=W1Version.V2,
                                        end_effector_type=EndEffectorType.BRAINCO_HAND,
                                        use_nav=True)
            while not self.w1_manager.set_sim_mode(enable_sim=False):
                time.sleep(2)
            while self.w1_manager.is_enabled() != True:
                time.sleep(2)
                if self.log_msg["pc1_op_error"][1] == 1:logging.info(self.log_msg["pc1_op_error"][0].format())
            if self.log_msg["pc1_op_success"][1] == 1:logging.info(self.log_msg["pc1_op_success"][0].format())        


    def format_json_compact_inner_lists(self, obj, indent=2, level=0):
        '''优化日志打印, 方便查问题, 并按指定顺序显示特定字段'''
        sp = ' ' * (indent * level)
        if isinstance(obj, dict):
            # Define the desired display order with priority
            priority_order = [
                'left_arm', 'left_arm_speed_ratio',
                'right_arm', 'right_arm_speed_ratio',
                'left_arm_ee', 'right_arm_ee',
                'torso', 'torso_speed_ratio',
                'head', 'head_speed_ratio'
            ]

            # Separate items into prioritized and others
            prioritized_items = []
            other_items = []

            for k, v in obj.items():
                if k in priority_order:
                    prioritized_items.append((priority_order.index(k), k, v))
                else:
                    other_items.append((len(priority_order), k, v))  # Others come after

            # Sort items - first by priority, then alphabetically for others
            sorted_items = sorted(prioritized_items + other_items, key=lambda x: (x[0], x[1]))
            items = []

            for _, k, v in sorted_items:
                # Special handling for speed ratio keys - always compact
                if k.endswith('_speed_ratio'):
                    items.append(f'{sp}{" " * indent}"{k}": {self.format_speed_ratio(v)}')
                else:
                    items.append(f'{sp}{" " * indent}"{k}": {self.format_json_compact_inner_lists(v, indent, level+1)}')

            return '{\n' + ',\n'.join(items) + f'\n{sp}}}'
        elif isinstance(obj, list):
            # 判断是否所有元素都是None
            if all(i is None for i in obj):
                return '[' + ', '.join(['null'] * len(obj)) + ']'
            # 每个元素一行, 连续null合并
            lines = []
            nulls = []
            for item in obj:
                if item is None:
                    nulls.append('null')
                else:
                    if nulls:
                        lines.append(' ' * (indent * (level+1)) + ', '.join(nulls))
                        nulls = []
                    # 如果是简单类型的list（如[0, [1,2], 0]）, 一行显示
                    if isinstance(item, list) and all(isinstance(x, (int, float, str, type(None), list)) for x in item):
                        def item_repr(i):
                            if isinstance(i, list):
                                return '[' + ', '.join('null' if x is None else repr(x) for x in i) + ']'
                            return 'null' if i is None else repr(i)
                        lines.append(' ' * (indent * (level+1)) + '[' + ', '.join(item_repr(i) for i in item) + ']')
                    else:
                        lines.append(' ' * (indent * (level+1)) + self.format_json_compact_inner_lists(item, indent, level+1))
            if nulls:
                lines.append(' ' * (indent * (level+1)) + ', '.join(nulls))
            return '[\n' + ',\n'.join(lines) + f'\n{sp}]'
        elif obj is None:
            return 'null'
        elif isinstance(obj, str):
            return '"' + obj + '"'
        else:
            return str(obj)

    def format_speed_ratio(self, value):
        """Helper function to format speed ratio values in a compact way"""
        if isinstance(value, list):
            return '[' + ', '.join('null' if x is None else str(x) for x in value) + ']'
        elif value is None:
            return 'null'
        elif isinstance(value, str):
            return '"' + value + '"'
        else:
            return str(value)

    def fix_none_in_ee(self, ee_list):
        """
        遍历 ee_list, 如果某一项为 None 或 [None], 则替换为最近一次不为 None 的项。
        """
        fixed = []
        last_valid = None
        for item in ee_list:
            if item is None or (isinstance(item, list) and item[0] is None):
                fixed.append(last_valid if last_valid is not None else item)
            else:
                fixed.append(item)
                last_valid = item
        return fixed

    def get_first_valid(self, head_torso, index):
        """
        遍历 head_torso 列表, 返回第一个子元素在索引 index 处不为 None 的值
        """
        for item in head_torso:
            if item is not None and isinstance(item, list) and len(item) > index and item[index] is not None:
                return item[index]
        return None

    def recombine_cfg(self, pose_tuple, cfg_msg):
        head_torso = cfg_msg.get("head_torso", [])
        body_val = []
        head_val = []
        b = self.get_first_valid(head_torso, 1)
        if b is not None:
            body_val = [b]
        h = self.get_first_valid(head_torso, 0)
        if h is not None:
            head_val = [h]

        new_cfg = {
            "torso": body_val,
            "head": head_val,
            "left_arm": pose_tuple.get("left_arm", []),
            "right_arm": pose_tuple.get("right_arm", []),
            "left_arm_ee": [item for item in cfg_msg.get("end_effector", {}).get("left_arm", [])],
            "right_arm_ee": [item for item in cfg_msg.get("end_effector", {}).get("right_arm", [])],
            "torso_speed_ratio":cfg_msg['torso_speed_ratio'],
            "head_speed_ratio": cfg_msg['head_speed_ratio'],
            "left_arm_speed_ratio":cfg_msg['left_arm_speed_ratio'],
            "right_arm_speed_ratio": cfg_msg['right_arm_speed_ratio']
        }

        new_cfg["left_arm_ee"] = self.fix_none_in_ee(new_cfg["left_arm_ee"])
        new_cfg["right_arm_ee"] = self.fix_none_in_ee(new_cfg["right_arm_ee"])

        # new_cfg["left_arm_speed_ratio"] = self.fix_none_in_ee(new_cfg["left_arm_ee"])
        # new_cfg["right_arm_speed_ratio"] = self.fix_none_in_ee(new_cfg["right_arm_ee"])

        # 如果第一个元素为 None, 则用下一个有效元素替换
        if new_cfg["left_arm_ee"] and new_cfg["left_arm_ee"][0] is None and len(new_cfg["left_arm_ee"]) > 1:
            new_cfg["left_arm_ee"][0] = new_cfg["left_arm_ee"][1]
        if new_cfg["right_arm_ee"] and new_cfg["right_arm_ee"][0] is None and len(new_cfg["right_arm_ee"]) > 1:
            new_cfg["right_arm_ee"][0] = new_cfg["right_arm_ee"][1]

        return new_cfg

    def pad_arm_speed_ratio(self, new_cfg):
        # # 处理 left_arm
        left_arm_len = len(new_cfg["left_arm"])
        new_cfg["left_arm_speed_ratio"] = new_cfg["left_arm_speed_ratio"][:left_arm_len] # 截断多余部分
        if len(new_cfg["left_arm_speed_ratio"]) < left_arm_len:
            new_cfg["left_arm_speed_ratio"].extend([None] * (left_arm_len - len(new_cfg["left_arm_speed_ratio"])))

        # 处理 right_arm（同理）
        right_arm_len = len(new_cfg["right_arm"])
        new_cfg["right_arm_speed_ratio"] = new_cfg["right_arm_speed_ratio"][:right_arm_len] # 截断多余部分
        if len(new_cfg["right_arm_speed_ratio"]) < right_arm_len:
            new_cfg["right_arm_speed_ratio"].extend([None] * (right_arm_len - len(new_cfg["right_arm_speed_ratio"])))

        return new_cfg

    def MoveL(self, pose_tuple, cfg_msg, work_name, parameter=None, config_cfg=None,go_home_log=None):
        self.tcp_setting()
        new_cfg = self.recombine_cfg(pose_tuple, cfg_msg)

        if work_name == '回原点':
            self.GoHome(speed=1)
            return True
        if "torso" in new_cfg and new_cfg["torso"]:
            new_cfg["torso"] = [list(np.deg2rad(new_cfg["torso"][0]))]
        if "head" in new_cfg and new_cfg["head"]:
            new_cfg["head"] = [list(np.deg2rad(new_cfg["head"][0]))]
        if "head_speed_ratio" in new_cfg and new_cfg["head_speed_ratio"]:
            new_cfg["head_speed_ratio"] = [x for x in new_cfg["head_speed_ratio"] if x != 1]
            if [x for x in new_cfg["head_speed_ratio"] if x != 1] == []:new_cfg["head_speed_ratio"] = [1]
        if "torso_speed_ratio" in new_cfg and new_cfg["torso_speed_ratio"]:
            new_cfg["torso_speed_ratio"] = [x for x in new_cfg["torso_speed_ratio"] if x != 1]
            if [x for x in new_cfg["torso_speed_ratio"] if x != 1] == []:new_cfg["torso_speed_ratio"] = [1]

        new_cfg = self.pad_arm_speed_ratio(new_cfg)

        if go_home_log == None:
            if self.log_msg["move_dict"][1] == 1:
                logging.info(self.log_msg["move_dict"][0].format(work_name,self.format_json_compact_inner_lists(new_cfg)))
        else:
            work_name_log = work_name + '_回原点轨迹'
            if self.log_msg["move_dict"][1] == 1:
                logging.info(self.log_msg["move_dict"][0].format(work_name_log,self.format_json_compact_inner_lists(new_cfg)))
        # 更新速度
        pose_list = self.parameter_cfg['pose_list'][work_name]
        tpose_idx = 0 # 独立计数器, 仅对 tpose_n 递增
        for tpose_key in pose_list:
            if not tpose_key.startswith('tpose_'):
                continue  # 跳过非 tpose_n 的键
            tpose_data = pose_list[tpose_key]
            arm_speed = tpose_data.get('arm_speed')
            if arm_speed is None:
                tpose_idx += 1 # 即使没有 arm_speed, 也要递增（因为占位置）
                continue
            use_arm = tpose_data.get('use_arm')
            if use_arm not in ['left_arm', 'right_arm']:
                tpose_idx += 1 # 无效 use_arm 也要递增
                continue
            if use_arm == 'left_arm':
                if tpose_idx < len(new_cfg['left_arm_speed_ratio']):
                    new_cfg['left_arm_speed_ratio'][tpose_idx] = arm_speed
            else:
                if tpose_idx < len(new_cfg['right_arm_speed_ratio']):
                    new_cfg['right_arm_speed_ratio'][tpose_idx] = arm_speed
            # print(f"更新 {use_arm} 速度: {arm_speed} (来自 {tpose_key}, tpose_idx={tpose_idx})")
            tpose_idx += 1


        if 'all_torso_offset' in self.parameter_cfg and self.parameter_cfg['all_torso_offset']['use'] == True:
            
            qpos_torso_pre = np.array(new_cfg["torso"][0])
            current_torso = np.degrees(qpos_torso_pre)
            res, x, z, y_theta = self.w1_manager.kine.get_torso_fk(qpos_torso_pre[:3])
            torso_offset = parameter['all_torso_offset']["offset"]
            x1 = x + torso_offset['x']*0.001
            y_theta1 = y_theta + torso_offset['y_theta']
            z1 = z+torso_offset['z']*0.001
            qpos_ = self.w1_manager.kine.get_torso_ik(x1, z1, y_theta1, qpos_torso_pre[1] < 0)[1]
            new_cfg["torso"] = [np.append(qpos_, qpos_torso_pre[-1]).tolist()]
            deg_torso_target = np.degrees(np.append(qpos_, qpos_torso_pre[-1]))
            if self.log_msg["torso_offset_move"][1] == 1:
                logging.info(self.log_msg["torso_offset_move"][0].format([torso_offset['x'],torso_offset['y_theta'],torso_offset['z']],current_torso,deg_torso_target))       

        if 'speed' in self.parameter_cfg['pose_list'][work_name]:
            # print('使用配置速度',self.parameter_cfg['pose_list'][work_name]['speed'])
            success = self.w1_manager.move_linear_full_body(
                waypoints_dict = new_cfg,
                speed_ratio = self.parameter_cfg['pose_list'][work_name]['speed']
            )
        else:
            success = self.w1_manager.move_linear_full_body(
                waypoints_dict = new_cfg,
                speed_ratio = 1.8
            )
        if "time_sleep" in self.parameter_cfg['pose_list'][work_name]:
            time.sleep(self.parameter_cfg['pose_list'][work_name]["time_sleep"])
        return success

    def MoveL_no_auto_gohome(self, pose_tuple, cfg_msg, work_name,parameter=None,config_cfg = None):
        """
        说明:
            输入pose_tuple若只含一个运动坐标,自动生成另一个臂当前坐标
            pose_tuple: {"left_arm":robot_1pose,"right_arm":robot_2pose} 机器人坐标系坐标
            ee_list:[[],[],[]]
        """

        if work_name == '回原点':
            self.GoHome(speed=0.5)
            return True

        else:
            self.tcp_setting()
            new_cfg = self.recombine_cfg(pose_tuple, cfg_msg)
            if "torso" in new_cfg and new_cfg["torso"]:
                new_cfg["torso"] = [list(np.deg2rad(new_cfg["torso"][0]))]
            if "head" in new_cfg and new_cfg["head"]:
                new_cfg["head"] = [list(np.deg2rad(new_cfg["head"][0]))]
            if "head_speed_ratio" in new_cfg and new_cfg["head_speed_ratio"]:
                new_cfg["head_speed_ratio"] = [x for x in new_cfg["head_speed_ratio"] if x != 1]
                if [x for x in new_cfg["head_speed_ratio"] if x != 1] == []:new_cfg["head_speed_ratio"] = [1]
            if "torso_speed_ratio" in new_cfg and new_cfg["torso_speed_ratio"]:
                new_cfg["torso_speed_ratio"] = [x for x in new_cfg["torso_speed_ratio"] if x != 1]
                if [x for x in new_cfg["torso_speed_ratio"] if x != 1] == []:new_cfg["torso_speed_ratio"] = [1]

            new_cfg = self.pad_arm_speed_ratio(new_cfg)
            work_name_log = work_name + '_回原点轨迹'
            if self.log_msg["move_dict"][1] == 1:
                logging.info(self.log_msg["move_dict"][0].format(work_name_log,self.format_json_compact_inner_lists(new_cfg)))

            # 更新速度
            pose_list = self.parameter_cfg['pose_list'][work_name]
            tpose_idx = 0 # 独立计数器, 仅对 tpose_n 递增
            for tpose_key in pose_list:
                if not tpose_key.startswith('tpose_'):
                    continue  # 跳过非 tpose_n 的键
                tpose_data = pose_list[tpose_key]
                arm_speed = tpose_data.get('arm_speed')
                if arm_speed is None:
                    tpose_idx += 1 # 即使没有 arm_speed, 也要递增（因为占位置）
                    continue
                use_arm = tpose_data.get('use_arm')
                if use_arm not in ['left_arm', 'right_arm']:
                    tpose_idx += 1 # 无效 use_arm 也要递增
                    continue
                if use_arm == 'left_arm':
                    if tpose_idx < len(new_cfg['left_arm_speed_ratio']):
                        new_cfg['left_arm_speed_ratio'][tpose_idx] = arm_speed
                else:
                    if tpose_idx < len(new_cfg['right_arm_speed_ratio']):
                        new_cfg['right_arm_speed_ratio'][tpose_idx] = arm_speed
                # print(f"更新 {use_arm} 速度: {arm_speed} (来自 {tpose_key}, tpose_idx={tpose_idx})")
                tpose_idx += 1

            if 'all_torso_offset' in self.parameter_cfg and self.parameter_cfg['all_torso_offset']['use'] == True:
                qpos_torso_pre = np.array(new_cfg["torso"][0])
                current_torso = np.degrees(qpos_torso_pre)
                res, x, z, y_theta = self.w1_manager.kine.get_torso_fk(qpos_torso_pre[:3])
                torso_offset = parameter['all_torso_offset']["offset"]
                x1 = x + torso_offset['x']*0.001
                y_theta1 = y_theta + torso_offset['y_theta']
                z1 = z+torso_offset['z']*0.001
                qpos_ = self.w1_manager.kine.get_torso_ik(x1, z1, y_theta1, qpos_torso_pre[1] < 0)[1]
                new_cfg["torso"] = [np.append(qpos_, qpos_torso_pre[-1]).tolist()]
                deg_torso_target = np.degrees(np.append(qpos_, qpos_torso_pre[-1]))
                if self.log_msg["torso_offset_move"][1] == 1:
                    logging.info(self.log_msg["torso_offset_move"][0].format([torso_offset['x'],torso_offset['y_theta'],torso_offset['z']],current_torso,deg_torso_target))       
                

            if 'speed' in self.parameter_cfg['pose_list'][work_name]:
                success = self.w1_manager.move_linear_full_body(
                    waypoints_dict = new_cfg,
                    speed_ratio = self.parameter_cfg['pose_list'][work_name]['speed']
                )
            else:
                success = self.w1_manager.move_linear_full_body(
                    waypoints_dict = new_cfg,
                    speed_ratio = 1.8
                )
            if "time_sleep" in self.parameter_cfg['pose_list'][work_name]:
                time.sleep(self.parameter_cfg['pose_list'][work_name]["time_sleep"])
            return success



    def GoHome(self,speed=0.5):
        status = self.w1_manager.go_home(speed)
        self.w1_manager.set_ee_qpos("left_arm_ee", [0., 0., 0., 0., 0., 0.])
        self.w1_manager.set_ee_qpos("right_arm_ee", [0., 0., 0., 0., 0., 0.])
        return status

    def tcp_setting(self):
        # "设置末端夹具Tcp"
        left_tcp_xpos = np.eye(4)
        left_tcp_xpos[2, 3] = 0
        self.w1_manager.set_tcp("left_arm", xpos=left_tcp_xpos)
        right_tcp_xpos = np.eye(4)
        right_tcp_xpos[2, 3] = 0
        right_tcp_xpos[:3, :3] = R.from_rotvec([0.0, 0.0, 180.], degrees=True).as_matrix()
        self.w1_manager.set_tcp("right_arm", xpos=right_tcp_xpos)

    def get_current_pose(self, name):
        """
        获取机械臂当前坐标
        注意是xyz坐标系

        参数:
            name: right_arm / left_arm / head / torso / left_arm_ee / right_arm_ee

        返回:
            w1_cart_pose, w1_joint_pose
        """

        if (name == "right_arm" or name == "left_arm"):
            self.tcp_setting()
            w1_cart_pose = self.w1_manager.get_current_pose(name)[1] # 获取臂当前位姿矩阵
            w1_joint_pose = self.w1_manager.get_current_qpos(name)[1]
            w1_cart_pose = [round(num, 3) for num in w1_cart_pose]
            w1_joint_pose = [round(num, 3) for num in w1_joint_pose]
            if self.log_msg["robot_cart_pose"][1] == 1:
                logging.info(self.log_msg["robot_cart_pose"][0].format(name, w1_cart_pose))
            if self.log_msg["robot_joint_pose"][1] == 1:
                logging.info(self.log_msg["robot_joint_pose"][0].format(name, w1_joint_pose))
            return w1_cart_pose, w1_joint_pose
        elif (name == "head" or name == "torso"):
            joint_pose = self.w1_manager.get_current_qpos(name)[1]
            if name == 'torso':
                if self.log_msg["torso_joint_pose"][1] == 1:
                    logging.info(self.log_msg["torso_joint_pose"][0].format(joint_pose))
                if self.log_msg["torso_cart_pose"][1] == 1:
                    logging.info(self.log_msg["torso_cart_pose"][0].format(np.degrees(joint_pose)))
            return np.degrees(joint_pose), True
        elif (name == "left_arm_ee" or name == "right_arm_ee"):
            return self.w1_manager.get_current_qpos(name)[1], True
        else:
            return False, False
        
    def set_ee_qpos(self, ee_name, qpos):
        """
        设置末端执行器位置
        参数:
            ee_name: left_arm_ee / right_arm_ee
            qpos: 位置值
        返回:
            设置结果
        """
        return self.w1_manager.set_ee_qpos(ee_name, qpos)
        
    def replay_teleop(self, file_name='pose_record_sample', name_list=['head', 'right_arm'], speed_ratio=0.1, run_times=-1):
        joint_keys = [
            "ANKLE", "KNEE", "BUTTOCK", "WAIST", "NECK1", "NECK2",
            "LEFT_J1", "LEFT_J2", "LEFT_J3", "LEFT_J4", "LEFT_J5", "LEFT_J6", "LEFT_J7",
            "RIGHT_J1", "RIGHT_J2", "RIGHT_J3", "RIGHT_J4", "RIGHT_J5", "RIGHT_J6", "RIGHT_J7"
        ]

        finger_keys = [
            "LEFT_HAND_THUMB1", "LEFT_HAND_THUMB2", "LEFT_HAND_INDEX", "LEFT_HAND_MIDDLE", "LEFT_HAND_RING", "LEFT_HAND_PINKY",
            "RIGHT_HAND_THUMB1", "RIGHT_HAND_THUMB2", "RIGHT_HAND_INDEX", "RIGHT_HAND_MIDDLE", "RIGHT_HAND_RING", "RIGHT_HAND_PINKY"
        ]

        file_path = os.path.dirname(os.path.abspath(__file__)) + '/parameters/' + file_name + ".json"
        traj_seq = 0

        head_qpos_array = []
        torso_qpos_array = []
        left_arm_qpos_array = []
        right_arm_qpos_array = []

        try:
            with open(file_path, 'r') as file:
                data = json.load(file)
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            sys.exit(1)

        frames = data.get("frames", [])

        init_torso_qpos = self.w1_manager.get_current_qpos(name="torso")[1]
        init_head_qpos = self.w1_manager.get_current_qpos(name="head")[1]
        init_left_arm = self.w1_manager.get_current_qpos(name="left_arm")[1]
        init_right_arm = self.w1_manager.get_current_qpos(name="right_arm")[1]

        for frame in frames:
            joint_data = frame.get("data", {})

            torso_qpos = self.w1_manager.get_current_qpos(name="torso")[1]
            head_qpos = self.w1_manager.get_current_qpos(name="head")[1]
            left_arm_qpos = self.w1_manager.get_current_qpos(name="left_arm")[1]
            right_arm_qpos = self.w1_manager.get_current_qpos(name="right_arm")[1]

            head_qpos = [joint_data.get(key, 0.0) for key in joint_keys[4 : 6]]
            head_qpos = [x - 3.1415926 for x in head_qpos]
            left_arm_qpos = [joint_data.get(key, 0.0) for key in joint_keys[6 : 13]]
            left_arm_qpos = [x - 3.1415926 for x in left_arm_qpos]
            # right_arm_qpos = [joint_data.get(key, 0.0) for key in joint_keys[13 : 20]]
            # right_arm_qpos = [x - 3.1415926 for x in right_arm_qpos]

            if (traj_seq == 0):
                first_cfg = {"left_arm":[left_arm_qpos], "right_arm":[right_arm_qpos]}

                success = self.w1_manager.move_joint_full_body(
                    waypoints_dict = first_cfg,
                    speed_ratio = 0.2
                )

            traj_seq = traj_seq + 1
            print("traj_seq", traj_seq)

            torso_qpos_array.append(torso_qpos)
            head_qpos_array.append(head_qpos)
            left_arm_qpos_array.append(left_arm_qpos)
            right_arm_qpos_array.append(right_arm_qpos)

            if (run_times > 0):
                run_times = run_times - 1
            elif (run_times == 0):
                break

        total_qpos_array = np.hstack(
            [
                torso_qpos_array,
                head_qpos_array,
                left_arm_qpos_array,
                right_arm_qpos_array,
            ]
        )

        print("total_qpos_array", total_qpos_array)
        self.w1_manager.execute_joint_traj(total_qpos_array)

        end_cfg = {"left_arm":[init_left_arm], "right_arm":[init_right_arm]}

        success = self.w1_manager.move_joint_full_body(
            waypoints_dict = end_cfg,
            speed_ratio = 0.2
        )

    def replay_waypoints(self, file_name='pose_record_sample', name_list=['left_arm', 'right_arm'], speed_ratio=0.1, start_time=0, run_times=-1):
        joint_keys = [
            "ANKLE", "KNEE", "BUTTOCK", "WAIST", "NECK1", "NECK2",
            "LEFT_J1", "LEFT_J2", "LEFT_J3", "LEFT_J4", "LEFT_J5", "LEFT_J6", "LEFT_J7",
            "RIGHT_J1", "RIGHT_J2", "RIGHT_J3", "RIGHT_J4", "RIGHT_J5", "RIGHT_J6", "RIGHT_J7"
        ]

        finger_keys = [
            "LEFT_HAND_THUMB1", "LEFT_HAND_THUMB2", "LEFT_HAND_INDEX", "LEFT_HAND_MIDDLE", "LEFT_HAND_RING", "LEFT_HAND_PINKY",
            "RIGHT_HAND_THUMB1", "RIGHT_HAND_THUMB2", "RIGHT_HAND_INDEX", "RIGHT_HAND_MIDDLE", "RIGHT_HAND_RING", "RIGHT_HAND_PINKY"
        ]

        head_qpos_array = []
        torso_qpos_array = []
        left_arm_qpos_array = []
        right_arm_qpos_array = []

        file_path = os.path.dirname(os.path.abspath(__file__)) + '/parameters/' + file_name + ".json"
        traj_seq = 0

        try:
            with open(file_path, 'r') as file:
                data = json.load(file)
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            sys.exit(1)

        frames = data.get("frames", [])

        init_torso= self.w1_manager.get_current_qpos(name="torso")[1]
        init_head = self.w1_manager.get_current_qpos(name="head")[1]
        init_left_arm = self.w1_manager.get_current_qpos(name="left_arm")[1]
        init_right_arm = self.w1_manager.get_current_qpos(name="right_arm")[1]

        for frame in frames:
            if (traj_seq == 0):
                joint_data = frame.get("data", {})

                head_qpos = [joint_data.get(key, 0.0) for key in joint_keys[4 : 6]]
                head_qpos = [x - 3.1415926 for x in head_qpos]
                head_qpos[0] = head_qpos[0] + 0.2
                left_arm_qpos = [joint_data.get(key, 0.0) for key in joint_keys[6 : 13]]
                left_arm_qpos = [x - 3.1415926 for x in left_arm_qpos]
                left_arm_qpos[0] = left_arm_qpos[0] - 0.1
                left_arm_qpos[3] = left_arm_qpos[3] - 0.2

                first_cfg = {"head": [head_qpos], "left_arm":[left_arm_qpos]}

                success = self.w1_manager.move_joint_full_body(
                    waypoints_dict = first_cfg,
                    speed_ratio = 0.8 * speed_ratio
                )

            if (traj_seq % 100 == 0):
                print("start_time: ", start_time)
                if (start_time > 0):
                    start_time = start_time - 1
                    if (start_time == 0):
                        traj_seq = 0
                elif (start_time == 0):
                    joint_data = frame.get("data", {})

                    head_qpos = [joint_data.get(key, 0.0) for key in joint_keys[4 : 6]]
                    head_qpos = [x - 3.1415926 for x in head_qpos]
                    head_qpos[0] = head_qpos[0] + 0.2
                    left_arm_qpos = [joint_data.get(key, 0.0) for key in joint_keys[6 : 13]]
                    left_arm_qpos = [x - 3.1415926 for x in left_arm_qpos]
                    left_arm_qpos[0] = left_arm_qpos[0] - 0.1
                    left_arm_qpos[3] = left_arm_qpos[3] - 0.2
                    print("left_arm_qpos: ", left_arm_qpos)

                    head_qpos_array.append(head_qpos)
                    left_arm_qpos_array.append(left_arm_qpos)

                    if (run_times > 0):
                        run_times = run_times - 1
                    elif (run_times == 0):
                        break

            traj_seq = traj_seq + 1

        traj_cfg = {"head": head_qpos_array, "left_arm": left_arm_qpos_array}

        success = self.w1_manager.move_joint_full_body(
            waypoints_dict = traj_cfg,
            speed_ratio = speed_ratio
        )

class Function:
    def __init__(self, config, vision_app, robot_app):
        self.init = config
        self.log_msg = config["log_msg"]
        self.loop = None
        self.robot_app = robot_app
        self.vision_app = vision_app
        self.image_getter = ROSImageGetter()
        self.WS = WS  # 添加对WS的引用
        self._should_stop = False  # 添加停止标志
        self.stop_saving = None
        self.status = None

    def set_ee_qpos(self, ee_name, qpos):
        """
        设置末端执行器位置
        参数:
            ee_name: left_arm_ee / right_arm_ee
            qpos: 位置值
        返回:
            设置结果
        """
        return self.robot_app.set_ee_qpos(ee_name, qpos)

    def execute_origin_tasks(self, work_name, text=""):
        """
        """
        if self.log_msg["http_log"][1] == 1:
            logging.info(self.log_msg["http_log"][0].format(text))
        # 重置停止标志
        self._should_stop = False

        config_list = self.init['parameter_cfg']["pose_list"][work_name]
        success = self.move_posetuning_list(work_name=work_name, text=text)
        if success == 'stopping':
            self._write_status_file("status","stopping")

            return False
        # 检查是否被中断
        if self._should_stop:
            self.send_voice(None, end=False)
            return False

        # config_list = self.init['parameter_cfg']["pose_list"][work_name]
        # success = self.move_posetuning_list(work_name=work_name,text=text)
        if isinstance(success, list):
            for key in success:
                status = self.move_posetuning_list(work_name=key,text =text)
                if status == False:
                    self.send_voice(None,end = False)
                    return False
                while isinstance(status, list): # 异常情况递归调用
                    status = self.for_run(status,text)
                    if status == False:
                        self.send_voice(None,end = False)
                        return False

            if status == True:
                self.send_voice(None,end = True)
                return True
            
        if work_name == '语音连续运行':
            self._write_status_file("status","idle")

    def stop_execution(self):
        """设置停止标志，中断当前执行"""
        self._should_stop = True
        logging.info("收到停止信号，正在中断任务执行...")

    def for_run(self, status, text):
        if status ==False:
            self.send_voice(None,end =False)
            return False
        for key1 in status:
            new_status = self.move_posetuning_list(work_name=key1, text=text)
            if isinstance(new_status, list):
                recursive_result = self.for_run(new_status, text)
                if recursive_result is False:
                    self.send_voice(None,end =False)
                    print('不可运动结束')
                    return False
                else:
                    continue
            elif new_status is False:
                self.send_voice(None,end = False)
                print('不可运动结束')
                return False
            status = new_status
        return True

    def select_pose_data(self,pose_tuple, vision_app_msg):
        """
        根据vision_app_msg[1][1]的值从pose_tuple中选择对应的left_arm和right_arm数据

        参数:
            pose_tuple: 包含left_arm和right_arm列表的字典
            vision_app_msg: 包含选择索引的二维列表

        返回:
            包含选定left_arm和right_arm的字典
        """
        try:
            # 获取选择索引
            select_index = vision_app_msg[1][1]
        except (IndexError, TypeError):
            select_index = 0  # 默认选择第一个

        # 确保索引在有效范围内
        left_arm_options = pose_tuple['left_arm']
        right_arm_options = pose_tuple['right_arm']

        # 获取最大有效索引
        max_index = min(len(left_arm_options), len(right_arm_options)) - 1
        select_index = max(0, min(select_index, max_index))  # 限制在有效范围内

        # 返回选定数据
        return {
            'left_arm': [left_arm_options[select_index]],
            'right_arm': [right_arm_options[select_index]]
        }

    def send_voice(self, msg, end=None):
        """发送语音消息，如果语音服务未启用或连接断开则不执行"""
        status = self.init['parameter_cfg']['voice_config']['use']

        try:
            if hasattr(WS, 'loop') and WS.loop.is_closed():
                if self.log_msg["voice_disconnection"][1] == 1:logging.error(self.log_msg["voice_disconnection"][0].format())
                return
            if not hasattr(WS, 'websocket') or WS.websocket is None:
                if self.log_msg["voice_disconnection"][1] == 1:logging.error(self.log_msg["voice_disconnection"][0].format())
                return
        except (RuntimeError, AttributeError):
            return
        try:
            if end == False:
                WS.send_msg("TASK_DONE: failed")
            elif end == True:
                WS.send_msg("TASK_DONE: success")
            elif msg:
                WS.send_msg(msg)
        except (RuntimeError, ConnectionError, AttributeError):
            if self.log_msg["voice_error"][1] == 1:logging.error(self.log_msg["voice_error"][0].format())

    def end_voice(self):
        WS.send_msg("TASK_DONE: failed")

    def analyze_roi_color_simple(self, roi_coords, camera_num=1, image=None):
        """使用独立的图像获取器分析颜色"""
        if image is None:
            a = time.time()
            for i in range(camera_num):
                image = self.image_getter.get_image()
                if self.log_msg["get_image"][1] == 1:
                    logging.info(self.log_msg["get_image"][0].format(i))

            b = time.time()
            c = b - a
            if self.log_msg["get_image_time"][1] == 1:
                logging.info(self.log_msg["get_image_time"][0].format(c))
            if image is None:
                return "获取图像失败", 0, 0, 0, None

        # 创建带ROI标记的图像副本
        image_with_roi = image.copy()

        # 直接进行颜色分析
        x, y, w, h = roi_coords
        try:
            # 确保ROI在图像范围内
            img_height, img_width = image.shape[:2]
            x = max(0, min(x, img_width - 1))
            y = max(0, min(y, img_height - 1))
            w = max(1, min(w, img_width - x))
            h = max(1, min(h, img_height - y))

            # 在图像上绘制ROI矩形
            cv2.rectangle(image_with_roi, (x, y), (x + w, y + h), (0, 255, 0), 2)  # 绿色边框，线宽2

            # 提取ROI区域
            roi = image[y:y+h, x:x+w]

            if roi.size == 0:
                return "无效ROI", 0, 0, 0, image_with_roi

            # 计算平均颜色
            avg_color = np.mean(roi, axis=(0, 1))
            avg_b, avg_g, avg_r = avg_color

            # 在图像上添加颜色信息文本
            color_info = f"Color: {self._detect_color_type_hsv(avg_r, avg_g, avg_b)}"
            cv2.putText(image_with_roi, color_info, (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

            # 使用HSV方法检测颜色
            color_name = self._detect_color_type_hsv(avg_r, avg_g, avg_b)
            return color_name, avg_r, avg_g, avg_b, image_with_roi

        except Exception as e:
            # 在异常情况下也返回带ROI标记的图像
            error_msg = f"分析错误: {str(e)}"
            cv2.putText(image_with_roi, error_msg, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            return error_msg, 0, 0, 0, image_with_roi

    def _detect_color_type_hsv(self, r, g, b):
        """使用HSV颜色空间更精确地判断颜色类型"""
        # 将RGB转换为HSV
        rgb_color = np.uint8([[[b, g, r]]])  # 注意OpenCV使用BGR顺序
        hsv_color = cv2.cvtColor(rgb_color, cv2.COLOR_BGR2HSV)
        h, s, v = hsv_color[0][0]
        # 定义HSV颜色范围（OpenCV中H范围是0-180，S和V范围是0-255）
        color_ranges = {
            "红色": [(0, 10), (170, 180)],
            "橙色": [(11, 25)],
            "黄色": [(26, 35)],
            "绿色": [(36, 85)],
            "青色": [(86, 100)],
            "蓝色": [(101, 130)],
            "紫色": [(131, 150)],
            "粉色": [(151, 169)],
        }
        # 首先检查是否为黑色、灰色或白色
        if v < 30:  # 亮度很低，接近黑色
            return "黑色"
        elif s < 40:  # 饱和度很低，调整为更合理的阈值
            if v > 200:  # 高亮度
                return "白色"
            elif v > 150:  # 较高亮度
                return "亮灰色"
            elif v > 80:   # 中等亮度
                return "灰色"
            else:          # 低亮度但饱和度低
                return "深灰色"

        # 检查亮度是否较低但不是黑色
        if v < 60:
            return "暗色"

        # 根据色相判断颜色
        for color_name, ranges in color_ranges.items():
            for h_range in ranges:
                if h_range[0] <= h <= h_range[1]:
                    # 对于紫色范围，增加额外的饱和度检查
                    if color_name == "紫色" and s < 80:
                        return "灰色偏紫"  # 低饱和度的紫色更接近灰色
                    return color_name
        return "未知颜色"

    def save_status_periodically(self,status_file, start_time,story_time):
        while story_time>=10:

            current_time = time.time()
            story_time = 70 - (current_time - start_time)
            status_data = {}
            if os.path.exists(status_file):
                try:
                    with open(status_file, 'r', encoding='utf-8') as f:
                        status_data = json.load(f)
                except:
                    status_data = {}
            
            status_data['story_time'] = int(story_time)
            if self.log_msg["story_time"][1] == 1:logging.info(self.log_msg["story_time"][0].format(story_time))

            try:
                with open(status_file, 'w', encoding='utf-8') as f:
                    json.dump(status_data, f, indent=2, ensure_ascii=False)
            except Exception as e:
                print(f"写入状态文件失败: {e}")
            time.sleep(3)  # 每3秒保存一次

    def _write_status_file(self, name,status):
        """写入状态到JSON文件"""
        try:
            # 确保目录存在
            self.status_file = "/home/dexforce/workspace/dexe_application/qt/auto_config.json"
            os.makedirs(os.path.dirname(self.status_file), exist_ok=True)
            
            # 先读取现有配置（如果文件存在）
            status_data = {}
            if os.path.exists(self.status_file):
                try:
                    with open(self.status_file, 'r', encoding='utf-8') as f:
                        status_data = json.load(f)
                    status_data[name] = status
                    with open(self.status_file, 'w', encoding='utf-8') as f:
                        json.dump(status_data, f, indent=2, ensure_ascii=False)
                except:
                    time.sleep(0.5)
                    with open(self.status_file, 'r', encoding='utf-8') as f:
                        status_data = json.load(f)
                    status_data[name] = status
                    with open(self.status_file, 'w', encoding='utf-8') as f:
                        json.dump(status_data, f, indent=2, ensure_ascii=False)
            print(f"Pickwiz状态已更新: {status}")
        except Exception as e:
            print(f"写入状态文件失败: {e}")

    def _read_status_file(self):
        """写入状态到JSON文件"""
        try:
            self.status_file = "/home/dexforce/workspace/dexe_application/qt/auto_config.json"
            os.makedirs(os.path.dirname(self.status_file), exist_ok=True)
            status_data = {}
            if os.path.exists(self.status_file):
                try:
                    with open(self.status_file, 'r', encoding='utf-8') as f:
                        status_data = json.load(f)
                except:
                    status_data = {}
            return status_data
        except Exception as e:
            print(f"写入状态文件失败: {e}")

    # xiugai 以下为增加新功能：物体检测 相关代码修改
    """
    # 在机器人任务配置中使用YOLO检测的完整示范
    "判断_物品存在": {
        "yolo_vision": true,
        "visual_judge": {
            "T": ["物品存在时的动作序列"],
            "F": ["物品不存在时的动作序列"]
        },
        "vision_0": {
            "yolo_analyze": {
                "roi_coords": [1103, 390, 12, 50],
                "camera_num": 1,
                "class_name": "capsule",
                "conf_threshold": 0.5,
                "save": {"T": true, "F": true},
                "name": "item_detect",
                "model_path": "C:/Users/HO/Desktop/dexe_application/models/detect_capsule_cup.pt"
            }
        }
    }
    """
    def analyze_roi_yolo(self, roi_coords, camera_num=1, class_name="", conf_threshold=0.5, model_path="", image=None, detect_name="", image_save=None):
        """使用YOLO模型分析ROI区域内是否存在目标物品（采用掩码模式）"""
        
        # 获取图像（复用现有图像获取逻辑）
        if image is None:
            for i in range(camera_num):
                image = self.image_getter.get_image()
                if self.log_msg["get_image"][1] == 1:
                    logging.info(self.log_msg["get_image"][0].format(i))
            if image is None:
                return "F", 0, None
        
        # 创建带ROI标记的图像副本 - 与detect_roi.py保持一致
        image_with_roi = image.copy()
        
        try:
            # 处理ROI坐标 - 统一使用 (x, y, w, h) 格式
            x, y, w, h = roi_coords
            img_height, img_width = image.shape[:2]
            
            # 验证ROI坐标（与detect_roi.py相同的边界检查）
            x = max(0, min(x, img_width - 1))
            y = max(0, min(y, img_height - 1))
            w = max(1, min(w, img_width - x))
            h = max(1, min(h, img_height - y))
            
            # 在图像上绘制ROI矩形 - 与detect_roi.py完全一致的绘制方式
            cv2.rectangle(image_with_roi, (x, y), (x + w, y + h), (0, 0, 255), 2)  # 红色边框，与detect_roi.py一致
            cv2.putText(image_with_roi, "ROI", (x, y - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)  # 红色文字
            
            # 运行YOLO模型（在全图上运行，然后过滤ROI内的结果）- 与detect_roi.py相同的掩码模式
            detection_result = self._run_yolo_detection_masked(image, model_path, class_name, conf_threshold, (x, y, w, h))
            
            detection_count = 0
            best_confidence = 0
            
            # 绘制检测结果 - 与detect_roi.py一致的绘制风格
            if detection_result['detected']:
                for det in detection_result['detections']:
                    if det['in_roi']:
                        detection_count += 1
                        if det['confidence'] > best_confidence:
                            best_confidence = det['confidence']
                        
                        # 绘制检测框 - 绿色边框，与detect_roi.py一致
                        x1, y1, x2, y2 = det['bbox_abs']
                        cv2.rectangle(image_with_roi, (x1, y1), (x2, y2), (0, 255, 0), 2)
                        
                        # 添加标签 - 与detect_roi.py一致的标签格式
                        label = f"{det['class']} {det['confidence']:.2f}"
                        cv2.putText(image_with_roi, label, (x1, y1 - 10), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            
            # 添加检测统计信息 - 与detect_roi.py类似的信息显示
            stats_text = f"ROI检测: {detection_count}个{class_name}"
            cv2.putText(image_with_roi, stats_text, (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            
            # 在图像上显示ROI坐标信息
            roi_info = f"ROI: [{x},{y},{w},{h}]"
            cv2.putText(image_with_roi, roi_info, (10, 60), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            result = "T" if detection_count > 0 else "F"
            confidence = best_confidence if detection_count > 0 else 0
            
            # 保存检测图片（如果需要）
            if image_save and image_save.get(result, False) and image_with_roi is not None:
                self._save_detection_image(image_with_roi, detect_name, result, class_name, confidence)
            
            return result, confidence, image_with_roi
            
        except Exception as e:
            error_msg = f"YOLO分析错误: {str(e)}"
            cv2.putText(image_with_roi, error_msg, (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            logging.error(f"YOLO分析错误: {str(e)}")
            return "F", 0, image_with_roi

    def _save_detection_image(self, image, detect_name, result, class_name, confidence):
        """保存检测结果图片"""
        try:
            # 创建保存目录
            error_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'qt', 'error')
            os.makedirs(error_dir, exist_ok=True)
            
            # 生成文件名 - 包含时间戳和检测结果
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            status = "success" if result == "T" else "error"
            filename = f"{detect_name}_yolo_{status}_{timestamp}.jpg"
            filepath = os.path.join(error_dir, filename)
            
            # 保存图像
            cv2.imwrite(filepath, image)
            
            if self.log_msg["save_error_image"][1] == 1:
                log_msg = self.log_msg["save_error_image"][0].format(
                    status, filepath, result, class_name, confidence
                )
                logging.info(log_msg)
                
        except Exception as e:
            logging.error(f"保存YOLO检测图片失败: {str(e)}")

    def _process_yolo_vision(self, yolo_cfg: Dict, parameter_list: Dict) -> str:
        """处理 YOLO 视觉检测配置（使用掩码模式，与detect_roi.py一致）"""
        roi_coords = yolo_cfg.get("roi_coords")
        camera_num = yolo_cfg.get("camera_num", parameter_list["camera_config"]["camera_num"])
        effective_num = yolo_cfg.get("effective_num", parameter_list["camera_config"]["default_effective_num"])
        image_save = yolo_cfg.get("save", {"T": False, "F": False})
        class_name = yolo_cfg.get("class_name")
        conf_threshold = yolo_cfg.get("conf_threshold", 0.5)
        model_path = yolo_cfg.get("model_path")
        detect_name = yolo_cfg.get("name", "yolo_detect")
        
        if not all([roi_coords, class_name, model_path]):
            logging.error("Missing required YOLO configuration parameters")
            return "F"
        
        # 执行多次检测（取最佳结果）- 与detect_roi.py的多次检测逻辑对应
        best_result = "F"
        best_confidence = 0.0
        best_image = None
        
        for i in range(effective_num):
            result, confidence, image = self.analyze_roi_yolo(
                roi_coords=roi_coords,
                camera_num=camera_num,
                class_name=class_name,
                conf_threshold=conf_threshold,
                model_path=model_path,
                detect_name=detect_name,
                image_save=image_save
            )
            
            # 记录最佳结果
            if result == "T" and confidence > best_confidence:
                best_result = "T"
                best_confidence = confidence
                best_image = image
            
            # 如果已经检测到目标，可以提前结束（优化性能）
            if best_result == "T" and confidence >= 0.8:  # 高置信度时提前结束
                logging.info(f"高置信度检测到目标，提前结束检测循环")
                break
        
        # 保存最佳检测结果图片
        if best_image is not None:
            if best_result == "T" and image_save.get("T", False):
                self._save_detection_image(best_image, detect_name, "T", class_name, best_confidence)
            elif best_result == "F" and image_save.get("F", False):
                self._save_detection_image(best_image, detect_name, "F", class_name, best_confidence)
        
        logging.info(f"YOLO检测最终结果: {best_result}, 置信度: {best_confidence:.3f}")
        return best_result


    def move_posetuning_list(self, work_name, text=""):
        """
        """
        # [86.43°, -149.99°, 66.38°, 0.00°]
       

        # # 手臂打包姿态
        # move_cfg = {
        #     "left_arm": [[0.7784073464102069, -1.571592653589793, 0.0, -1.571592653589793, 0.0, 0.0, 0.0]],
        #     "left_arm_speed_ratio": [-3.091592653589793],
        #     "right_arm": [[-0.7815926535897931, 1.5684073464102069, 0.0, 1.5684073464102069, 0.0, 0.0, 0.0]],
        #     "right_arm_speed_ratio": [-3.091592653589793]
        # }

        # # 躯干打包姿态
        # move_cfg = {
        #     "torso": [[1.5084073464102069, -2.617592653589793, 1.1584073464102069, 0.0]],
        #     "torso_speed_ratio": [0.03],
        #     "head": [[0.0, 0.0]],
        #     "head_speed_ratio": [0.03]
        # }

        # success = self.robot_app.w1_manager.move_joint_full_body(
        #     waypoints_dict = move_cfg,
        #     speed_ratio = 0.5
        # )



        config_list = self.init['parameter_cfg']["pose_list"][work_name]
        cfg = self.init['parameter_cfg']["pose_list"][work_name]
        parameter_list =  self.init['parameter_cfg']
        euler = self.init['calibration_cfg']["robot_1"]["euler"]
        sequence_move_tuple = {"left_arm": [], "right_arm": []}
        vv_config = parameter_list['vision_voice_config']
        va_config = parameter_list['vision_app_config']
        id1 = 0
        arm = []
        q1 = []
        go_home_work_name = None
        self.status = self._read_status_file()
        if work_name == '回原点' and self.status['goinghome'] == True:
            if parameter_list['auto_gohome']["use"] == True: 
                time.sleep(0.5)
                if self.log_msg["read_current_module"][1] == 1:
                    logging.info(self.log_msg["read_current_module"][0].format(self._read_status_file()['current_module']))
                go_home_work_name = self._read_status_file()['current_module']
                if "return_gohome" in parameter_list["pose_list"][go_home_work_name]:
                    work_name = go_home_work_name
                    config_list = self.init['parameter_cfg']["pose_list"][work_name]["return_gohome"]
                    cfg = self.init['parameter_cfg']["pose_list"][work_name]["return_gohome"]
            else:
                if self.log_msg["go_home_error1"][1] == 1:logging.info(self.log_msg["go_home_error1"][0].format())
                return False

        if self.status["goinghome"]== True and self.status["stop_num"]==0:
            logging.info(f'停止任务:{work_name}')
            return 'stopping'
        elif self.status["goinghome"]== True and self.status["stop_num"]==1:
            logging.info(f'变换:{work_name}')
            self._write_status_file("stop_num",0)

        if parameter_list['auto_gohome']["use"] == True:
            self._write_status_file("current_module",work_name)

        if "voice_msg" in config_list and self.status=="running":
            self.send_voice(config_list["voice_msg"][0])

        if "voice_interaction" in config_list and "replay" not in config_list:
            self.send_voice(config_list["voice_interaction"][0])
            time.sleep(config_list["voice_interaction"][1])
            self.send_voice(config_list["voice_interaction"][2])


        if "replay" in config_list and config_list['replay']["use"]==True:
            if parameter_list["use_robot"] == True:
                a = time.time()
                if "voice_interaction" in config_list:
                    self.send_voice(config_list["voice_interaction"][0])

                if "speed_ratio" in config_list['replay']: speed_ratio = config_list['replay']["speed_ratio"]
                else: speed_ratio =1

                if "start_time" in config_list['replay']: start_time = config_list['replay']["start_time"]
                else: start_time =25

                if "run_times" in config_list['replay']: run_times = config_list['replay']["run_times"]
                else: run_times =10


                # 创建停止事件和线程
                self.stop_saving = threading.Event()
                status_file = "/home/dexforce/workspace/dexe_application/qt/auto_config.json"
                os.makedirs(os.path.dirname(status_file), exist_ok=True)
                save_thread = threading.Thread(target=self.save_status_periodically, args=(status_file, a,config_list["wait_time"]))
                save_thread.start()

                self.robot_app.replay_waypoints(speed_ratio=speed_ratio, start_time=start_time, run_times=run_times)
                left_arm_qpos = [0.158, -0.746, -0.026, -1.946, 0.082, -0.165, 0.059]
                head_status = [0, -38]
                movel_cfg = { "head_speed_ratio": [0.5]}
                movel_cfg["head"] = [list(np.deg2rad(head_status))]
                move_cfg = {"left_arm":[left_arm_qpos],"head":[list(np.deg2rad(head_status))],"head_speed_ratio":[0.7]}
                

                # try:
                success = self.robot_app.w1_manager.move_joint_full_body(
                        waypoints_dict = move_cfg,
                        speed_ratio = 0.8
                    )
                if success == False:
                    return False
                # finally:
                #     # 确保线程被停止
                #     self.stop_saving.set()
                #     save_thread.join()
                    
                b = time.time()
                try:
                    self.status_file = status_file
                    status_data = {}
                    if os.path.exists(self.status_file):
                        try:
                            with open(self.status_file, 'r', encoding='utf-8') as f:
                                status_data = json.load(f)
                        except:
                            status_data = {}
                        status_data['story_time'] = "no"
                        with open(self.status_file, 'w', encoding='utf-8') as f:
                            json.dump(status_data, f, indent=2, ensure_ascii=False)     

                except Exception as e:
                    print(f"写入状态文件失败: {e}")


                if "voice_interaction" in config_list:
                    while b-a<=config_list["voice_interaction"][1]:
                        time.sleep(1)
                        b = time.time()
                    self.send_voice(config_list["voice_interaction"][2])
                if "wait_time" in config_list:
                    while b-a<=config_list["wait_time"]:
                        time.sleep(1)
                        b = time.time()
                return True
            return True

        if "rgb_vision" in config_list:
            self.status = self._read_status_file()
            if self.status['status'] in ['stopping','idle']:
                return 'stopping'
            a = time.time()
            vision_results = []  # 存储每个vision检测的结果（"T"或"F"）

            # 遍历所有vision配置
            for vision_key in [k for k in config_list if k.startswith("vision_")]:
                vision_cfg = config_list[vision_key]

                if "color_analyze" in vision_cfg:
                    color_cfg = vision_cfg["color_analyze"]
                    roi_coords = color_cfg.get("roi_coords")
                    camera_num = parameter_list["camera_config"]["camera_num"]
                    if "camera_num" in color_cfg: camera_num = color_cfg["camera_num"]
                    effective_num=parameter_list["camera_config"]["default_effective_num"]
                    if "effective_num" in color_cfg: effective_num = color_cfg["effective_num"]
                    image_save = {"T":False,"F":False}
                    if "save" in color_cfg: image_save = color_cfg["save"]
                    expected_color = color_cfg.get("color")
                    detect_name = vision_cfg['color_analyze']["name"]

                    if roi_coords and expected_color:
                        # 调用颜色分析函数
                        a = time.time()
                        for i in range(effective_num):
                            color_name, avg_r, avg_g, avg_b ,image= self.analyze_roi_color_simple(roi_coords,camera_num)
                            if self.log_msg["get_image"][1] == 1:logging.info(self.log_msg["get_image"][0].format(i))
                            result = "T" if set(expected_color) & set(color_name) else "F"

                            if result == 'F' and image_save.get('F', False):
                                # 保存错误图片到error文件夹
                                try:
                                    error_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'vision_save_data')
                                    os.makedirs(error_dir, exist_ok=True)

                                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                                    filename = f"{detect_name}_error_F_{timestamp}.jpg"
                                    filepath = os.path.join(error_dir, filename)

                                    cv2.imwrite(filepath, image)
                                    if self.log_msg["save_error_image"][1] == 1:
                                        logging.info(self.log_msg["save_error_image"][0].format(filepath, "F", color_name))
                                except Exception as e:
                                
                                    logging.error(f"保存错误图片失败: {str(e)}")

                            elif result == 'T' and image_save.get('T', False):
                                # 保存正确图片到error文件夹
                                try:
                                    error_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'vision_save_data')
                                    os.makedirs(error_dir, exist_ok=True)

                                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                                    filename = f"{detect_name}_success_T_{timestamp}.jpg"
                                    filepath = os.path.join(error_dir, filename)

                                    cv2.imwrite(filepath, image)
                                    if self.log_msg["save_error_image"][1] == 1:
                                        logging.info(self.log_msg["save_error_image"][0].format(filepath, "T", color_name))
                                except Exception as e:
                                    logging.error(f"保存成功图片失败: {str(e)}")

                            if self.log_msg.get("vision_color_check", [None, 0])[1] == 1:
                                logging.info(f"Vision检测 {vision_key}: ROI={roi_coords}, 期望颜色={expected_color}, 检测颜色={color_name}, 结果={result}")
                            if result == 'T':
                                break
                        vision_results.append(result)
            result_pattern = "".join(vision_results)
            b = time.time()
            c=b-a
            if self.log_msg["rgb_time"][1] == 1:logging.info(self.log_msg["rgb_time"][0].format(c))

            # 检查结果是否在visual_judge中定义
            if "visual_judge" in config_list and result_pattern in config_list["visual_judge"]:
                return_pattern = config_list["visual_judge"][result_pattern]
                if self.log_msg["vision_pattern_match"][1] == 1:logging.info(self.log_msg["vision_pattern_match"][0].format(result_pattern,return_pattern))

                return return_pattern
            else:
                if self.log_msg["vision_no_pattern_match"][1] == 1:logging.info(self.log_msg["vision_no_pattern_match"][0].format(result_pattern))

        # xiugai
        if "yolo_vision" in config_list:
            self.status = self._read_status_file()
            if self.status['status'] in ['stopping','idle']:
                return 'stopping'
            a = time.time()
            yolo_vision_results = []  # 单独存储YOLO检测结果
            
            # 遍历所有vision配置，只处理YOLO检测
            for vision_key in [k for k in config_list if k.startswith("vision_")]:
                vision_cfg = config_list[vision_key]
                
                if "yolo_analyze" in vision_cfg:
                    yolo_cfg = vision_cfg["yolo_analyze"]
                    result = self._process_yolo_vision(yolo_cfg, parameter_list)
                    yolo_vision_results.append(result)
                    
                    if self.log_msg.get("yolo_vision_check", [None, 0])[1] == 1:
                        logging.info(f"YOLO检测 {vision_key}: ROI={yolo_cfg.get('roi_coords')}, 目标类别={yolo_cfg.get('class_name')}, 结果={result}")
            
            yolo_result_pattern = "".join(yolo_vision_results)
            b = time.time()
            c = b - a
            if self.log_msg.get("yolo_time", [None, 0])[1] == 1:
                logging.info(f"YOLO检测总耗时: {c:.2f}秒")
            
            # 检查YOLO检测结果是否在visual_judge中定义
            if "visual_judge" in config_list and yolo_result_pattern in config_list["visual_judge"]:
                return_pattern = config_list["visual_judge"][yolo_result_pattern]
                if self.log_msg.get("yolo_pattern_match", [None, 0])[1] == 1:
                    logging.info(f"YOLO检测模式匹配: {yolo_result_pattern} -> {return_pattern}")
                return return_pattern
            else:
                if self.log_msg.get("yolo_no_pattern_match", [None, 0])[1] == 1:
                    logging.info(f"YOLO检测无匹配模式: {yolo_result_pattern}")


        for pose_cfg in config_list:
            # 构建运动坐标序列
            if "tpose" in pose_cfg or "jpose" in pose_cfg:
                arm = []
                if self.log_msg["move_status"][1] == 1:
                    logging.info(self.log_msg["move_status"][0].format(work_name, pose_cfg))
                cfg = config_list[pose_cfg]
                task_type = "MoveL" if "tpose" in pose_cfg else "MoveJ"
                if "use_arm" not in cfg:
                    cfg["use_arm"] = "all"
                cfg_use_arm = cfg["use_arm"]
                if cfg_use_arm != "all":
                    arm = [cfg_use_arm]
                # 处理vision_app信息
                p_teach_pose = []
                if 'vision_app' in cfg: # 确认使用视觉识别功能
                    vision_app_msg = cfg['vision_app']

                    if "vision_voice_config" in parameter_list and work_name in vv_config["effective_range"]:
                        for key in vv_config:
                            keywords = key.split('、')
                            if any(keyword in text for keyword in keywords):
                                vision_app_msg[0][0] = vv_config[key]["send"]
                                self.send_voice(vv_config[key]["send_voice"])
                                break  # 匹配到第一个就停止
                        else:  # 如果遍历完全部都没有满足条件
                            vision_app_msg[0][0] = vv_config['none_identify']["send"]
                            self.send_voice(vv_config['none_identify']["send_voice"])
                    if vision_app_msg[2] == "send_recv" and va_config["all_use_vision"]==True: # 触发视觉, 记录坐标
                        pose_tuple, _ , vision_pose = self.vision_app.send_recv(vision_app_msg[0][0],work_name=work_name)
                        self.write_pose(pose_tuple,vision_app_msg[1][0])
                        if vision_pose == vv_config["none_identify"]['sign'] and work_name in vv_config["effective_range"]:
                            vision_app_msg[0][0] = vv_config['none_identify']["send"]
                            for key in vv_config:
                                keywords = key.split('、')
                                if any(keyword in text for keyword in keywords):
                                    self.send_voice(vv_config[key]["recv_none_voice"])
                                    pose_tuple, _ , vision_pose = self.vision_app.send_recv(vision_app_msg[0][0],work_name=work_name)
                                    self.write_pose(pose_tuple,vision_app_msg[1][0])
                                    if vision_pose == vv_config["none_identify"]['sign']:
                                        self.send_voice(vv_config["none_identify"]["recv_none_voice"])
                                        return False
                                    break
                            else:
                                self.send_voice(vv_config['none_identify']["recv_none_voice"])
                                pose_tuple, _ , vision_pose = self.vision_app.send_recv(vision_app_msg[0][0],work_name=work_name)
                                self.write_pose(pose_tuple,vision_app_msg[1][0])
                                if vision_pose == vv_config["none_identify"]['sign']:
                                    self.send_voice(vv_config["none_identify"]["recv_none_voice"])
                                    return False
                        pose_tuple = self.select_pose_data(pose_tuple,vision_app_msg[1][1])
                        # print('读取前的视觉坐标',pose_tuple['left_arm'])

                    if vision_app_msg[2] == "osend" and va_config["all_use_vision"]==True:
                        self.vision_app.osend(pose_cfg['vision_app'][0])
                    if vision_app_msg[2] == "orecv" and va_config["all_use_vision"]==True:
                        pose_tuple, pose_param_list = self.vision_app.orecv(pose_cfg['vision_app'][0])

                    if arm!=[] and 't' in cfg or va_config["all_use_vision"]==False:
                        if va_config["all_use_vision"]==False:
                            vision_app_msg[0][1] = 0
                        if vision_app_msg[0][1] == 0: # 使用历史视觉
                            pose_tuple = self.read_vision_app_msg(vision_app_msg[1][0],vision_app_msg[1][1])
                            # print('读取到的坐标',pose_tuple['left_arm'])

                    if pose_tuple['left_arm'][0] == []:
                        q1.append(1)
                    else:
                        q1.append(pose_tuple['left_arm'][0][0])
                    if "visual_judge" in config_list and "not_return" not in config_list[pose_cfg]:
                        if len(q1) == 2 and q1[0] == 1 and q1[1] ==1:
                            if self.log_msg["visual_judge"][1] == 1:logging.info(self.log_msg["visual_judge"][0].format(config_list["visual_judge"]["12_1"]))
                            return config_list["visual_judge"]["12_1"]
                        elif len(q1) == 2 and q1[0] == 1 :
                            if self.log_msg["visual_judge"][1] == 1:logging.info(self.log_msg["visual_judge"][0].format(config_list["visual_judge"]["1_1"]))
                            return config_list["visual_judge"]["1_1"]
                        elif len(q1) == 2 and q1[1] == 1 :
                            if self.log_msg["visual_judge"][1] == 1:logging.info(self.log_msg["visual_judge"][0].format(config_list["visual_judge"]["2_1"]))
                            return config_list["visual_judge"]["2_1"]
                        elif len(q1) == 1 and q1[0] == 1 :
                            if self.log_msg["visual_judge"][1] == 1:logging.info(self.log_msg["visual_judge"][0].format(config_list["visual_judge"]["1"]))
                            return config_list["visual_judge"]["1"]
                    elif "visual_judge" in config_list and "not_return" in config_list[pose_cfg]:
                        continue

                # 计算目标姿态
                if task_type == "MoveL":
                    o_pose = {"left_arm": [], "right_arm": []} # 初始化为字典, 包含两个空列表
                    if "t" in cfg and isinstance(cfg["t"], str): # 字符串, 用basic_pose的固定坐标
                        pose_name = cfg["t"]
                        if cfg_use_arm == "same" and not pose_name.startswith(("l_", "r_")):
                            pose_name = f"{'l_' if arm == 'left_arm' else 'r_'}{pose_name}"
                        elif cfg_use_arm == "dif" and not pose_name.startswith(("l_", "r_")):
                            pose_name = f"{'r_' if arm == 'left_arm' else 'l_'}{pose_name}"

                        elif  (cfg_use_arm == "right_arm" or  cfg_use_arm == "left_arm") and 'vision_app' not in cfg:
                            if cfg_use_arm == "right_arm":
                                pose_name_r = f"{'r_'}{pose_name}"
                                right_basic = self.init['parameter_cfg']["pose_list"]["basic_pose"][pose_name_r]
                                if  len(right_basic)>1:
                                    o_pose['right_arm'] = [right_basic]
                                else:
                                    o_pose['right_arm'] = [[right_basic]]
                                if p_teach_pose!=[]:
                                    o_pose['right_arm'] = [p_teach_pose]
                            elif cfg_use_arm == "left_arm":
                                pose_name_l = f"{'l_'}{pose_name}"
                                left_basic = self.init['parameter_cfg']["pose_list"]["basic_pose"][pose_name_l]
                                if len(left_basic)>1:
                                    o_pose['left_arm'] = [left_basic]
                                else:
                                    o_pose['left_arm'] = [[left_basic]]
                                if p_teach_pose!=[]:
                                    o_pose['left_arm'] = [p_teach_pose]

                        elif 'vision_app' in cfg and cfg_use_arm == "left_arm":
                            if vision_app_msg[3] == "no_z_ryz1":
                                if self.init["calibration_cfg"]['ROBOT1']['plane_fence_pose']['use'] or self.init["calibration_cfg"]['ROBOT2']['plane_fence_pose']['use'] == True:
                                    if "t" in cfg and isinstance(cfg["t"], str) and arm==['left_arm']:
                                        teach_pose = self.init['parameter_cfg']["pose_list"]["basic_pose"]['l_'+cfg['t']]
                                    elif "t" in cfg and isinstance(cfg["t"], str) and arm==['right_arm']:
                                        teach_pose = self.init['parameter_cfg']["pose_list"]["basic_pose"]['r_'+cfg['t']]
                                    elif "t" in cfg and len(cfg["t"])==6 and not isinstance(cfg["t"], str):
                                        teach_pose = cfg['t']
                                    pose_tuple,p_teach_pose = self.no_z_plane_fence(o_pose,teach_pose,arm,work_name)

                                    for left_data, right_data in zip(pose_tuple['left_arm'], pose_tuple['right_arm']):
                                        left_data[4:] = [0, 0]
                                        right_data[4:] = [0, 0]
                                o_pose = pose_tuple

                            if vision_app_msg[3] in ["no_rxyz","no_z_rxyz"]: # 不使用角度, 角度设置为0
                                for left_data, right_data in zip(pose_tuple['left_arm'], pose_tuple['right_arm']):
                                    left_data[3:] = [0, 0, 0]
                                    right_data[3:] = [0, 0, 0]
                            pose_name_l = f"{'l_'}{pose_name}"
                            left_basic = self.init['parameter_cfg']["pose_list"]["basic_pose"][pose_name_l]
                            if parameter_list['auto_convert_poses']['use'] == True and parameter_list["use_robot"] == True:
                                move_head_torso = config_list["move_head_torso"]
                                current_torso_qpos = list(np.deg2rad(move_head_torso['current_torso']))
                                target_torso_qpos = list(np.deg2rad(move_head_torso['target_torso']))
                                left_cover_pose = self.robot_app.w1_manager.transfer_grasp_pose(
                                            "left_arm",
                                            left_basic,
                                            target_torso_qpos,
                                            current_torso_qpos
                                        )
                                left_basic1 = left_cover_pose[1]
                                left_basic1 = [round(x, 2) for x in left_basic1]
                                o_pose['left_arm'] = [left_basic1]
                            else:
                                o_pose['left_arm'] = [left_basic]

                            # 拿配置里的vision_app_pose配置里的

                            for i in range(len(arm)):
                                o_pose[arm[i]] = [self.posetuning_calculate(
                                    pose_tuple[arm[i]][i],
                                    config_list["apose"][arm[0]],
                                    o_pose[arm[0]][0],
                                    euler
                                )]
                            if vision_app_msg[3]=="no_z_rxyz1": # 不使用高度, 平面标定处理
                                if self.init["calibration_cfg"]['ROBOT1']['plane_fence_pose']['use'] or self.init["calibration_cfg"]['ROBOT2']['plane_fence_pose']['use'] == True:
                                    if "t" in cfg and isinstance(cfg["t"], str) and arm==['left_arm']:
                                        teach_pose = self.init['parameter_cfg']["pose_list"]["basic_pose"]['l_'+cfg['t']]
                                    elif "t" in cfg and isinstance(cfg["t"], str) and arm==['right_arm']:
                                        teach_pose = self.init['parameter_cfg']["pose_list"]["basic_pose"]['r_'+cfg['t']]
                                    elif "t" in cfg and len(cfg["t"])==6 and not isinstance(cfg["t"], str):
                                        teach_pose = cfg['t']
                                    pose_tuple,p_teach_pose = self.no_z_plane_fence(o_pose,teach_pose,arm,work_name)

                                    for left_data, right_data in zip(pose_tuple['left_arm'], pose_tuple['right_arm']):
                                        left_data[3:] = [0, 0, 0]
                                        right_data[3:] = [0, 0, 0]
                                o_pose = pose_tuple

                        elif 'vision_app' in cfg and cfg_use_arm == "right_arm":
                            if vision_app_msg[3] in ["no_rxyz","no_z_rxyz"]: # 不使用角度, 角度设置为0
                                for left_data, right_data in zip(pose_tuple['left_arm'], pose_tuple['right_arm']):
                                    left_data[3:] = [0, 0, 0]
                                    right_data[3:] = [0, 0, 0]
                            pose_name_r = f"{'r_'}{pose_name}"
                            right_basic = self.init['parameter_cfg']["pose_list"]["basic_pose"][pose_name_r]
                            if parameter_list['auto_convert_poses']['use'] == True and parameter_list["use_robot"] == True:
                                move_head_torso = config_list["move_head_torso"]
                                current_torso_qpos = list(np.deg2rad(move_head_torso['current_torso']))
                                target_torso_qpos = list(np.deg2rad(move_head_torso['target_torso']))
                                right_cover_pose = self.robot_app.w1_manager.transfer_grasp_pose(
                                            "right_arm",
                                            right_basic,
                                            target_torso_qpos,
                                            current_torso_qpos
                                        )
                                right_basic1 = right_cover_pose[1]
                                right_basic1 = [round(x, 2) for x in right_basic1]
                                o_pose['right_arm'] = [right_basic1]
                            else:
                                o_pose['right_arm'] = [right_basic]
                            # 拿配置里的vision_app_pose配置里的
                            for i in range(len(arm)):
                                o_pose[arm[i]] = [self.posetuning_calculate(
                                    pose_tuple[arm[i]][i],
                                    config_list["apose"][arm[0]],
                                    o_pose[arm[0]][0],
                                    euler
                                )]
                            if vision_app_msg[3] == "no_z_rxyz1" :  # 不使用高度, 平面标定处理
                                if self.init["calibration_cfg"]['robot_1']['plane_fence_pose']['use'] or self.init["calibration_cfg"]['robot_2']['plane_fence_pose']['use'] == True:
                                    if "t" in cfg and isinstance(cfg["t"], str) and arm == ['left_arm']:
                                        teach_pose = self.init['parameter_cfg']["pose_list"]["basic_pose"]['l_'+cfg['t']]
                                    elif "t" in cfg and isinstance(cfg["t"], str) and arm == ['right_arm']:
                                        teach_pose = self.init['parameter_cfg']["pose_list"]["basic_pose"]['r_'+cfg['t']]
                                    elif "t" in cfg and len(cfg["t"]) == 6 and not isinstance(cfg["t"], str):
                                        teach_pose = cfg['t']
                                    pose_tuple,p_teach_pose = self.no_z_plane_fence(o_pose,teach_pose,arm,work_name)

                                    for left_data, right_data in zip(pose_tuple['left_arm'], pose_tuple['right_arm']):
                                        left_data[3:] = [0, 0, 0]
                                        right_data[3:] = [0, 0, 0]
                                o_pose = pose_tuple

                        elif cfg_use_arm == "all" and not pose_name.startswith(("l_", "r_")):
                            pose_name_l = f"{'l_'}{pose_name}"
                            pose_name_r = f"{'r_'}{pose_name}"

                            left_basic = self.init['parameter_cfg']["pose_list"]["basic_pose"][pose_name_l]
                            right_basic = self.init['parameter_cfg']["pose_list"]["basic_pose"][pose_name_r]
                            if len(left_basic) > 1:
                                o_pose['left_arm'] = left_basic
                            else:
                                o_pose['left_arm'] = [left_basic]
                            if  len(right_basic) > 1:
                                o_pose['right_arm'] = right_basic
                            else:
                                o_pose['right_arm'] = [right_basic]

                            if 'vision_app' in cfg:
                                for i in range(len(arm)):
                                    o_pose[arm[i]] = [self.posetuning_calculate(
                                        pose_tuple[arm[i]][i],
                                        config_list["apose"][arm[0]],
                                        o_pose[arm[0]][0],
                                        euler
                                    )]

                    elif "t" in cfg and len(cfg["t"]) == 6 and not isinstance(cfg["t"], str): # 有使用示教
                        for i in range(len(arm)):
                            o_pose[arm[i]].append(self.posetuning_calculate(
                                pose_tuple[arm[i]][i],
                                config_list["apose"][arm[0]],
                                cfg["t"],
                                euler
                            ))
                    else: # 没使用示教
                        arm_indices = {"left_arm": 0, "right_arm": 0}

                        for current_arm in arm:
                            arm_index = arm_indices[current_arm]
                            pose = pose_tuple[current_arm][arm_index]
                            o_pose[current_arm].append(pose)
                            arm_indices['left_arm'] += 1
                            arm_indices['right_arm'] += 1

                    if "b" in cfg:
                        o_pose = self.apply_offset(o_pose, cfg["b"], offset_type="plane",arm=arm)
                    if "g" in cfg:
                        o_pose = self.apply_offset(o_pose, cfg["g"], offset_type="grab", arm=arm)
                    if "move_head_torso" in config_list and config_list["move_head_torso"]['use'] == True and 'vision_app' in cfg:
                        move_head_torso = config_list["move_head_torso"]
                        current_torso_qpos = list(np.deg2rad(move_head_torso['current_torso']))
                        target_torso_qpos = list(np.deg2rad(move_head_torso['target_torso']))
                        if "ht" in cfg:
                            target_torso_qpos = list(np.deg2rad(cfg["ht"]))
                        # new_pose_tuple = {'left_arm':[],'right_arm':[]}
                        if o_pose["left_arm"] != []:
                            arm_name = 'left_arm'
                            if len(o_pose["left_arm"][0]) == 6:
                                pose = o_pose["left_arm"][0]
                            elif len(o_pose["left_arm"]) == 6:
                                pose = o_pose["left_arm"]
                            if parameter_list["use_robot"] == True:
                                new_pose = self.robot_app.w1_manager.transfer_grasp_pose(
                                            arm_name,
                                            pose,
                                            current_torso_qpos,
                                            target_torso_qpos
                                        )
                            else:
                                new_pose = [True,pose]
                            rounded_values = [round(x, 3) for x in new_pose[1]]
                            o_pose['left_arm'] = [rounded_values]

                        elif o_pose["right_arm"] != []:
                            arm_name = 'right_arm'
                            if len(o_pose["right_arm"][0]) == 6:
                                pose = o_pose["right_arm"][0]
                            elif len(o_pose["right_arm"]) == 6:
                                pose = o_pose["right_arm"]
                            if parameter_list["use_robot"] == True:
                                new_pose = self.robot_app.w1_manager.transfer_grasp_pose(
                                            arm_name,
                                            pose,
                                            np.array(current_torso_qpos),
                                            np.array(target_torso_qpos)
                                        )
                            else :
                                new_pose = [True,pose]
                            rounded_values = [round(x, 3) for x in new_pose[1]]
                            o_pose['right_arm'] = [rounded_values]

                    o_pose1 = deepcopy(o_pose)
                    # print(o_pose1)
                    for key in o_pose1:
                        o_pose1[key] = [item for item in o_pose1[key]]
                    for key in sequence_move_tuple:
                        sequence_move_tuple[key].extend(o_pose1[key])
                    id1 += 1
                elif task_type == 'MoveJ':  # MoveJ
                    o_pose = {"left_arm": [], "right_arm": []}  # 初始化结果字典
                    for current_arm in arm:
                        pose_name = cfg["t"]
                        if isinstance(pose_name, str):  # 检查 pose_name 是否为字符串列表
                            if cfg["use_arm"] == "same" and not pose_name.startswith(("l_", "r_")):
                                pose_name = f"{'l_' if current_arm == 'left_arm' else 'r_'}{pose_name}"
                            elif cfg["use_arm"] == "dif" and not pose_name.startswith(("l_", "r_")):
                                pose_name = f"{'r_' if current_arm == 'left_arm' else 'l_'}{pose_name}"
                            elif cfg["use_arm"] == "all" and not pose_name.startswith(("l_", "r_")):
                                pose_name = f"{'l_' if current_arm == 'left_arm' else 'r_'}{pose_name}"
                            pose_value = self.init['parameter_cfg']["pose_list"]["basic_pose"].get(pose_name)
                        else:
                            pose_value = config_list[pose_cfg][0]
                        o_pose[current_arm].append(pose_value)

                    o_pose1 = deepcopy(o_pose)
                    for key in o_pose1:
                        o_pose1[key] = [item for item in o_pose1[key]]
                    for key in sequence_move_tuple:
                        sequence_move_tuple[key].extend(o_pose1[key])
                    id1 += 1

            if "continuous" in pose_cfg:
                if self.log_msg["continuous"][1] == 1:logging.info(self.log_msg["continuous"][0].format(config_list["continuous"]))
                return config_list["continuous"]
        # 仅动头
        if 't' not in cfg and 'head_torso' in cfg:
            sequence_move_tuple = {'left_arm':[],'right_arm':[]}
            cfg_msg = self.get_cfg_msg(work_name,sequence_move_tuple)

            if parameter_list["use_robot"] == True:
                success = self.robot_app.MoveL(sequence_move_tuple,cfg_msg,work_name,parameter=parameter_list,config_cfg = self.init)
            else:
                success = True
            if success == False:
                return False
            else:
                return True


        if pose_cfg == "movej":
            success = self.robot_app.w1_manager.move_joint_full_body(
                waypoints_dict = cfg[pose_cfg],
                speed_ratio = 0.8
            )
            return success
        
        if arm!=[] and 't' in cfg:
            sequence_move_tuple = self.pad_sequence_move_tuple(sequence_move_tuple)
            if self.log_msg["move_pose"][1] == 1:
                formatted_tuple = self.format_sequence_move_tuple_one_line(sequence_move_tuple)
                logging.info(self.log_msg["move_pose"][0].format(work_name, formatted_tuple))

            cfg_msg = self.get_cfg_msg(work_name,sequence_move_tuple,config_list)
            if self.log_msg["cfg_msg"][1] == 1:
                logging.info(self.log_msg["cfg_msg"][0].format(work_name, self.format_json_compact_inner_lists(cfg_msg)))

            if parameter_list["use_robot"] == True and go_home_work_name == None: # 非回原点轨迹
                success = self.robot_app.MoveL(sequence_move_tuple,cfg_msg,work_name,parameter = parameter_list,config_cfg = self.init)
            else:
                success = self.robot_app.MoveL(sequence_move_tuple,cfg_msg,work_name,parameter = parameter_list,config_cfg = self.init,go_home_log = True)        
                success = self.robot_app.GoHome(speed = parameter_list["pose_list"]['回原点']['speed'])
                self._write_status_file("status","idle")
                time.sleep(0.3)
                self._write_status_file("goinghome",False)
            if success == False:
                return False
            else:
                return True


    def pad_sequence_move_tuple(self, sequence_move_tuple):
        """
        如果左右手的轨迹长度不一致, 则将短的一方用最后一个元素补齐到和长的一致。
        """
        left_len = len(sequence_move_tuple["left_arm"])
        right_len = len(sequence_move_tuple["right_arm"])
        if left_len > right_len and right_len > 0:
            last = sequence_move_tuple["right_arm"][-1]
            sequence_move_tuple["right_arm"].extend([last] * (left_len - right_len))
        elif right_len > left_len and left_len > 0:
            last = sequence_move_tuple["left_arm"][-1]
            sequence_move_tuple["left_arm"].extend([last] * (right_len - left_len))
        return sequence_move_tuple

    def get_cfg_msg(self, work_name, sequence_move_tuple=None,config_list= None):
        hand_pose = self.init['parameter_cfg']["pose_list"]["hand_pose"]
        basic_pose = self.init['parameter_cfg']["pose_list"]["basic_pose"]
        # 按配置字典原始顺序提取所有 tpose/jpose 项
        pose_keys = [k for k in config_list if k.startswith("tpose") or k.startswith("jpose")]

        # 轨迹长度（由 pad_sequence_move_tuple 保证左右数组等长）
        left_len = len(sequence_move_tuple["left_arm"]) if sequence_move_tuple else 0
        right_len = len(sequence_move_tuple["right_arm"]) if sequence_move_tuple else 0

        # 初始化 end_effector 列表
        ee_left = [None] * left_len
        ee_right = [None] * right_len

        # 当前的填充索引
        l_idx = 0
        r_idx = 0

        # 初始化输出列表（按照 head_torso 的方式）
        voice_msg_list = []
        head_torso_list = []
        vision_app_list = []
        torso_speed_list = []
        head_speed_list = []
        left_arm_speed_list = []
        right_arm_speed_list = []
        for k in pose_keys:
            cfg = config_list[k]
            arm = cfg.get("use_arm", "all")
            ee_cfg = cfg.get("end_effector")  # 若不存在, ee_cfg为None
            t_val = cfg.get("t", None)

            # 处理 voice_msg, head_torso, vision_app (保持不变)
            if len(voice_msg_list) == 0 and "vioce_msg" in config_list:
                voice_msg_list.append(config_list["vioce_msg"])
            else:
                voice_msg_list.append(None)
            head_torso_list.append(cfg.get("head_torso", None))
            vision_app_list.append(cfg.get("vision_app", None))
            # 新增: 按照 head_torso 的方式处理速度参数
            torso_speed_list.append(cfg.get("head_torso_speed", 1))
            head_speed_list.append(cfg.get("head_torso_speed", 1))

            # 如果 t_val 为字符串且以 waving_hands_list 结尾, 则认为是多点动作
            if isinstance(t_val, str) and t_val.endswith("waving_hands_list"):
                if arm == "left_arm":
                    print(12)
                    left_arm_speed_list.append(cfg.get("arm_speed", None))
                    n = len(basic_pose.get("l_waving_hands_list", []))
                    # 若存在 end_effector 参数则填充最后一个点, 否则保持为 None
                    if ee_cfg:
                        if isinstance(ee_cfg[1], str):
                            hand_key = f"l_{ee_cfg[1]}"
                            hand_val = hand_pose.get(hand_key) or hand_pose.get(ee_cfg[1]) or [0, 0, 0, 0, 0, 0]
                        else:
                            hand_val = ee_cfg[1]
                        if l_idx + n > left_len:
                            n = left_len - l_idx
                        if n > 0:
                            ee_left[l_idx + n - 1] = [ee_cfg[0], hand_val, ee_cfg[2]]
                    # 无论是否有 end_effector 参数, 跳过这一段的 n 个点
                    l_idx += n
                elif arm == "right_arm":
                    print(123)
                    right_arm_speed_list.append(cfg.get("arm_speed", None))
                    n = len(basic_pose.get("r_waving_hands_list", []))
                    if ee_cfg:
                        if isinstance(ee_cfg[1], str):
                            hand_key = f"r_{ee_cfg[1]}"
                            hand_val = hand_pose.get(hand_key) or hand_pose.get(ee_cfg[1]) or [0, 0, 0, 0, 0, 0]
                        else:
                            hand_val = ee_cfg[1]
                        if r_idx + n > right_len:
                            n = right_len - r_idx
                        if n > 0:
                            ee_right[r_idx + n - 1] = [ee_cfg[0], hand_val, ee_cfg[2]]
                    r_idx += n
            else:
                # 单点动作: 若存在end_effector参数填充, 否则直接占位None
                if arm == "left_arm" and l_idx < left_len:
                    left_arm_speed_list.append(cfg.get("arm_speed", None))
                    if ee_cfg:
                        if isinstance(ee_cfg[1], str):
                            hand_key = f"l_{ee_cfg[1]}"
                            hand_val = hand_pose.get(hand_key) or hand_pose.get(ee_cfg[1]) or [0, 0, 0, 0, 0, 0]
                        else:
                            hand_val = ee_cfg[1]
                        ee_left[l_idx] = [ee_cfg[0], hand_val, ee_cfg[2]]
                    else:
                        ee_left[l_idx] = None
                    l_idx += 1
                elif arm == "right_arm" and r_idx < right_len:
                    right_arm_speed_list.append(cfg.get("arm_speed", None))
                    if ee_cfg:
                        if isinstance(ee_cfg[1], str):
                            hand_key = f"r_{ee_cfg[1]}"
                            hand_val = hand_pose.get(hand_key) or hand_pose.get(ee_cfg[1]) or [0, 0, 0, 0, 0, 0]
                        else:
                            hand_val = ee_cfg[1]
                        ee_right[r_idx] = [ee_cfg[0], hand_val, ee_cfg[2]]
                    else:
                        ee_right[r_idx] = None
                    r_idx += 1
                else:
                    right_arm_speed_list.append(cfg.get("arm_speed", None))

        if right_arm_speed_list == [1]:
            right_arm_speed_list=[]
        if left_arm_speed_list == [1]:
            left_arm_speed_list=[]

        if ee_left == [None]:
            ee_left = []
        if ee_right == [None]:
            ee_right = []

        if all(x is None for x in head_torso_list):
            torso_speed_list = []
            head_speed_list = []

        cfg_msg_dict = {
            "end_effector": {"left_arm": ee_left, "right_arm": ee_right},
            "voice_msg": voice_msg_list,
            "head_torso": head_torso_list,
            "vision_app": vision_app_list,
            "torso_speed_ratio": torso_speed_list,
            "head_speed_ratio": head_speed_list,
            "left_arm_speed_ratio": left_arm_speed_list,
            "right_arm_speed_ratio": right_arm_speed_list
        }
        return cfg_msg_dict


    def apply_offset(self,pose, offset, offset_type="plane", arm=None):
        """应用偏移量"""
        if not isinstance(pose, dict) or not isinstance(arm, list):
            raise ValueError("pose 应该是字典, arm 应该是列表")

        # 初始化结果字典
        result_pose = {key: [] for key in pose.keys()}

        # 初始化每个手臂的索引计数器
        arm_indices = {"left_arm": 0, "right_arm": 0}

        for current_arm in arm:
            # 获取当前手臂的索引
            arm_index = arm_indices[current_arm]

            # 检查索引是否超出范围
            if current_arm not in pose or arm_index >= len(pose[current_arm]):
                print(f"跳过无效的 arm 或超出索引范围: {current_arm}, 索引: {arm_index}")
                continue

            single_pose = pose[current_arm][arm_index].copy()  # 获取当前 arm 的单个 pose

            if offset != [0]:
                if offset_type == "base":
                    single_pose[2] += offset[2]
                    single_pose[0] += offset[0]
                    single_pose[1] += offset[1]
                elif offset_type == "plane":
                    if current_arm == 'right_arm' and self.init["calibration_cfg"]['robot_2']['plane_fence_pose']['use'] == True:
                        # 设置用户坐标系
                        r_fence = self.init["calibration_cfg"]['robot_2']['plane_fence_pose']
                        ro_pos = r_fence['ro_pos']
                        rx_pos = r_fence['rx_pos']
                        rxy_pos = r_fence['rxy_pos']
                        T_matrix = self.cal_userframe_xpos(ro_pos, rx_pos, rxy_pos)  # 设置用户坐标系
                        # 将左右臂坐标转换至平面坐标系
                        plane_pose = self.transform_to_plane(single_pose, T_matrix)
                        plane_pose[2] += offset[2]
                        plane_pose[1] += offset[1]
                        plane_pose[0] += offset[0]
                    elif current_arm == 'left_arm' and self.init["calibration_cfg"]['robot_1']['plane_fence_pose']['use'] == True:
                        l_fence = self.init["calibration_cfg"]['robot_1']['plane_fence_pose']
                        lo_pos = l_fence['lo_pos']
                        lx_pos = l_fence['lx_pos']
                        lxy_pos = l_fence['lxy_pos']
                        T_matrix = self.cal_userframe_xpos(lo_pos, lx_pos, lxy_pos)  # 设置用户坐标系
                        plane_pose = self.transform_to_plane(single_pose, T_matrix)
                        plane_pose[2] -= offset[2]
                        plane_pose[1] += offset[1]
                        plane_pose[0] += offset[0]
                    else:print('有错误123')
                    single_pose = self.inverse_transform_from_plane(plane_pose, T_matrix)
                elif offset_type == "grab":
                    single_pose = self.grabpose_xyz_offset(
                        single_pose, {"x": offset[0], "y": offset[1], "z": offset[2]}
                    )

            # 将处理后的 pose 添加到结果中
            # result_pose[current_arm].append(
            #     [round(num, 3 - len(str(int(num)))) if num != 0 else 0 for num in single_pose]
            # )
            result_pose[current_arm].append(
                single_pose
            )
            # 更新当前手臂的索引
            arm_indices[current_arm] += 1
        if self.log_msg["apply_offset"][1] == 1:
            logging.info(self.log_msg["apply_offset"][0].format(pose,result_pose))
        return result_pose

    def no_z_plane_fence(self,pose_tuple,teach_pose,arm,work_name=None):
        '''
        平面围栏功能, 判断机械臂是否在平面围栏内。
        对于每个手臂的每个坐标, 先转换至平面坐标系,
        根据 z 值限幅后再转换回原始坐标系,
        最终返回经过 z 限幅调整后的坐标数据元组（字典）。
        '''
        # 设置用户坐标系 --- 右臂
        r_fence = self.init["calibration_cfg"]['robot_2']['plane_fence_pose']
        ro_pos = r_fence['ro_pos']
        rx_pos = r_fence['rx_pos']
        rxy_pos = r_fence['rxy_pos']
        right_use = r_fence['use']
        self.right_T_matrix = self.cal_userframe_xpos(ro_pos, rx_pos, rxy_pos)
        # 设置用户坐标系 --- 左臂
        l_fence = self.init["calibration_cfg"]['robot_1']['plane_fence_pose']
        lo_pos = l_fence['lo_pos']
        lx_pos = l_fence['lx_pos']
        lxy_pos = l_fence['lxy_pos']
        left_use = l_fence['use']
        self.left_T_matrix = self.cal_userframe_xpos(lo_pos, lx_pos, lxy_pos)
        vision_app_pose = deepcopy(pose_tuple[arm[0]][0])
        if arm == ['left_arm']:
            p_teachpose = self.transform_to_plane(teach_pose, self.left_T_matrix)
            p_vision_app_pose = self.transform_to_plane(pose_tuple[arm[0]][0], self.left_T_matrix)

            p_teachpose1 = deepcopy(p_teachpose)
            p_teachpose[0] = p_vision_app_pose[0]
            p_teachpose[1] = p_vision_app_pose[1]

            teachpose = self.inverse_transform_from_plane(p_teachpose, self.left_T_matrix)
            pose_tuple[arm[0]][0] = teachpose
            teachpose[3:] = teach_pose[3:]
            if self.log_msg["no_z_plane_fence_p"][1] == 1:
                logging.info(self.log_msg["no_z_plane_fence_p"][0].format(arm[0],p_vision_app_pose,p_teachpose1,p_teachpose))

        elif arm == ['right_arm']:
            p_teachpose = self.transform_to_plane(teach_pose, self.right_T_matrix)
            p_vision_app_pose = self.transform_to_plane(pose_tuple[arm[0]][0], self.right_T_matrix)
            p_teachpose1 = deepcopy(p_teachpose)
            p_teachpose[0] = p_vision_app_pose[0]
            p_teachpose[1] = p_vision_app_pose[1]
            p_teachpose[2] = p_vision_app_pose[2]-10
            teachpose = self.inverse_transform_from_plane(p_teachpose, self.right_T_matrix)
            pose_tuple[arm[0]][0] = teachpose
            teachpose[3:] = teach_pose[3:]
            if self.log_msg["no_z_plane_fence_p"][1] == 1:
                logging.info(self.log_msg["no_z_plane_fence_p"][0].format(arm[0],p_teachpose,p_teachpose1,p_teachpose))

        if self.log_msg["no_z_plane_fence"][1] == 1:
            logging.info(self.log_msg["no_z_plane_fence"][0].format(arm[0],vision_app_pose,teach_pose,teachpose))
        return pose_tuple, teachpose

    def plane_fence(self, pose_tuple, work_name):
        '''
        平面围栏功能, 判断机械臂是否在平面围栏内。
        对于每个手臂的每个坐标, 先转换至平面坐标系,
        根据 z 值限幅后再转换回原始坐标系,
        最终返回经过 z 限幅调整后的坐标数据元组（字典）。
        '''
        # 设置用户坐标系 --- 右臂
        r_fence = self.init["calibration_cfg"]['robot_2']['plane_fence_pose']
        ro_pos = r_fence['ro_pos']
        rx_pos = r_fence['rx_pos']
        rxy_pos = r_fence['rxy_pos']
        right_use = r_fence['use']

        self.right_T_matrix = self.cal_userframe_xpos(ro_pos, rx_pos, rxy_pos)
        # 设置用户坐标系 --- 左臂
        l_fence = self.init["calibration_cfg"]['robot_1']['plane_fence_pose']
        lo_pos = l_fence['lo_pos']
        lx_pos = l_fence['lx_pos']
        lxy_pos = l_fence['lxy_pos']
        left_use = l_fence['use']

        self.left_T_matrix = self.cal_userframe_xpos(lo_pos, lx_pos, lxy_pos)

        # 定义 z 限制
        l_z_down_limit = l_fence['fence_thread']['fence_z'][0]  #左臂, 平面z值最小值
        r_z_down_limit = r_fence['fence_thread']['fence_z'][1] # 右臂, 平面z值最大值
        processed_pose = {}  # 存放处理后的结果
        # 针对每个臂处理
        for arm in pose_tuple:
            processed_pose[arm] = []
            for pose in pose_tuple[arm]:
                # 根据不同臂选择相应的用户坐标变换
                if arm == "left_arm" and left_use:
                    plane_pose = self.transform_to_plane(pose, self.left_T_matrix)
                    if plane_pose[2] < l_z_down_limit:
                        if self.log_msg["plane_fence"][1] == 1:
                            logging.info(self.log_msg["plane_fence"][0].format(plane_pose, l_z_down_limit, l_z_down_limit))
                        plane_pose[2] = l_z_down_limit
                        new_pose = self.inverse_transform_from_plane(plane_pose, self.left_T_matrix)
                    else:
                        new_pose = pose

                elif arm == "right_arm" and right_use:
                    plane_pose = self.transform_to_plane(pose, self.right_T_matrix)
                    if plane_pose[2] > r_z_down_limit:
                        if self.log_msg["plane_fence"][1] == 1:
                            logging.info(self.log_msg["plane_fence"][0].format(plane_pose, r_z_down_limit, r_z_down_limit))
                        plane_pose[2] = r_z_down_limit
                        new_pose = self.inverse_transform_from_plane(plane_pose, self.right_T_matrix)
                    else:
                        new_pose = pose
                else:
                    new_pose = pose
                processed_pose[arm].append(new_pose)
        return processed_pose

    def cal_userframe_xpos(self,o_pos: list, x_pos: list, xy_pos: list):
        """Calculate the User Frame transformation matrix.
        Args:
            o_pos (list): Origin position of the User Frame [x, y, z].
            x_pos (list): A point on X-axis of the User Frame [x, y, z].
            xy_pos (list): A point on the XY plane of the User Frame [x, y, z].

        Returns:
            np.ndarray: 4x4 homogeneous transformation matrix representing the User Frame
        """
        # Convert input positions to numpy arrays

        o_pos = np.array(o_pos)
        x_pos = np.array(x_pos)
        xy_pos = np.array(xy_pos)
        # Calculate the X-axis direction vector
        x_axis = x_pos - o_pos
        x_axis /= np.linalg.norm(x_axis)
        # Calculate the vector in the XY plane
        xy_vector = xy_pos - o_pos
        # Calculate the Z-axis direction vector (cross product of X and XY vectors)
        z_axis = np.cross(x_axis, xy_vector)
        z_axis /= np.linalg.norm(z_axis)
        # Calculate the Y-axis direction vector (cross product of Z and X vectors)
        y_axis = np.cross(z_axis, x_axis)
        # Construct the User Frame transformation matrix
        userframe_xpos = np.eye(4)
        userframe_xpos[:3, 0] = x_axis  # X-axis
        userframe_xpos[:3, 1] = y_axis  # Y-axis
        userframe_xpos[:3, 2] = z_axis  # Z-axis
        userframe_xpos[:3, 3] = o_pos   # Origin position
        return userframe_xpos

    def transform_to_plane(self,pose, T):
        """
        将坐标系转换为平面坐标系
        参数:
            pose: 需要转换的基坐标系坐标, 格式为 [x, y, z, roll, pitch, yaw]
            T: 变换矩阵, 格式为 4x4 的 numpy 数组
        返回:
            pose: 转换后的平面坐标系坐标, 格式为 [x, y, z, roll, pitch, yaw]
        """
        from scipy.linalg import pinv
        position = np.array(pose[:3])
        euler = pose[3:]
        # 计算转换矩阵
        pose_T = np.eye(4)
        pose_T[:3, :3] = R.from_euler('ZYX', euler, degrees=True).as_matrix()
        pose_T[:3, 3] = position
        new_T = pinv(T) @ pose_T
        new_pose = np.concatenate([new_T[:3, 3], R.from_matrix(new_T[:3, :3]).as_euler('xyz', degrees=False)])
        new_pose_list = np.round(new_pose, 2).tolist()
        return new_pose_list

    def inverse_transform_from_plane(self, plane_pose, T):
        """
        将平面坐标转换回原始坐标系
        参数:
            plane_pose: 平面坐标, 格式为 [x, y, z, roll, pitch, yaw]
                        其中平面旋转角采用 'xyz' 顺序, 单位为弧度
            T: 变换矩阵, 格式为 4x4 的 numpy 数组
        返回:
            原始坐标系坐标, 格式为 [x, y, z, roll, pitch, yaw]
            其中角度采用 'ZYX' 顺序, 单位为°（两位小数）
        """
        # 由平面坐标构造变换矩阵（注意平面角度用 'xyz', 弧度）
        plane_position = np.array(plane_pose[:3])
        plane_euler = plane_pose[3:]
        plane_T = np.eye(4)
        plane_T[:3, :3] = R.from_euler('xyz', plane_euler, degrees=False).as_matrix()
        plane_T[:3, 3] = plane_position
        # 原始姿态的变换矩阵: pose_T = T @ plane_T
        pose_T = T @ plane_T
        # 提取原始平移和旋转。原始旋转由 transform_to_plane 使用 'ZYX'（角度制）构造
        original_position = pose_T[:3, 3]
        original_euler = R.from_matrix(pose_T[:3, :3]).as_euler('ZYX', degrees=True)
        original_pose = np.concatenate([original_position, original_euler])
        original_pose_list = np.round(original_pose,2).tolist()
        return original_pose_list

    def grabpose_xyz_offset( self, pose, offset):
        """
        沿着抓取点自身坐标系的方向进行偏移

        参数:
            coord: 抓取点坐标和方向 [x, y, z, a, b, c] (单位: mm, 度)
            offset: 偏移量字典, 如 {"x": 10, "y": 5, "z": 15} (单位: mm)
            euler_order: 欧拉角顺序, 支持 "ZYX"（默认）或 "xyz"

        返回:
            偏移后的新坐标 [x', y', z', a, b, c]
        """
        x, y, z, a, b, c = pose

        # 如果RX和RY均为0, 则直接处理Z偏移（无需旋转）
        if a == 0 and b == 0:
            new_pose = [
                x + offset.get("x", 0),
                y + offset.get("y", 0),
                z + offset.get("z", 0),
                a,
                b,
                c
            ]
            return new_pose

        # 否则计算旋转矩阵（xyz顺序: R = Rx(a) @ Ry(b) @ Rz(c)）
        rx = radians(a)
        ry = radians(b)
        rz = radians(c)

        Rx = np.array([
            [1, 0, 0],
            [0, cos(rx), -sin(rx)],
            [0, sin(rx), cos(rx)]
        ])

        Ry = np.array([
            [cos(ry), 0, sin(ry)],
            [0, 1, 0],
            [-sin(ry), 0, cos(ry)]
        ])

        Rz = np.array([
            [cos(rz), -sin(rz), 0],
            [sin(rz), cos(rz), 0],
            [0, 0, 1]
        ])

        R = np.dot(Rx, np.dot(Ry, Rz))

        # 局部偏移向量
        offset_vec = np.array([
            offset.get("x", 0),
            offset.get("y", 0),
            offset.get("z", 0)
        ])

        # 将局部偏移转换到世界坐标系
        world_offset = np.dot(R, offset_vec)

        # 返回新位姿（角度不变）
        new_pose = [
            x + world_offset[0],
            y + world_offset[1],
            z + world_offset[2],
            a,
            b,
            c
        ]

        return new_pose

    def posetuning_calculate(self, robot_pose, shotpose, grabpose, euler):
        """
        计算示教坐标
        参数:
            robot_pose: 当前坐标
            shotpose: 机器人坐标系下法兰坐标
            grabpose: 机器人坐标系示教的抓取坐标
            euler: 欧拉角顺序
        """
        def poseConvert(pose:list, rotation:str):
            rot_matrix = R.from_euler(rotation, [pose[3],pose[4],pose[5]], degrees=True).as_matrix()
            pose_matrix = np.identity(4)
            pose_matrix[:3,:3] = rot_matrix
            pose_matrix[:3,3] = [pose[0],pose[1],pose[2]]
            return np.mat(pose_matrix)

        if self.log_msg["teach_offset"][1]==1: logging.info(self.log_msg["teach_offset"][0].format(robot_pose,shotpose,grabpose))
        if shotpose[5]=="n":
            return grabpose
        else:
            vision_app_matrix = poseConvert(shotpose, euler)
            teach_matrix = poseConvert(grabpose, euler)
            matrix = np.linalg.inv(vision_app_matrix) @ teach_matrix
            CAM_BD = poseConvert(robot_pose, euler)
            PUT3 = CAM_BD @ matrix
            rxyz = R.from_matrix(PUT3[:3, :3]).as_euler(euler, degrees=True)
            rxyz = [round(num, 2) for num in rxyz]
            x = round(PUT3[0, 3], 2)
            y = round(PUT3[1, 3], 2)
            z = round(PUT3[2, 3], 2)
            return [x, y, z] + rxyz

    # 文件更新函数
    def write_pose(self, pose_tuple, recv_vision_app_msg):
        def write_formatted_json(f, data):
            f.write('{\n')
            f.write('\t"vision_app_pose":\n')
            f.write('\t{\n')

            vision_app_pose = data["vision_app_pose"]
            items = list(vision_app_pose.items())

            for i, (k, v) in enumerate(items):
                # 每个动作占一行, 缩进2个Tab
                f.write('\t\t"{}":{}'.format(
                    k,
                    json.dumps(v, ensure_ascii=False, separators=(',', ':'))
                ))
                if i < len(items) - 1:
                    f.write(',')
                f.write('\n')
            f.write('\t}\n')
            f.write('}\n')

        def safe_write_json(filepath, data):
            """安全的JSON写入函数（原子操作+同步）"""
            temp_path = filepath + '.tmp'
            try:
                # 写入临时文件
                with open(temp_path, 'w', encoding='utf-8') as f:
                    write_formatted_json(f, data)
                    f.flush()  # 确保数据从缓冲区写入文件
                    os.fsync(f.fileno())  # 确保数据写入磁盘
                # 原子性替换（Unix系统保证原子性）
                os.replace(temp_path, filepath)
                return True
            except Exception as e:
                logging.error(f"写入文件失败: {str(e)}")
                if os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except:
                        pass
                raise

        # 1. 获取 JSON 文件路径
        current_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'parameters',
            'vision_app_pose.json'
        )

        # 2. 读取 JSON 文件
        try:
            with open(current_dir, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logging.error(f"读取JSON文件失败: {str(e)}")
            raise

        # 3. 更新 recv_vision_app_msg 对应的 pose 数据
        if recv_vision_app_msg in data["vision_app_pose"]:
            data["vision_app_pose"][recv_vision_app_msg]["left_arm"] = [pose_tuple["left_arm"][0]]
            data["vision_app_pose"][recv_vision_app_msg]["right_arm"] = [pose_tuple["right_arm"][0]]
        else:
            # 如果 recv_vision_app_msg 不在预设的键中, 动态添加
            data["vision_app_pose"][recv_vision_app_msg] = {
                "left_arm": [pose_tuple["left_arm"][0]],
                "right_arm": [pose_tuple["right_arm"][0]]
            }

        # 4. 安全的写入JSON文件
        try:
            safe_write_json(current_dir, data)
            # time.sleep(0.1)
            logging.info(f"已更新 {recv_vision_app_msg} 的 pose 数据到 {current_dir}")

            # 可选：验证写入是否成功
            if self.verify_write(current_dir, data):
                logging.debug("文件写入验证成功")
            else:
                logging.warning("文件写入验证未通过")

        except Exception as e:
            logging.error(f"写入姿势数据失败: {str(e)}")
            raise

    def verify_write(self, filepath, expected_data, timeout=1.0, retry_interval=0.1):
        """验证文件是否已正确写入"""
        # start_time = time.time()
        last_exception = None

        # while time.time() - start_time < timeout:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                current_data = json.load(f)
            if current_data == expected_data:
                return True
            else :
                time.sleep(0.1)
        except Exception as e:
            last_exception = e
        logging.warning(f"文件验证超时，最后错误: {str(last_exception) if last_exception else '无错误'}")
        return False

    def read_vision_app_msg(self,name,pose_id):
        current_dir = os.path.dirname(os.path.abspath(__file__)) + '/parameters/vision_app_pose.json'
        try:
            with open(current_dir, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            logging.error(f"未找到对应vision_app_pose.json文件")
            raise
        pose_list = data['vision_app_pose'][name]
        pose_tuple = self.select_pose_data(pose_list,pose_id)

        return pose_tuple

    def save_point(self, sequence_move_tuple):
        """
        保存 sequence_move_tuple 信息到 JSON 文件:
        - "left" 下的 "pose_list" 保存 sequence_move_tuple["left_arm"]
        - "right" 下的 "pose_list" 保存 sequence_move_tuple["right_arm"]
        - "left" 下的 "mat" 保存 self.init["calibration_cfg"]["robot_1"]["calib_martix"]
        - "right" 下的 "mat" 保存 self.init["calibration_cfg"]["robot_2"]["calib_martix"]
        """
        file_path = self.init["parameter_cfg"]["vision_app_config"]["track_save_path"]

        # 尝试读取已有数据；如果不存在则构造默认结构
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {"left": {"pose_list": [], "mat": []}, "right": {"pose_list": [], "mat": []}}

        # 更新左右臂的 pose_list
        data["left"]["pose_list"] = sequence_move_tuple.get("left_arm", [])
        data["right"]["pose_list"] = sequence_move_tuple.get("right_arm", [])

        # 保存 calib_martix
        data["left"]["mat"] = self.init["calibration_cfg"]["robot_1"]["calib_martix"]
        data["right"]["mat"] = self.init["calibration_cfg"]["robot_2"]["calib_martix"]

        # 写入 JSON 文件
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

        print("Saved point data to", file_path)

    # 日志层函数
    def format_json_compact_inner_lists(self,obj, indent=2, level=0):
        '''优化日志打印, 方便查问题'''
        sp = ' ' * (indent * level)
        if isinstance(obj, dict):
            items = []
            for k, v in obj.items():
                items.append(f'{sp}{" " * indent}"{k}": {self.format_json_compact_inner_lists(v, indent, level+1)}')
            return '{\n' + ',\n'.join(items) + f'\n{sp}}}'
        elif isinstance(obj, list):
            # 判断是否所有元素都是None
            if all(i is None for i in obj):
                return '[' + ', '.join(['null'] * len(obj)) + ']'
            # 每个元素一行, 连续null合并
            lines = []
            nulls = []
            for item in obj:
                if item is None:
                    nulls.append('null')
                else:
                    if nulls:
                        lines.append(' ' * (indent * (level+1)) + ', '.join(nulls))
                        nulls = []
                    # 如果是简单类型的list（如[0, [1,2], 0]）, 一行显示
                    if isinstance(item, list) and all(isinstance(x, (int, float, str, type(None), list)) for x in item):
                        def item_repr(i):
                            if isinstance(i, list):
                                return '[' + ', '.join('null' if x is None else repr(x) for x in i) + ']'
                            return 'null' if i is None else repr(i)
                        lines.append(' ' * (indent * (level+1)) + '[' + ', '.join(item_repr(i) for i in item) + ']')
                    else:
                        lines.append(' ' * (indent * (level+1)) + self.format_json_compact_inner_lists(item, indent, level+1))
            if nulls:
                lines.append(' ' * (indent * (level+1)) + ', '.join(nulls))
            return '[\n' + ',\n'.join(lines) + f'\n{sp}]'
        elif obj is None:
            return 'null'
        elif isinstance(obj, str):
            return '"' + obj + '"'
        else:
            return str(obj)

    def format_sequence_move_tuple_one_line(self, data):
        '''优化日志打印, 方便查问题'''
        lines = []
        lines.append("{")
        for arm, poses in data.items():
            lines.append(f'  "{arm}": [')
            for pose in poses:
                if pose is not None:
                    lines.append("    [" + ", ".join(f"{v}" for v in pose) + "],")
                else:
                    lines.append("    null,")
            lines.append("  ],")
        lines.append("}")
        return "\n".join(lines)

    def log_msg_save(self):
        log_fmt = '%(asctime)s - %(levelname)s - %(filename)s - Line: %(lineno)d - %(message)s'
        log_file = 'log.log'
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)
        file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
        stream_handler = logging.StreamHandler(sys.stdout)
        logging.basicConfig(
            level=logging.INFO,
            format=log_fmt,
            handlers=[file_handler, stream_handler]
        )