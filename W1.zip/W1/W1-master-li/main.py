# ///////////////////////////////////////////////////////////////
#
# BY: WANDERSON M.PIMENTA
# PROJECT MADE WITH: Qt Designer and PySide6
# V: 1.0.0
#
# This project can be used freely for all uses, as long as they maintain the
# respective credits only in the Python scripts, any information in the visual
# interface (GUI) can be modified without any implication.
#
# There are limitations on Qt licenses if you want to use your products
# commercially, I recommend reading them on the official website:
# https://doc.qt.io/qtforpython/licenses.html
#
# ///////////////////////////////////////////////////////////////

import sys
import os
import platform
import numpy as np
import time
import ast
import subprocess



# IMPORT / GUI AND MODULES AND WIDGETS
# ///////////////////////////////////////////////////////////////
from modules import *
from widgets import *



os.environ["QT_FONT_DPI"] = "96" # FIX Problem for High DPI and Scale above 100%


from handler_function import *
from basic_function import *
from log import *
from W1 import *


# SET AS GLOBAL WIDGETS
# ///////////////////////////////////////////////////////////////
widgets = None

class MainWindow(QMainWindow):
    """
    窗口初始化
    """
    def __init__(self):
        QMainWindow.__init__(self)

        # SET AS GLOBAL WIDGETS
        # ///////////////////////////////////////////////////////////////
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        

        #窗口
        global widgets
        widgets = self.ui

        #线程初始化
        global Th
        Th=ThreadManager()


        #初始化机器人通信
        global w1
        global function
        global vision_app
        init_instance = Initialize()
        w1,function,vision_app,self.device_cfg = init_instance.Create_robot_communication()
        WL=W1_Logic(w1)

        self.w1 = w1


         #初始化日志
        global logger
        logger = Logger(
        name="MyApp",
        level="DEBUG",
        log_dir="app_logs",
        console_output=True,
        file_output=True,
        max_file_size=5 * 1024 * 1024,  # 5MB
        backup_count=3
        )

        # 计时器
        self.counter = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_counter)

        #读取点位
        global Robotpoint
        Robotpoint=Json.read_simple_json(self,f'{os.getcwd()}/parameters/parameter.json')
        self.Loadingpoint()
        

        # 读取任务
        global Task
        Task=Json.read_simple_json(self,f'{os.getcwd()}/parameters/task.json')
        self.Loadingtask()
        self.load_user_tasks()  

        #初始化任务Ui
        self.TaskUi()


        # 使用自定义标题栏|在MAC或LINUX中用作“False”
        # ///////////////////////////////////////////////////////////////
        Settings.ENABLE_CUSTOM_TITLE_BAR = True

        # 应用名称
        # ///////////////////////////////////////////////////////////////
        title = "Dexforce - W1"
        description = "Dexforce W1 Pro APP - Towards a General Physical World Intelligence"
        # APPLY TEXTS
        self.setWindowTitle(title)
        widgets.titleRightInfo.setText(description)

        # 切换菜单
        # ///////////////////////////////////////////////////////////////
        widgets.toggleButton.clicked.connect(lambda: UIFunctions.toggleMenu(self, True))
        
        # 设置UI定义
        # ///////////////////////////////////////////////////////////////
        UIFunctions.uiDefinitions(self)

        # QTableWidget 参数
        # ///////////////////////////////////////////////////////////////
        # widgets.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)


        # 左侧菜单
        widgets.btn_home.clicked.connect(self.buttonClick)
        widgets.btn_widgets.clicked.connect(self.buttonClick)
        widgets.btn_new.clicked.connect(self.buttonClick)
        widgets.btn_save.clicked.connect(self.buttonClick)
        widgets.btn_tasks.clicked.connect(self.open_tasks_page)

        #右臂按钮连接函数
        widgets.RAmotionButton.clicked.connect(self.buttonClick)
        widgets.RAinformationButton.clicked.connect(self.buttonClick)
        widgets.RAMinterruptionButton.clicked.connect(self.buttonClick)
        widgets.JRAmotionButton.clicked.connect(self.buttonClick)

        #右手按钮连接函数
        widgets.RHmotionButton.clicked.connect(self.buttonClick)
        widgets.RHinformationButton.clicked.connect(self.buttonClick)
        widgets.RHMinterruptionButton.clicked.connect(self.buttonClick)

        
        #左臂按钮连接函数
        widgets.LAmotionButton.clicked.connect(self.buttonClick)
        widgets.LAinformationButton.clicked.connect(self.buttonClick)
        widgets.LAMinterruptionButton.clicked.connect(self.buttonClick)
        widgets.JLAmotionButton.clicked.connect(self.buttonClick)

        #左手按钮连接函数
        widgets.LHmotionButton.clicked.connect(self.buttonClick)
        widgets.LHinformationButton.clicked.connect(self.buttonClick)
        widgets.LHMinterruptionButton.clicked.connect(self.buttonClick)


        #躯干按钮连接函数
        widgets.TrunkinformationButton.clicked.connect(self.buttonClick)
        widgets.TrunkinterruptionButton.clicked.connect(self.buttonClick)
        widgets.TrunkmotionButton.clicked.connect(self.buttonClick)

        #头部按钮连接函数
        widgets.HeadinformationButton.clicked.connect(self.buttonClick)
        widgets.HeadmotionButton.clicked.connect(self.buttonClick)
        widgets.HeadinterruptionButton.clicked.connect(self.buttonClick)

        #底盘按钮连接函数
        widgets.ChassisinformationButton.clicked.connect(self.buttonClick)
        widgets.LHmotionButton_4.clicked.connect(self.buttonClick)
        widgets.HeadmotionButton_3.clicked.connect(self.buttonClick)
        #widgets.HeadinterruptionButton_3.clicked.connect(self.buttonClick)

        # 拖拽按钮连接函数
        widgets.stardragmode.clicked.connect(self.buttonClick)
        widgets.closedragmode.clicked.connect(self.buttonClick)

        # 头部旋转+
        widgets.HeadRPButton.pressed.connect(self.start_action)
        widgets.HeadRPButton.released.connect(self.stop_action)

        #触发任务按钮
        widgets.StartTaskButton.clicked.connect(self.buttonClick)
        widgets.EndTaskButton.clicked.connect(self.buttonClick)

        #点位切换
        widgets.pointlistWidget.itemClicked.connect(self.listWidgetClicked)

        # 部位切换
        widgets.pointcomboBox.currentIndexChanged.connect(self.comboBoxChanged)

        # 点位编辑
        widgets.ChangePointButton.clicked.connect(self.buttonClick)
        widgets.DeletePointButton.clicked.connect(self.buttonClick)
        widgets.AddPointButton.clicked.connect(self.buttonClick)

        # 视觉连接
        widgets.VisionButton.clicked.connect(self.buttonClick)
        widgets.StartPickwizButton.clicked.connect(self.buttonClick)

        # 额外的左框
        def openCloseLeftBox():
            UIFunctions.toggleLeftBox(self, True)
        widgets.toggleLeftBox.clicked.connect(openCloseLeftBox)
        widgets.extraCloseColumnBtn.clicked.connect(openCloseLeftBox)

        # 额外的右框
        def openCloseRightBox():
            UIFunctions.toggleRightBox(self, True)
        widgets.settingsTopBtn.clicked.connect(openCloseRightBox)

        # 展示窗口
        # ///////////////////////////////////////////////////////////////
        self.show()

        # 设置自定义主题
        # ///////////////////////////////////////////////////////////////
        useCustomTheme = False
        themeFile = r"themes\py_dracula_dark.qss"

        # 设定主题和技巧
        if useCustomTheme:
            # LOAD AND APPLY STYLE
            UIFunctions.theme(self, themeFile, True)

            # SET HACKS
            AppFunctions.setThemeHack(self)

        # 设置主页并选择菜单
        # ///////////////////////////////////////////////////////////////
        widgets.stackedWidget.setCurrentWidget(widgets.home)
        widgets.btn_home.setStyleSheet(UIFunctions.selectMenu(widgets.btn_home.styleSheet()))
    
        widgets.addTaskButton.clicked.connect(self.on_add_task_clicked)
        widgets.confirmTaskButton.clicked.connect(self.on_confirm_task)
        widgets.cancelTaskButton.clicked.connect(self.on_cancel_task)
          
        
        widgets.eventSelectButton.clicked.connect(self.open_event_selector)
        widgets.eventConfirmButton.clicked.connect(self.on_event_confirm)
        widgets.eventCancelButton.clicked.connect(self.on_event_cancel)

        widgets.emergencyStopButton.clicked.connect(self.on_emergency_stop)
    

    def start_action(self):
        """按钮按下时开始动作"""
        print("开始动作")
        self.timer.start(100)  # 每100毫秒触发一次
    
    def stop_action(self):
        """按钮释放时停止动作"""
        print("结束动作")
        self.timer.stop()
    
    def update_counter(self):
        """定时器触发时更新计数器"""
        self.counter += 1
        print(self.counter)

    # 任务页面相关方法
    def open_tasks_page(self):
        try:
            widgets.stackedWidget.setCurrentWidget(widgets.task_page)
            UIFunctions.resetStyle(self, 'btn_tasks')
            widgets.btn_tasks.setStyleSheet(UIFunctions.selectMenu(widgets.btn_tasks.styleSheet()))
        except Exception as e:
            self.append_log_with_timestamp(f"打开任务页失败: {e}")

    def on_add_task_clicked(self):
        try:
            # 显示输入区域（如果需要，这个UI始终可见，故仅清空输入）
            widgets.taskNameEdit.clear()
            widgets.navPointEdit.clear()
            widgets.motionTypeComboBox.setCurrentText("导航运动")
            widgets.taskNameEdit.setFocus()
        except Exception as e:
            self.append_log_with_timestamp(f"添加任务按钮处理失败: {e}")

    def on_confirm_task(self):
        try:
            name = widgets.taskNameEdit.text().strip()
            nav = widgets.navPointEdit.toPlainText().strip()
            motion_type = widgets.motionTypeComboBox.currentText()
            if not name:
                self.append_log_with_timestamp("任务名不能为空")
                return
            # 解析导航点为数值列表用于执行
            nav_list = self._parse_nav_point(nav)
            # 准备显示文本（任务名 + 格式化导航坐标）
            if nav_list is not None:
                nav_display = ",".join([f"{v:.2f}" for v in nav_list])
            else:
                nav_display = nav

            # 创建自定义列表项：图标 + 文本 + 导航按钮
            item = QListWidgetItem()
            container = QWidget()
            layout = QHBoxLayout(container)
            layout.setContentsMargins(4, 4, 4, 4)
            # 图标
            try:
                pix = QPixmap(":/icons/images/icons/cil-camera.png")
                icon_label = QLabel()
                icon_label.setPixmap(pix.scaled(32, 32, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            except Exception:
                icon_label = QLabel()
                icon_label.setText("")
            layout.addWidget(icon_label)
            text_label = QLabel(f"{name}\n{nav_display}")
            text_label.setWordWrap(True)
            layout.addWidget(text_label, 1)
            events_label = QLabel("")
            events_label.setObjectName('events_label')
            events_label.setMaximumWidth(220)
            events_label.setWordWrap(True)
            layout.addWidget(events_label)
            # 根据运动类型设置按钮文本
            btn_text = motion_type
            nav_btn = QPushButton(btn_text)
            nav_btn.setCursor(QCursor(Qt.PointingHandCursor))
            # 将导航点和运动类型作为闭包参数绑定
            if motion_type == "导航运动":
                nav_btn.clicked.connect(lambda _checked, nl=nav_list: self.on_task_navigate(nl))
            elif motion_type == "控制运动":
                nav_btn.clicked.connect(lambda _checked, nl=nav_list: self.on_task_control(nl))
            layout.addWidget(nav_btn)
            # 删除按钮
            del_btn = QPushButton("删除")
            del_btn.setCursor(QCursor(Qt.PointingHandCursor))
            # 绑定删除回调，删除对应的 QListWidgetItem
            def make_remove(btn_item):
                return lambda: self._remove_task_item(btn_item)
            # 在这里我们还未将 item 添加到 widget，所以使用一个弱闭包：稍后设置时传入 item
            layout.addWidget(del_btn)
            item.setSizeHint(container.sizeHint())
            widgets.taskListWidget.addItem(item)
            widgets.taskListWidget.setItemWidget(item, container)
            # 将删除按钮的回调绑定到刚创建的 item
            try:
                del_btn.clicked.disconnect()
            except Exception:
                pass
            del_btn.clicked.connect(lambda _checked, it=item: self._remove_task_item(it))
            widgets.taskNameEdit.clear()
            widgets.navPointEdit.clear()
            display_text = f"{name}\n{nav_display}"
            # 将任务元数据放到 item 上，方便后续关联事件
            try:
                meta = {'name': name, 'nav': nav_list, 'motion_type': motion_type, 'events': []}
                item.setData(Qt.UserRole, meta)
                try:
                    widgets.taskListWidget.setItemWidget(item, container)
                    # 保留对事件标签的引用到 item 的 Qt.UserRole+1
                    item.setData(Qt.UserRole + 1, events_label)
                except Exception:
                    pass
            except Exception:
                pass
            self.append_log_with_timestamp(f"任务已添加: {display_text}")
            # 保存到 user_tasks
            task_data = {'name': name, 'nav': nav_list, 'motion_type': motion_type, 'events': []}
            self.append_log_with_timestamp(f"准备保存任务: {task_data}")
            if 'user_tasks' not in Task:
                Task['user_tasks'] = []
            Task['user_tasks'].append(task_data)
            Json.write_simple_json(self, f'{os.getcwd()}/parameters/task.json', Task)
            self.append_log_with_timestamp("任务保存成功")
        except Exception as e:
            self.append_log_with_timestamp(f"确认添加任务失败: {e}")

    def on_cancel_task(self):
        try:
            widgets.taskNameEdit.clear()
            widgets.navPointEdit.clear()
            widgets.motionTypeComboBox.setCurrentText("导航运动")
            self.append_log_with_timestamp("已取消任务输入")
        except Exception as e:
            self.append_log_with_timestamp(f"取消任务失败: {e}")

    def Loadingpoint(self):
        """加载点位"""
        widgets.pointlistWidget.clear()
        if widgets.pointcomboBox.currentText()=="左臂":
            l_poses = {key: value for key, value in Robotpoint["pose_list"]["basic_pose"].items() if key.startswith('l_')}
        elif widgets.pointcomboBox.currentText()=="右臂":
            l_poses = {key: value for key, value in Robotpoint["pose_list"]["basic_pose"].items() if key.startswith('r_')}  
        elif widgets.pointcomboBox.currentText()=="左手":
            l_poses = {key: value for key, value in Robotpoint["pose_list"]["hand_pose"].items() if key.startswith('l_')}
        elif widgets.pointcomboBox.currentText()=="右手":
            l_poses = {key: value for key, value in Robotpoint["pose_list"]["hand_pose"].items() if key.startswith('r_')}  
        for i in  l_poses:           
            widgets.pointlistWidget.addItems([f"{i}"])
    

    def add_task_to_list(self, task_data):
        """将任务数据添加到任务列表中"""
        try:
            name = task_data.get('name', '')
            nav_list = task_data.get('nav', [])
            motion_type = task_data.get('motion_type', '导航运动')  # 默认导航运动
            events = task_data.get('events', [])

            # 准备显示文本
            if nav_list:
                nav_display = ",".join([f"{v:.2f}" for v in nav_list])
            else:
                nav_display = ""

            # 创建自定义列表项：图标 + 文本 + 导航按钮
            item = QListWidgetItem()
            container = QWidget()
            layout = QHBoxLayout(container)
            layout.setContentsMargins(4, 4, 4, 4)
            # 图标
            try:
                pix = QPixmap(":/icons/images/icons/cil-camera.png")
                icon_label = QLabel()
                icon_label.setPixmap(pix.scaled(32, 32, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            except Exception:
                icon_label = QLabel()
                icon_label.setText("")
            layout.addWidget(icon_label)
            text_label = QLabel(f"{name}\n{nav_display}")
            text_label.setWordWrap(True)
            layout.addWidget(text_label, 1)
            events_label = QLabel(", ".join(events))
            events_label.setObjectName('events_label')
            events_label.setMaximumWidth(220)
            events_label.setWordWrap(True)
            layout.addWidget(events_label)
            # 根据运动类型设置按钮文本和事件
            nav_btn = QPushButton(motion_type)
            nav_btn.setCursor(QCursor(Qt.PointingHandCursor))
            if motion_type == "导航运动":
                nav_btn.clicked.connect(lambda _checked, nl=nav_list: self.on_task_navigate(nl))
            elif motion_type == "控制运动":
                nav_btn.clicked.connect(lambda _checked, nl=nav_list: self.on_task_control(nl))
            layout.addWidget(nav_btn)
            # 删除按钮
            del_btn = QPushButton("删除")
            del_btn.setCursor(QCursor(Qt.PointingHandCursor))
            # 绑定删除回调，删除对应的 QListWidgetItem
            layout.addWidget(del_btn)
            item.setSizeHint(container.sizeHint())
            widgets.taskListWidget.addItem(item)
            widgets.taskListWidget.setItemWidget(item, container)
            # 将删除按钮的回调绑定到刚创建的 item
            try:
                del_btn.clicked.disconnect()
            except Exception:
                pass
            del_btn.clicked.connect(lambda _checked, it=item: self._remove_task_item(it))
            # 将任务元数据放到 item 上
            meta = {'name': name, 'nav': nav_list, 'motion_type': motion_type, 'events': events}
            item.setData(Qt.UserRole, meta)
            # 保留对事件标签的引用
            item.setData(Qt.UserRole + 1, events_label)
        except Exception as e:
            self.append_log_with_timestamp(f"添加任务到列表失败: {e}")

    def load_user_tasks(self):
        """加载用户添加的任务到任务列表"""
        if 'user_tasks' in Task:
            for task in Task['user_tasks']:
                self.add_task_to_list(task)

    def Loadingtask(self):
        """加载任务"""
        for i in Task["work_sequence"]:
            show=Task["work_sequence"][f"{i}"][0]   
            widgets.TasklistWidget.addItems([show])
    
    def listWidgetClicked(self):
        """点位切换"""
        try:   
            if widgets.pointcomboBox.currentText()=="左臂":  
                CRobotpoint=Robotpoint["pose_list"]["basic_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]
                logger.info(f"{widgets.pointlistWidget.currentItem().text()}--{CRobotpoint}") 
            elif widgets.pointcomboBox.currentText()=="右臂":  
                CRobotpoint=Robotpoint["pose_list"]["basic_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]
                logger.info(f"{widgets.pointlistWidget.currentItem().text()}--{CRobotpoint}")
            elif widgets.pointcomboBox.currentText()=="左手":
                CRobotpoint=Robotpoint["pose_list"]["hand_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]
                logger.info(f"{widgets.pointlistWidget.currentItem().text()}--{CRobotpoint}") 
            elif widgets.pointcomboBox.currentText()=="右手":
                CRobotpoint=Robotpoint["pose_list"]["hand_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]
                logger.info(f"{widgets.pointlistWidget.currentItem().text()}--{CRobotpoint}")
            widgets.XPC.setText(f"{CRobotpoint[0]}")
            widgets.YPC.setText(f"{CRobotpoint[1]}")
            widgets.ZPC.setText(f"{CRobotpoint[2]}")
            widgets.RXPC.setText(f"{CRobotpoint[3]}")
            widgets.RYPC.setText(f"{CRobotpoint[4]}")
            widgets.RZPC.setText(f"{CRobotpoint[5]}")      
        except Exception as e:
            logger.info("点位切换错误")
            logger.error(f"{e}")

    def comboBoxChanged(self):
        """切换点位对象"""
        try:
            self.Loadingpoint()
        except Exception as e:
            logger.info("点位切换错误")
            logger.error("e")

    def TaskUi(self):
        "加载任务栏Ui"
        try:
            card_data_list = [
        {"title": "打开盖子",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "重抓胶囊",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "下拉把手1",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "左手按按钮",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "右手按按钮",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "按开水",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "拿出咖啡",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "送出咖啡",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "送出咖啡2",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        {"title": "同步下拉前",
         "description": "\"move_head_torso\":{\"use\":true,\"current_torso\":[45,-90,45,2],\"target_torso\":[45,-90,45,2]}"},
        ]
            
            model = QStandardItemModel()
            for card_data in card_data_list:
                item = QStandardItem()
                item.setData(card_data, Qt.DisplayRole)
                model.appendRow(item)

        except Exception as e:
            logger.info("任务切换错误")
            logger.error(f"{e}")

    # 按钮绑定事件，根据按钮名分类
    def buttonClick(self):

        # GET BUTTON CLICKED
        btn = self.sender()
        btnName = btn.objectName()
        logger.debug(f'"{btnName}" pressed!')

        # 显示主页
        if btnName == "btn_home":
            widgets.stackedWidget.setCurrentWidget(widgets.home)
            UIFunctions.resetStyle(self, btnName)
            btn.setStyleSheet(UIFunctions.selectMenu(btn.styleSheet()))

        # 显示小部件页面
        if btnName == "btn_widgets":
            widgets.stackedWidget.setCurrentWidget(widgets.widgets)
            UIFunctions.resetStyle(self, btnName)
            btn.setStyleSheet(UIFunctions.selectMenu(btn.styleSheet()))

        # 显示新页面
        if btnName == "btn_new":
            widgets.stackedWidget.setCurrentWidget(widgets.new_page) # SET PAGE
            UIFunctions.resetStyle(self, btnName) # RESET ANOTHERS BUTTONS SELECTED
            btn.setStyleSheet(UIFunctions.selectMenu(btn.styleSheet())) # SELECT MENU

        if btnName == "btn_save":
            print("Save BTN clicked!")

        if btnName == "RAinformationButton":
            """获取右臂坐标"""           
            try:
                arm_r_pose = w1.get_current_pose('right_arm')[0]
                arm_r_pose = np.round(arm_r_pose, 2).tolist()
                self.append_log_with_timestamp(str(arm_r_pose))
                self.append_log_with_timestamp("右臂坐标获取成功")        
                widgets.RAtextEdit.setText(str(arm_r_pose))     
            except Exception as e:
                self.append_log_with_timestamp("右臂坐标获取失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")


        if btnName == "RAmotionButton":
            """右臂运动"""
            try:
                #获取坐标
                arm_l_pose = w1.get_current_pose('left_arm')[0]
                arm_r_pose = ast.literal_eval(widgets.RAtextEdit.toPlainText())          
                move_point = {'left_arm': [arm_l_pose], 'right_arm': [arm_r_pose]}   
                self.append_log_with_timestamp(f"移动点位{move_point}")
                #机器人运动
                success = w1.w1_manager.move_linear_full_body(
                waypoints_dict=move_point,
                speed_ratio=self.device_cfg["ui_param"]["movel_speed"]
            )                

                if(success==True):
                    self.append_log_with_timestamp("右臂运动成功") 
                else:
                    self.append_log_with_timestamp("右臂运动失败") 
            except Exception as e:
                self.append_log_with_timestamp("右臂运动失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "RAMinterruptionButton":
            """中断右臂运动"""
            try:
                self.append_log_with_timestamp("停止运动成功")
            except Exception as e:
                self.append_log_with_timestamp(f"错误: {str(e)}")
        
        if btnName == "LAinformationButton":
            """获取左臂坐标"""           
            try:
                arm_l_pose = w1.get_current_pose('left_arm')[0]
                arm_l_pose = np.round(arm_l_pose, 2).tolist()
                self.append_log_with_timestamp(str(arm_l_pose))
                self.append_log_with_timestamp("左臂坐标获取成功")
                widgets.LAtextEdit.setText(str(arm_l_pose))    
            except Exception as e:
                self.append_log_with_timestamp("左臂坐标获取失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")


        if btnName == "LAmotionButton":          
            """左臂运动"""
            try:
                #获取坐标
                arm_r_pose = w1.get_current_pose('right_arm')[0]
                arm_l_pose = ast.literal_eval(widgets.LAtextEdit.toPlainText())

                move_point = {'left_arm': [arm_l_pose], 'right_arm': [arm_r_pose]}  
                self.append_log_with_timestamp(f"移动点位{move_point}") 

                #机器人运动
                success = w1.w1_manager.move_linear_full_body(
                waypoints_dict=move_point,
                speed_ratio=self.device_cfg["ui_param"]["movel_speed"]
                )

                if(success==True):
                    self.append_log_with_timestamp("左臂运动成功")  
                else:
                    self.append_log_with_timestamp("左臂运动失败")                     
            except Exception as e:
                self.append_log_with_timestamp("左臂运动失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "LAMinterruptionButton":
            """中断左臂运动"""
            try:            
                self.append_log_with_timestamp("停止运动成功")
            except Exception as e:
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "TrunkinformationButton":
            """获取躯干坐标"""           
            try:
                arm_t_pose = w1.get_current_pose('torso')[0]
                arm_t_pose = np.round(arm_t_pose, 2).tolist()
                self.append_log_with_timestamp(str(arm_t_pose))
                self.append_log_with_timestamp("躯干坐标获取成功")
                widgets.TrunktextEdit.setText(str(arm_t_pose))    
            except Exception as e:
                self.append_log_with_timestamp("躯干坐标获取失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "TrunkmotionButton":             
            """躯干运动"""
            try:
                #获取坐标
                torso_status = np.round(np.radians(ast.literal_eval(widgets.TrunktextEdit.toPlainText())), 4).tolist()
                move_point = {'torso': [torso_status],"torso_speed_ratio":[0.3]}

                self.append_log_with_timestamp(f"躯干点位{move_point}") 

                #机器人运动
                success = w1.w1_manager.move_linear_full_body(
                waypoints_dict=move_point,
                speed_ratio=self.device_cfg["ui_param"]["movel_speed"]
                )            
                if(success):
                    self.append_log_with_timestamp("躯干运动成功")
                else:
                    self.append_log_with_timestamp("躯干运动失败.")                        
            except Exception as e:
                self.append_log_with_timestamp("躯干运动失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")    
        
        if btnName == "TrunkinterruptionButton":
            """中断躯干运动"""
            try:         
                self.append_log_with_timestamp("停止运动成功")           
            except Exception as e:
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "RHinformationButton":
            """获取右手坐标"""           
            try:
                hand_status = w1.get_current_pose("right_arm_ee")[0]
                hand_status = np.round(hand_status, 2).tolist()
                self.append_log_with_timestamp(str(hand_status))
                self.append_log_with_timestamp("右手坐标获取成功")        
                widgets.RHtextEdit.setText(str(hand_status))     
            except Exception as e:
                self.append_log_with_timestamp("右手坐标获取失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "RHmotionButton":
            """右手运动"""
            try:
                hand_state = ast.literal_eval(widgets.RHtextEdit.toPlainText())
                self.append_log_with_timestamp(str(hand_state))
                w1.set_ee_qpos("right_arm_ee", hand_state)
                    

            except Exception as e:
                self.append_log_with_timestamp("右手运动失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "LHinformationButton":
            """获取左手坐标"""
            try:
                hand_status = w1.get_current_pose("left_arm_ee")[0]
                hand_status = np.round(hand_status, 2).tolist()
                self.append_log_with_timestamp(str(hand_status))
                self.append_log_with_timestamp("左手坐标获取成功")
                widgets.LHtextEdit.setText(str(hand_status))
            except Exception as e:
                self.append_log_with_timestamp("左手坐标获取失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "LHmotionButton":
            """左手运动"""
            try:
                hand_state = ast.literal_eval(widgets.LHtextEdit.toPlainText())
                self.append_log_with_timestamp(str(hand_state))
                w1.set_ee_qpos("left_arm_ee", hand_state)
                self.append_log_with_timestamp("左手运动成功")

            except Exception as e:
                self.append_log_with_timestamp("左手运动失败")
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "LHMinterruptionButton":
            """中断左手运动"""
            try:
                self.append_log_with_timestamp("停止运动成功")
            except Exception as e:
                self.append_log_with_timestamp(f"错误: {str(e)}")

        if btnName == "HeadinformationButton":
            """获取头部坐标"""           
            try:
                head_status = w1.get_current_pose('head')[0]
                rounded = [int(np.round(x)) for x in head_status]
                logger.info(rounded)
                logger.info("头部坐标获取成功")        
                widgets.HeadtextEdit.setText(str(rounded))     
            except Exception as e:
                logger.info("头部坐标获取失败")
                logger.error(e)
        
        if btnName == "HeadmotionButton":
            """头部运动"""
            try:
                head_status = np.round(np.radians(ast.literal_eval(widgets.HeadtextEdit.toPlainText())), 4).tolist()
                move_point = {'head': [head_status],"head_speed_ratio":[0.5]}
                logger.info(f"移动点位{move_point}")
                success = w1.w1_manager.move_linear_full_body(
                waypoints_dict=move_point,
                speed_ratio=self.device_cfg["ui_param"]["head_speed"]
            )             
                if(success==True):
                    logger.info("头部运动成功") 
                else:
                    logger.info("头部运动失败") 
            except Exception as e:
                logger.info("头部运动失败")
                logger.error(e)  

        if btnName == "HeadRPButton":
            """头部旋转+"""
            try:
                print("开始旋转")
                self.timer.start(100)           
            except Exception as e:
                logger.error(e)

        if btnName == "StartTaskButton":
            """开始执行任务"""
            try:  
                currenttask = widgets.TasklistWidget.currentItem().text()        
                logger.info(f"触发任务--{currenttask}") 
                widgets.Taskstatus.setStyleSheet("color: green;")

                #global TaskThread
                #TaskThread=Th.create_thread(function.execute_origin_tasks(currenttask), 
                #args=(),
                #kwargs=None,
                #name="test",
                #daemon=True
                #)

                #Th.start_thread(TaskThread)

                global thread
                thread = one_task_th(vision_app,function,currenttask)
                thread.start()

                logger.info(f"开始执行任务--{currenttask}") 

                widgets.Taskstatus.setStyleSheet("color: white;")

                #function.execute_origin_tasks(currenttask)     
                      
            except Exception as e:
                logger.info("执行任务错误")
                logger.error(e)
                widgets.Taskstatus.setStyleSheet("color: white;")

        if btnName == "EndTaskButton":
            """中断任务"""
            try:  

                currenttask = widgets.TasklistWidget.currentItem().text() 

                thread.quit() 

                w1.w1_manager.stop_move()

                logger.info(f"中断任务成功--{currenttask}")               

            except Exception as e:
                logger.info("中断任务错误")
                logger.error(e)
        if btnName == "ChangePointButton":
            """更改点位"""
            try:
                X=widgets.XPC.toPlainText()
                Y=widgets.YPC.toPlainText()
                Z=widgets.ZPC.toPlainText()
                RX=widgets.RXPC.toPlainText()
                RY=widgets.RYPC.toPlainText()
                RZ=widgets.RZPC.toPlainText()

                CRobotpoint=[X,Y,Z,RX,RY,RZ]
                

                Robotpoint=Json.read_simple_json(self,f'{os.getcwd()}/parameters/parameter.json')

                if widgets.pointcomboBox.currentText()=="左臂":  
                    BRobotpoint =Robotpoint["pose_list"]["basic_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]
                    logger.info(f"更改前{widgets.pointlistWidget.currentItem().text()}--{ BRobotpoint}")
                    Robotpoint["pose_list"]["basic_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]=CRobotpoint          
                elif widgets.pointcomboBox.currentText()=="右臂": 
                    BRobotpoint =Robotpoint["pose_list"]["basic_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]
                    logger.info(f"更改前{widgets.pointlistWidget.currentItem().text()}--{ BRobotpoint}") 
                    Robotpoint["pose_list"]["basic_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]=CRobotpoint
                elif widgets.pointcomboBox.currentText()=="左手":
                    BRobotpoint =Robotpoint["pose_list"]["hand_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]
                    logger.info(f"更改前{widgets.pointlistWidget.currentItem().text()}--{ BRobotpoint}")
                    Robotpoint["pose_list"]["hand_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]=CRobotpoint     
                elif widgets.pointcomboBox.currentText()=="右手":
                    BRobotpoint =Robotpoint["pose_list"]["hand_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]
                    logger.info(f"更改前{widgets.pointlistWidget.currentItem().text()}--{ BRobotpoint}")
                    Robotpoint["pose_list"]["hand_pose"][f"{widgets.pointlistWidget.currentItem().text()}"]=CRobotpoint


                logger.info(f"更改后{widgets.pointlistWidget.currentItem().text()}--{CRobotpoint}")

 
                #Json.write_simple_json(self,f"{os.getcwd()}/parameters/parameter.json",Robotpoint)


                logger.info("更改点位成功")
            except Exception as e:   
                logger.info("更改点位错误")
                logger.error(e)

        if btnName == "VisionButton":
            """视觉连接"""  
            try:
                sign = vision_app.connection()
                if sign:
                    logger.info("视觉连接成功")           
                    widgets.visionstatus.setStyleSheet("color: green;")     
                else:
                    logger.info("视觉连接失败")
            except Exception as e:
                logger.info("视觉连接失败")
                logger.error(e)

        if btnName == "StartPickwizButton":
            """启动Pickwiz"""  
            try:
                current_dir = os.path.dirname(os.path.abspath(__file__))
                pickwiz_path = os.path.join(current_dir, "pickwiz_start.py")
                if not os.path.exists(pickwiz_path):
                    logger.info(f"错误: 未找到Pickwiz启动文件 {pickwiz_path}")
                    return
                subprocess.Popen([sys.executable, pickwiz_path])
                logger.info("Pickwiz启动命令已发送")
            except Exception as e:
                logger.info("启动Pickwiz失败")
                logger.error(e)

        if btnName == "ChassisinformationButton":
            """获取底盘信息"""
            self.on_chassis_get()

        if btnName == "LHmotionButton_4":
            """导航运动"""
            self.on_move_chassis_nav2()

        if btnName == "HeadmotionButton_3":
            """控制运动"""
            self.on_move_chassis_ctrl()

        if btnName == "stardragmode":
            """开启拖拽"""
            self.drag_open()

        if btnName == "closedragmode":
            """关闭拖拽"""
            self.drag_close()

        #if btnName == "HeadinterruptionButton_3":
        #    """中断底盘运动"""
        #    try:
        #       self.append_log_with_timestamp("停止底盘运动成功")
        #    except Exception as e:
        #        self.append_log_with_timestamp(f"错误: {str(e)}")

        #return

    def append_log_with_timestamp(self, msg):
        """添加带时间戳的日志"""
        # 恢复为仅使用 logger 的标准输出格式
        logger.info(msg)

    def on_chassis_get(self):
        """获取底盘状态"""
        try:
            res, chassis_pose = self.w1.w1_manager.get_current_chassis_pose()
            text_chassis_pose = np.round(chassis_pose, 2).tolist()
            widgets.ChassistextEdit.setText(str(text_chassis_pose))
            self.append_log_with_timestamp(f"底盘状态获取成功" if res else "底盘状态获取失败")
        except Exception as e:
            self.append_log_with_timestamp(f"获取底盘状态出错: {str(e)}")

    def _parse_nav_point(self, s: str):
        if not s:
            return None
        try:
            val = ast.literal_eval(s)
            if isinstance(val, (list, tuple)):
                nums = [float(v) for v in val][:3]
                return nums
        except Exception:
            pass
        for sep in [",", ";", " "]:
            if sep in s:
                parts = [p for p in s.split(sep) if p.strip()]
                try:
                    nums = [float(p) for p in parts][:3]
                    return nums
                except Exception:
                    continue
        return None

    def on_task_navigate(self, nav_list):
        try:
            if nav_list is None:
                self.append_log_with_timestamp("任务导航点不可解析")
                return
            base_position = np.round(nav_list, 4).tolist()
            try:
                result = self.w1.w1_manager.move_chassis_nav2(base_position)
                if result:  # 返回True表示成功
                    self.append_log_with_timestamp(f"导航到底盘位置成功: {base_position}")
                else:
                    self.append_log_with_timestamp(f"导航到底盘位置失败: {base_position}")
            except Exception as e:
                self.append_log_with_timestamp(f"调用底盘导航接口失败: {e}")
        except Exception as e:
            self.append_log_with_timestamp(f"任务导航失败: {e}")

    def on_task_control(self, nav_list):
        try:
            if nav_list is None:
                self.append_log_with_timestamp("任务控制点不可解析")
                return
            base_position = np.round(nav_list, 4).tolist()
            try:
                self.w1.w1_manager.move_chassis_ctrl(base_position)
                self.append_log_with_timestamp(f"开始控制到底盘位置: {base_position}")
            #控制接口暂时未添加，故先屏蔽
            #try:
                #result = self.w1.w1_manager.move_chassis_ctrl(base_position)
                #if result:  # 返回True表示成功
                    #self.append_log_with_timestamp(f"控制到底盘位置成功: {base_position}")
                #else:
                    #self.append_log_with_timestamp(f"控制到底盘位置失败: {base_position}")
            except Exception as e:
                self.append_log_with_timestamp(f"调用底盘控制接口失败: {e}")
        except Exception as e:
            self.append_log_with_timestamp(f"任务控制失败: {e}")

    def on_emergency_stop(self):
        try:
            self.w1.w1_manager.emergency_stop()
            # 尝试停止管理的线程（如果存在全局 Th）
            try:
                global Th
                if Th and hasattr(Th, 'threads'):
                    for t in list(Th.threads):
                        try:
                            Th.stop_thread(t)
                        except Exception:
                            pass
                    self.append_log_with_timestamp("已尝试停止管理线程")
            except Exception:
                pass
            # 记录紧急停止事件
            self.append_log_with_timestamp("紧急停止触发：所有可用停止动作已尝试执行")
        except Exception as e:
            self.append_log_with_timestamp(f"紧急停止失败: {e}")

    def _remove_task_item(self, item: QListWidgetItem):
        """从任务列表中删除指定的 QListWidgetItem 并清理其 widget"""
        try:
            list_widget = widgets.taskListWidget
            row = list_widget.row(item)
            if row >= 0:
                # 获取任务元数据
                meta = item.data(Qt.UserRole)
                if meta:
                    name = meta.get('name')
                    nav = meta.get('nav')
                    events = meta.get('events', [])
                    # 从 user_tasks 中移除
                    if 'user_tasks' in Task:
                        Task['user_tasks'] = [t for t in Task['user_tasks'] if not (t.get('name') == name and t.get('nav') == nav)]
                        Json.write_simple_json(self, f'{os.getcwd()}/parameters/task.json', Task)
                # 取回并删除关联的 widget
                w = list_widget.itemWidget(item)
                if w is not None:
                    w.setParent(None)
                    w.deleteLater()
                list_widget.takeItem(row)
                self.append_log_with_timestamp(f"任务已删除")
            else:
                self.append_log_with_timestamp("要删除的任务未找到")
        except Exception as e:
            self.append_log_with_timestamp(f"删除任务失败: {e}")

    def open_event_selector(self):
        """显示事件选择面板，针对当前右侧输入中所填写的任务。"""
        try:
            # 如果当前在任务页，打开 eventSelectionFrame
            widgets.eventSelectionFrame.setVisible(True)
            widgets.eventListWidget.clear()
            # 尝试从 parameters/task.json 的 work_sequence 加载事件
            try:
                import json
                p = os.path.join(os.path.dirname(__file__), 'parameters', 'task.json')
                with open(p, 'r', encoding='utf-8') as f:
                    task_conf = json.load(f)
                seq = task_conf.get('work_sequence', {})
                events = [v[0] for k, v in sorted(seq.items(), key=lambda x: int(x[0]))]
                for ev in events:
                    item = QListWidgetItem(ev)
                    widgets.eventListWidget.addItem(item)
            except Exception as e:
                # 回退到示例事件
                self.append_log_with_timestamp(f"载入 task.json 失败，使用默认事件: {e}")
                sample_events = ["拾取", "移动到目的地", "放置", "等待", "检查状态"]
                for ev in sample_events:
                    it = QListWidgetItem(ev)
                    widgets.eventListWidget.addItem(it)
        except Exception as e:
            self.append_log_with_timestamp(f"打开事件选择失败: {e}")

    def on_event_confirm(self):
        try:
            selected = [it.text() for it in widgets.eventListWidget.selectedItems()]
            # 找到当前任务项：优先获取 list 的当前行，否则使用右侧输入的最近任务名匹配
            cur_row = widgets.taskListWidget.currentRow()
            if cur_row >= 0:
                item = widgets.taskListWidget.item(cur_row)
            else:
                # 尝试通过名称匹配
                name = widgets.taskNameEdit.text().strip()
                item = None
                for i in range(widgets.taskListWidget.count()):
                    it = widgets.taskListWidget.item(i)
                    meta = it.data(Qt.UserRole)
                    if meta and meta.get('name') == name:
                        item = it
                        break
            if item is None:
                self.append_log_with_timestamp("未找到要附加事件的任务")
                widgets.eventSelectionFrame.setVisible(False)
                return
            try:
                meta = item.data(Qt.UserRole) or {}
                meta['events'] = selected
                item.setData(Qt.UserRole, meta)
            except Exception:
                pass
            # 更新列表项旁边的事件标签
            try:
                ev_label = item.data(Qt.UserRole + 1)
                if ev_label:
                    ev_label.setText(', '.join(selected))
            except Exception:
                pass
            widgets.eventSelectionFrame.setVisible(False)
            self.append_log_with_timestamp(f"为任务分配事件: {selected}")
            # 更新 user_tasks 中的事件并保存
            if 'user_tasks' in Task:
                for task in Task['user_tasks']:
                    if task.get('name') == meta.get('name') and task.get('nav') == meta.get('nav'):
                        task['events'] = selected
                        break
                Json.write_simple_json(self, f'{os.getcwd()}/parameters/task.json', Task)
            # 切回任务页并显示执行按钮（在右侧）
            widgets.stackedWidget.setCurrentWidget(widgets.task_page)
            try:
                # 显示或启用开始执行按钮（动态创建或查找）
                if not hasattr(widgets, 'taskExecuteButton'):
                    btn = QPushButton(widgets.task_right_frame)
                    btn.setObjectName('taskExecuteButton')
                    btn.setText('开始执行')
                    btn.setMinimumSize(QSize(110, 32))
                    widgets.task_right_layout.addWidget(btn)
                    widgets.taskExecuteButton = btn
                    widgets.taskExecuteButton.clicked.connect(self.on_task_execute)
                widgets.taskExecuteButton.setEnabled(True)
            except Exception:
                pass
        except Exception as e:
            self.append_log_with_timestamp(f"确认事件失败: {e}")

    def on_event_cancel(self):
        try:
            widgets.eventSelectionFrame.setVisible(False)
        except Exception as e:
            self.append_log_with_timestamp(f"取消事件选择失败: {e}")

    def on_task_execute(self):
        """开始执行选中任务及其分配的事件(测试中)"""
        try:
            cur_row = widgets.taskListWidget.currentRow()
            if cur_row < 0:
                self.append_log_with_timestamp("请先在任务列表中选择任务")
                return
            item = widgets.taskListWidget.item(cur_row)
            meta = item.data(Qt.UserRole) or {}
            name = meta.get('name')
            nav = meta.get('nav')
            motion_type = meta.get('motion_type', '导航运动')
            events = meta.get('events', [])
            self.append_log_with_timestamp(f"开始执行任务 '{name}'，运动类型: {motion_type}，事件序列: {events}")
            
            # 1.执行任务的运动（导航或控制）
            motion_success = False
            if motion_type == "导航运动":
                if nav:
                    try:
                        result = self.w1.w1_manager.move_chassis_nav2(np.round(nav, 4).tolist())
                        if result:
                            self.append_log_with_timestamp(f"任务 '{name}' 导航运动成功: {nav}")
                            motion_success = True
                        else:
                            self.append_log_with_timestamp(f"任务 '{name}' 导航运动失败: {nav}")
                    except Exception as e:
                        self.append_log_with_timestamp(f"任务 '{name}' 导航运动出错: {e}")
                else:
                    self.append_log_with_timestamp(f"任务 '{name}' 需要导航点，但未配置")
            elif motion_type == "控制运动":
                if nav:
                    try:
                        # 假设控制运动也返回布尔值，如果不返回，需调整--接口暂时未添加，后续会补充
                        result = self.w1.w1_manager.move_chassis_ctrl(np.round(nav, 4).tolist())
                        if result:
                            self.append_log_with_timestamp(f"任务 '{name}' 控制运动成功: {nav}")
                            motion_success = True
                        else:
                            self.append_log_with_timestamp(f"任务 '{name}' 控制运动失败: {nav}")
                    except Exception as e:
                        self.append_log_with_timestamp(f"任务 '{name}' 控制运动出错: {e}")
                else:
                    self.append_log_with_timestamp(f"任务 '{name}' 需要控制点，但未配置")
            
            # 2.当判断底盘运动成功，则执行事件动作
            if motion_success:
                for ev in events:
                    try:
                        self.append_log_with_timestamp(f"开始执行事件 '{ev}'")
                        event_thread = one_task_th(vision_app, function, ev)
                        event_thread.start()
                        event_thread.wait()  # 等待线程完成，确保顺序执行
                        self.append_log_with_timestamp(f"事件 '{ev}' 执行完成")
                    except Exception as e:
                        self.append_log_with_timestamp(f"执行事件 '{ev}' 失败: {e}")
                self.append_log_with_timestamp(f"任务 '{name}' 执行完毕")
            else:
                self.append_log_with_timestamp(f"任务 '{name}' 运动失败，跳过事件执行")
        except Exception as e:
            self.append_log_with_timestamp(f"执行任务失败: {e}")
    def on_move_chassis_nav2(self):
        """控制底盘运动 导航"""
        try:
            base_position = np.round(ast.literal_eval(widgets.ChassistextEdit.toPlainText()), 4).tolist()
            result = self.w1.w1_manager.move_chassis_nav2(base_position)
            if result:
                self.append_log_with_timestamp(f"底盘导航到位置成功: {base_position}")
            else:
                self.append_log_with_timestamp(f"底盘导航到位置失败: {base_position}")
        except Exception as e:
            self.append_log_with_timestamp(f"底盘导航出错: {str(e)}")

    def on_move_chassis_ctrl(self):
        """控制底盘运动 控制"""
        try:
            base_position = np.round(ast.literal_eval(widgets.ChassistextEdit.toPlainText()), 4).tolist()
            self.w1.w1_manager.move_chassis_ctrl(base_position)
            self.append_log_with_timestamp(f"底盘运动到位置: {base_position}")
        except Exception as e:
            self.append_log_with_timestamp(f"底盘运动出错: {str(e)}")

    def clear_log(self):
        """清除日志"""
        try:
            widgets.LogTextEdit.clear()
            self.append_log_with_timestamp("日志已清除")
        except Exception:
            print("日志已清除")

    def drag_open(self):
        """开启拖拽"""
        if not self.w1:
            QMessageBox.warning(self, "警告", "请等待初始化完成")
            return
        try:
            self.w1.w1_manager.set_drag_mode(True)
            widgets.dragstatus.setStyleSheet("color: green;")
            self.append_log_with_timestamp("拖拽模式已开启")
        except Exception as e:
            self.append_log_with_timestamp(f"开启拖拽失败: {str(e)}")

    def drag_close(self):
        """关闭拖拽"""
        if not self.w1:
            QMessageBox.warning(self, "警告", "请等待初始化完成")
            return
        try:
            self.w1.w1_manager.set_drag_mode(False)
            widgets.dragstatus.setStyleSheet("color: white;")
            self.append_log_with_timestamp("拖拽模式已关闭")
        except Exception as e:
            self.append_log_with_timestamp(f"关闭拖拽失败: {str(e)}")
    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    window = MainWindow()
    sys.exit(app.exec())
