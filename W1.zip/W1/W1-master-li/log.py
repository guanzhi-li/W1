import logging
import logging.handlers
import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Union, Dict, Any

class Logger:
    """
    功能完整的日志类
    支持控制台输出、文件输出、日志轮转等功能
    """
    
    # 日志级别映射
    LEVELS = {
        'DEBUG': logging.DEBUG,
        'INFO': logging.INFO,
        'WARNING': logging.WARNING,
        'ERROR': logging.ERROR,
        'CRITICAL': logging.CRITICAL
    }
    
    def __init__(
        self,
        name: str = "AppLogger",
        level: str = "INFO",
        log_dir: str = "logs",
        console_output: bool = True,
        file_output: bool = True,
        max_file_size: int = 10 * 1024 * 1024,  # 10MB
        backup_count: int = 5,
        log_format: Optional[str] = None,
        date_format: Optional[str] = None
    ):
        """
        初始化日志类
        
        Args:
            name: 日志器名称
            level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_dir: 日志目录
            console_output: 是否输出到控制台
            file_output: 是否输出到文件
            max_file_size: 单个日志文件最大大小（字节）
            backup_count: 备份文件数量
            log_format: 自定义日志格式
            date_format: 自定义日期格式
        """
        self.name = name
        self.log_dir = Path(log_dir)
        self.console_output = console_output
        self.file_output = file_output
        self.max_file_size = max_file_size
        self.backup_count = backup_count
        
        # 设置日志格式
        self.log_format = log_format or (
            '%(asctime)s - %(name)s - %(levelname)s - '
            '[%(filename)s:%(lineno)d] - %(message)s'
        )
        self.date_format = date_format or '%Y-%m-%d %H:%M:%S'
        
        # 创建日志器
        self.logger = logging.getLogger(name)
        self._set_level(level)
        
        # 避免重复添加处理器
        if not self.logger.handlers:
            self._setup_handlers()
        
        # 保存原始异常方法
        self._exception = self.logger.exception
        
    def _set_level(self, level: str):
        """设置日志级别"""
        level_upper = level.upper()
        if level_upper in self.LEVELS:
            self.logger.setLevel(self.LEVELS[level_upper])
        else:
            self.logger.setLevel(logging.INFO)
            self.warning(f"未知的日志级别 '{level}'，使用默认级别 INFO")
    
    def _setup_handlers(self):
        """设置日志处理器"""
        # 创建格式化器
        formatter = logging.Formatter(self.log_format, self.date_format)
        
        # 控制台处理器
        if self.console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)
        
        # 文件处理器（带轮转）
        if self.file_output:
            self._setup_file_handler(formatter)
    
    def _setup_file_handler(self, formatter: logging.Formatter):
        """设置文件处理器"""
        try:
            # 创建日志目录
            self.log_dir.mkdir(parents=True, exist_ok=True)
            
            # 日志文件路径
            log_file = self.log_dir / f"{self.name}.log"
            
            # 创建轮转文件处理器
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=self.max_file_size,
                backupCount=self.backup_count,
                encoding='utf-8'
            )
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
            
        except Exception as e:
            print(f"创建文件处理器失败: {e}")
    
    def set_level(self, level: str):
        """动态设置日志级别"""
        self._set_level(level)
        for handler in self.logger.handlers:
            handler.setLevel(self.logger.level)
    
    def get_log_file_path(self) -> Optional[Path]:
        """获取当前日志文件路径"""
        for handler in self.logger.handlers:
            if isinstance(handler, logging.handlers.RotatingFileHandler):
                return Path(handler.baseFilename)
        return None
    
    def get_log_files(self) -> list:
        """获取所有日志文件列表"""
        log_file = self.get_log_file_path()
        if not log_file:
            return []
        
        log_files = [log_file]
        for i in range(1, self.backup_count + 1):
            backup_file = Path(f"{log_file}.{i}")
            if backup_file.exists():
                log_files.append(backup_file)
        
        return log_files
    
    def clear_old_logs(self, keep_count: Optional[int] = None):
        """清理旧的日志文件"""
        keep_count = keep_count or self.backup_count
        log_files = self.get_log_files()
        
        if len(log_files) > keep_count:
            for log_file in log_files[keep_count:]:
                try:
                    log_file.unlink()
                    self.info(f"已删除旧日志文件: {log_file}")
                except Exception as e:
                    self.error(f"删除日志文件失败 {log_file}: {e}")
    
    # 日志记录方法
    def debug(self, msg: str, *args, **kwargs):
        """记录调试信息"""
        self.logger.debug(msg, *args, **kwargs)
    
    def info(self, msg: str, *args, **kwargs):
        """记录一般信息"""
        self.logger.info(msg, *args, **kwargs)
    
    def warning(self, msg: str, *args, **kwargs):
        """记录警告信息"""
        self.logger.warning(msg, *args, **kwargs)
    
    def error(self, msg: str, *args, **kwargs):
        """记录错误信息"""
        self.logger.error(msg, *args, **kwargs)
    
    def critical(self, msg: str, *args, **kwargs):
        """记录严重错误信息"""
        self.logger.critical(msg, *args, **kwargs)
    
    def exception(self, msg: str, *args, **kwargs):
        """记录异常信息（包含堆栈跟踪）"""
        self._exception(msg, *args, **kwargs)
    
    def log_performance(self, func):
        """性能日志装饰器"""
        from functools import wraps
        import time
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                execution_time = time.time() - start_time
                self.info(f"函数 {func.__name__} 执行时间: {execution_time:.4f}秒")
                return result
            except Exception as e:
                execution_time = time.time() - start_time
                self.error(f"函数 {func.__name__} 执行失败，耗时: {execution_time:.4f}秒，错误: {e}")
                raise
        return wrapper
    
    def log_operation(self, operation: str, **details):
        """记录操作日志"""
        details_str = " ".join([f"{k}={v}" for k, v in details.items()])
        self.info(f"[操作] {operation} - {details_str}")
    
    def __enter__(self):
        """上下文管理器入口"""
        self.info("=" * 50)
        self.info("程序开始执行")
        self.info("=" * 50)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        if exc_type:
            self.exception("程序执行过程中发生异常")
        else:
            self.info("程序正常结束")
        self.info("=" * 50)
        return False