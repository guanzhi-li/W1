import sys
import subprocess
import os
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit
)
from PySide6.QtCore import QThread, Signal, Qt, QTimer
from PySide6.QtGui import QColor, QPalette, QLinearGradient
import json

class ScriptRunnerThread(QThread):
    """在后台线程中运行脚本"""
    output_signal = Signal(str)
    error_signal = Signal(str)
    finished_signal = Signal(int)

    def __init__(self, script_path):
        super().__init__()
        self.script_path = script_path

    def run(self):
        try:
            # 检查文件是否存在
            if not os.path.exists(self.script_path):
                self.error_signal.emit(f"错误：文件 {self.script_path} 不存在")
                self.finished_signal.emit(1)
                return
            # 确保文件有执行权限
            if not os.access(self.script_path, os.X_OK):
                os.chmod(self.script_path, 0o755)
                self.output_signal.emit("为脚本添加执行权限...")

            self.output_signal.emit(f"正在执行脚本: {self.script_path}")
            self.output_signal.emit("-" * 50)

            # 修改这里：添加处理 TTY 相关的参数
            process = subprocess.Popen(
                [self.script_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                universal_newlines=True,
                # 添加以下参数来解决 TTY 问题
                stdin=subprocess.DEVNULL,  # 不分配 stdin
                preexec_fn=os.setsid if hasattr(os, 'setsid') else None  # 创建新的进程组
            )
            
            # 实时读取标准输出
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                if output:
                    self.output_signal.emit(f"[STDOUT] {output.strip()}")

            # 读取错误输出
            stderr = process.stderr.read()
            if stderr:
                self.error_signal.emit(f"[STDERR] {stderr.strip()}")

            return_code = process.wait()
            self.finished_signal.emit(return_code)

        except Exception as e:
            self.error_signal.emit(f"执行过程中发生错误: {e}")
            self.finished_signal.emit(1)


class TechMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pickwiz 启动器")
        self.setGeometry(800, 0, 800, 500)  # 增大窗口尺寸
        self.script_thread = None
        self.init_ui()
        self.setup_tech_style()
        # 添加自动运行功能
        QApplication.processEvents()  # 确保UI完全加载
        self._write_status_file(False)
        self.run_script()  # 自动执行脚本

    def close_after_delay(self):
        """延迟关闭窗口"""
        self.close()
        
    def setup_tech_style(self):
        """设置科技风样式"""
        # 设置主窗口背景为深色渐变
        palette = self.palette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(20, 30, 50))
        gradient.setColorAt(1, QColor(10, 20, 40))
        palette.setBrush(QPalette.Window, gradient)
        self.setPalette(palette)

    def init_ui(self):
        # 主窗口部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        # 主布局
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(5)  # 减少间距
        main_layout.setContentsMargins(10, 10, 10, 10)  # 减少边距

        # 创建按钮区域（直接放置按钮，不要外框）
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)  # 减少按钮间距
        button_layout.setContentsMargins(0, 0, 0, 0)  # 去掉边距

        self.run_btn = self._create_small_tech_button("启动 Pickwiz", "blue")
        self.run_btn.clicked.connect(self.run_script)
        button_layout.addWidget(self.run_btn)

        self.stop_btn = self._create_small_tech_button("停止 Pickwiz", "red")
        self.stop_btn.clicked.connect(self.stop_script)
        self.stop_btn.setEnabled(False)
        button_layout.addWidget(self.stop_btn)

        # 添加一些弹性空间使按钮居中
        button_layout.addStretch()
        button_layout.insertStretch(0)

        main_layout.addLayout(button_layout)

        # 创建日志显示区域（最大化，去掉标签和外框）
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: rgba(10, 25, 47, 0.8);
                border: 2px solid #00b4ff;
                border-radius: 5px;
                padding: 10px;
                color: #00ffff;
                font-family: 'Courier New';
                font-size: 12px;
            }
        """)

        # 给日志区域最大拉伸因子
        main_layout.addWidget(self.log_text, 10)  # 增大拉伸因子

    def _create_small_tech_button(self, text, color="blue"):
        """创建小型科技风按钮"""
        btn = QPushButton(text)
        if color == "blue":
            btn.setStyleSheet("""
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                stop:0 #0066cc, stop:1 #003366);
                    color: white;
                    border: 2px solid #00b4ff;
                    border-radius: 5px;
                    padding: 8px 15px;
                    font-weight: bold;
                    font-size: 12px;
                    min-width: 100px;
                    max-width: 120px;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                stop:0 #0088ff, stop:1 #0055aa);
                }
                QPushButton:pressed {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                stop:0 #004488, stop:1 #002244);
                }
                QPushButton:disabled {
                    background: #555555;
                    border: 2px solid #777777;
                    color: #aaaaaa;
                }
            """)
        elif color == "red":
            btn.setStyleSheet("""
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                stop:0 #cc0000, stop:1 #660000);
                    color: white;
                    border: 2px solid #ff4444;
                    border-radius: 5px;
                    padding: 8px 15px;
                    font-weight: bold;
                    font-size: 12px;
                    min-width: 100px;
                    max-width: 120px;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                stop:0 #ff0000, stop:1 #880000);
                }
                QPushButton:pressed {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                stop:0 #880000, stop:1 #440000);
                }
                QPushButton:disabled {
                    background: #555555;
                    border: 2px solid #777777;
                    color: #aaaaaa;
                }
            """)
        return btn

    def run_script(self):
        """执行脚本"""
        script_path = "/home/dexforce/workspace/dexe_application/qt/pickwiz.sh"

        if not script_path:
            self.append_error("请设置脚本路径")
            return

        if not os.path.exists(script_path):
            self.append_error(f"文件不存在: {script_path}")
            return

        # 禁用运行按钮，启用停止按钮
        self.run_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.log_text.append(f"开始执行脚本: {script_path}")
        self.log_text.append("-" * 50)
        # 创建并启动线程
        self.script_thread = ScriptRunnerThread(script_path)
        self.script_thread.output_signal.connect(self.append_output)
        self.script_thread.error_signal.connect(self.append_error)
        self.script_thread.finished_signal.connect(self.script_finished)
        self.script_thread.start()

    def stop_script(self):
        """停止执行"""
        self._write_status_file(False)
        if self.script_thread and self.script_thread.isRunning():
            try:
                # 尝试使用进程组终止整个进程树
                if hasattr(self.script_thread, 'process') and self.script_thread.process:
                    import signal
                    os.killpg(os.getpgid(self.script_thread.process.pid), signal.SIGTERM)
            except:
                # 如果上面的方法失败，使用原来的方法
                self.script_thread.terminate()
            self.script_thread.wait()
            self.append_error("执行已被用户终止")
            self.script_finished(-1)

    def append_output(self, message):
        """添加标准输出到日志"""
        self.log_text.append(message)
        self.scroll_to_bottom()
        if "脚本执行成功!" in message or "当前相机及配置无更改" in message or "initLog:logLevel(1),printLevel(0),logFile(/root/.dexforce/camlog/KFC-ROS.log)" in message:
            self.log_text.append("=== Pickwiz启动完成 ===\n")
            self._write_status_file(True)
            # QTimer.singleShot(500, self.close_after_delay)

    def append_error(self, message):
        """添加错误输出到日志"""
        self.log_text.append(f'<font color="red">{message}</font>')
        self.scroll_to_bottom()
        # 显示错误弹窗（非模态，避免锁定）
        self.show_error_dialog(message)

    def show_error_dialog(self, message):
        """显示错误对话框（非模态）"""
        from PySide6.QtWidgets import QMessageBox
        msg_box = QMessageBox(self)
        msg_box.setIcon(QMessageBox.Critical)
        msg_box.setWindowTitle("错误")
        msg_box.setText(message)
        msg_box.setStandardButtons(QMessageBox.Ok)
        msg_box.show()  # 非模态显示，用户可以移动和关闭

    def scroll_to_bottom(self):
        """滚动到底部"""
        scrollbar = self.log_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def script_finished(self, return_code):
        """脚本执行完成"""
        self.run_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        if return_code == 0:
            self.append_output("-" * 50)
            self.append_output("脚本执行成功!")
        else:
            self.append_output("-" * 50)
            self.append_error(f"脚本执行失败! 返回码: {return_code}")

    def _write_status_file(self, status):
        """写入状态到JSON文件"""
        try:
            # 确保目录存在
            self.status_file = "/home/dexforce/workspace/dexe_application/qt/auto_config.json"
            os.makedirs(os.path.dirname(self.status_file), exist_ok=True)
            
            # 先读取现有配置（如果文件存在）
            status_data = {}
            if os.path.exists(self.status_file):
                try:
                    with open(self.status_file, 'r', encoding='utf-8') as f:
                        status_data = json.load(f)
                except:
                    # 如果文件损坏或格式错误，创建新的配置
                    status_data = {}
            
            # 只更新pickwiz_status字段，保留其他字段
            status_data["pickwiz_status"] = status
            
            # 写入更新后的配置
            with open(self.status_file, 'w', encoding='utf-8') as f:
                json.dump(status_data, f, indent=2, ensure_ascii=False)
                
            print(f"Pickwiz状态已更新: {status}")
        except Exception as e:
            print(f"写入状态文件失败: {e}")

def main():
    app = QApplication(sys.argv)

    window = TechMainWindow()
    window.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()