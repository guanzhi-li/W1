from log import *

#初始化日志
global logger
logger = Logger(
        name="MyApp",
        level="DEBUG",
        log_dir="app_logs",
        console_output=True,
        file_output=True,
        max_file_size=5 * 1024 * 1024,  # 5MB
        backup_count=3
        )

class W1_Logic:
    def __init__(self, w1):
        self.w1 = w1

    def  w1_Move(self, move_point):
          try:
            success = self.w1.w1_manager.move_linear_full_body(
                 waypoints_dict=move_point,
                 speed_ratio=self.device_cfg["ui_param"]["movel_speed"]
                 )
            if success:  
                logger.info("机器人运动成功")
            else:  
                logger.error("机器人运动失败")          
          except(Exception):
              logger.error("机器人运动失败")
              logger.error(Exception)

               
          


          
